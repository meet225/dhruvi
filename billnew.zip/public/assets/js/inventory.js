/*********** Grand total grid ***********/
function grandTotal(){
    var grandtotal = 0;
    $('.item_grid').each(function(i){
        var row_num = $(this).attr('id').split('-');
        var netamount = $('[name="totalamount-'+row_num[1]+'"]').val();
        if(typeof netamount !== 'undefined'){
            grandtotal += +netamount;
        }
    });
    $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
    $('input[name="grandtotal"]').trigger('keyup');
}

function discount(discper,grandtotal){
    if (discper != '' && grandtotal != '') {
        var discamount = (parseFloat(grandtotal)) * (parseFloat(discper)) / 100;
        if (isFinite(discamount)){
            $('input[name="discamt"]').val(discamount.toFixed(2));
        }
    }else{
        $('input[name="discamt"]').val('');
    }
}

function discountAmount(discamt,grandtotal){
    if (discamt != '' && grandtotal != '') {
        var discper = (parseFloat(discamt)) * 100 / (parseFloat(grandtotal));
        if (isFinite(discper)){
            $('input[name="discper"]').val(discper.toFixed(2));
        }
    }else{
        $('input[name="discper"]').val('');
    }
}

function totalNetAmount(grandtotal,discamt,othercharges){
    if (grandtotal != '' && discamt != '' && othercharges != '') {
        
        var total_netamount = (parseFloat(grandtotal)) - (parseFloat(discamt)) + (parseFloat(othercharges));
        
        var decimalPart = total_netamount - Math.floor(total_netamount);
        var onlyTwoDecimalPlaces = decimalPart.toFixed(2);
        var explode = onlyTwoDecimalPlaces.split('.');
        if(explode[1] == '00'){
            $('input[name="roundoff"]').val('')
            var final_netamt = (parseFloat(total_netamount));
        }else if(explode[1] > '5'){
            var roundval = 1 - onlyTwoDecimalPlaces;
            $('input[name="roundoff"]').val('+'+roundval.toFixed(2))
            var final_netamt = (parseFloat(total_netamount)) + (parseFloat(roundval));
        }else if(explode[1] < '5'){
            $('input[name="roundoff"]').val('-'+onlyTwoDecimalPlaces)
            var final_netamt = (parseFloat(total_netamount)) - (parseFloat(onlyTwoDecimalPlaces));
        }
        $('input[name="netamount"]').val((final_netamt).toFixed(2));
        $('input[name="netamount"]').trigger('keyup');
    }else{
        $('input[name="netamount"]').val('');
    }
}

$('input[name="discper"]').on("keyup", function() {
    var discper=0,grandtotal=0;
    discper += $(this).val();
    grandtotal += $('input[name="grandtotal"]').val();
    discount(discper,grandtotal);
    $('input[name="othercharges"]').trigger('keyup');
    $('input[name="tcsper"]').trigger('keyup');
});

$('input[name="discamt"]').on("keyup", function() {
    var discamt=0,grandtotal=0;
    discamt += $(this).val();
    grandtotal += $('input[name="grandtotal"]').val();
    discountAmount(discamt,grandtotal);
    //totalNetAmountDiagnostic(grandtotal,discamt)
    $('input[name="othercharges"]').trigger('keyup');
    $('input[name="tcsper"]').trigger('keyup');
});

$('input[name="othercharges"]').on("keyup", function() {
    var discamt = 0,othercharges = 0;
    var grandtotal = $('input[name="grandtotal"]').val();
    discamt += $('input[name="discamt"]').val();
    othercharges += $(this).val();
    totalNetAmount(grandtotal,discamt,othercharges);
});
/*********** End Grand total grid ***********/

/****** Inventory Item Grid Keyup Event *******/
function itemGridCalculation($ele){
    $('input[name="recqty-'+$ele+'"]').on("keyup", function() {
        // var value=0,rate=0;
        var value = $(this).val();
        var rate = $('input[name="rate-'+$ele+'"]').val();
        var netamount = (parseFloat(value)) * (parseFloat(rate));
        if (value != '' && rate != '') {
            $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
            $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
            $('input[name="basicamount-'+$ele+'"]').trigger('keyup');
            $('input[name="discper-'+$ele+'"]').trigger('keyup');
            $('input[name="totalamount-'+$ele+'"]').trigger('keyup');

        }else{
            $('input[name="basicamount-'+$ele+'"]').val('');
            $('input[name="totalamount-'+$ele+'"]').val('');
        }
        grandTotal();
        $('input[name="discper"]').trigger('keyup');
        $('input[name="tcsper"]').trigger('keyup');
        $('input[name="othercharges"]').trigger('keyup');
    })
    $('input[name="rate-'+$ele+'"]').on("keyup", function() {
        // var value = 0,recqty=0;
        var value = $(this).val();
        var recqty = $('input[name="recqty-'+$ele+'"]').val();
        var netamount = (parseFloat(value)) * recqty;

        if (value != '' && recqty != '') {
            $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
            $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
            $('input[name="basicamount-'+$ele+'"]').trigger('keyup');
            $('input[name="totalamount-'+$ele+'"]').trigger('keyup');
            $('input[name="discper-'+$ele+'"]').trigger('keyup');
        }else{
            $('input[name="basicamount-'+$ele+'"]').val('');
            $('input[name="totalamount-'+$ele+'"]').val('');
        }
        grandTotal();
        $('input[name="discper"]').trigger('keyup');
        $('input[name="tcsper"]').trigger('keyup');
        $('input[name="othercharges"]').trigger('keyup');
    })
    $('input[name="discper-'+$ele+'"]').on("keyup", function() {
        var discper = $(this).val();
        var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
        var discper = $('[name="discper-'+$ele+'"]').val();
        var basicamount = $('[name="basicamount-'+$ele+'"]').val();
        if (isFinite(basicamount) && discper != '' && basicamount != '') {
            if(typeof basicamount !== 'undefined'){
            var discamount = (parseFloat(basicamount)) * (parseFloat(discper)) / 100;
            $('[name="discamt-'+$ele+'"]').val(discamount.toFixed(2));
            var netamount = (parseFloat(basicamount)) - (parseFloat(discamount))
            $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
            }
        }else{
            $('[name="discamt-'+$ele+'"]').val('');
            $('[name="totalamount-'+$ele+'"]').val(basicamount);
        }
        grandTotal();
        $('input[name="discper"]').trigger('keyup');
        $('input[name="othercharges"]').trigger('keyup');
    });
    $('input[name="discamt-'+$ele+'"]').on("keyup", function() {
        var discamt = $(this).val();
        var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
        var discamt = $('[name="discamt-'+$ele+'"]').val();
        var basicamount = $('[name="basicamount-'+$ele+'"]').val();

        if (isFinite(basicamount) && discamt != '' && basicamount != '' && basicamount != 0) {
            if(typeof basicamount !== 'undefined'){
            var discper = (parseFloat(discamt)) * 100 / (parseFloat(basicamount));
            $('[name="discper-'+$ele+'"]').val(discper.toFixed(2));
            var netamount = (parseFloat(basicamount)) - (parseFloat(discamt))
            $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
            }
        }else{
            $('[name="discper-'+$ele+'"]').val('');
            $('[name="totalamount-'+$ele+'"]').val(basicamount);
        }
        grandTotal();
        $('input[name="discper"]').trigger('keyup');
        $('input[name="othercharges"]').trigger('keyup');
    });
}

/*** Inventory Purchase Bill ***/
function billItemGridCalculation($ele){
$('input[name="days-'+$ele+'"]').on("keyup", function() {
    // var value=0,rate=0;
    var value = $(this).val();
    var rate = $('input[name="rate-'+$ele+'"]').val();
    var qty = $('input[name="qty-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(rate)) * (parseFloat(qty));
    if (value != '' && rate != '' && qty != '') {
        $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
        $('input[name="totalamount-'+$ele+'"]').trigger('keyup');
    }else{
        $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
})
$('input[name="qty-'+$ele+'"]').on("keyup", function() {
    // var value=0,rate=0;
    var value = $(this).val();
    var rate = $('input[name="rate-'+$ele+'"]').val();
    var days = $('input[name="days-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(rate)) * (parseFloat(days));
    if (value != '' && rate != '' && days != '') {
        $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
        $('input[name="totalamount-'+$ele+'"]').trigger('keyup');

    }else{
        $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
})
$('input[name="rate-'+$ele+'"]').on("keyup", function() {
    var value = $(this).val();
    var qty = $('input[name="qty-'+$ele+'"]').val();
    var days = $('input[name="days-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(days)) * (parseFloat(qty));
  
    if (value != '' && qty != '' && days != '') {
        $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
        $('input[name="totalamount-'+$ele+'"]').trigger('keyup');
    }else{
        $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
})

}
/*** Inventory Purchase Bill ***/
// Payment type on change event at purchase bill
function paymentMode(pmode){
    if($(pmode).val() !== 'Cash'){
        if($(pmode).val() == null || $(pmode).val() == ''){
            $('.transactionno,.transactiondate,.bankname').val('');
            $('#transactionno-error, #transactiondate-error, #bankname-error,#paidamount-error').text('')
            $('.payment-details').hide();
        }else{
            $('.payment-details').show();
        }
        if($(pmode).val() == 'Cheque'){
            $('.numberlbl,.datelbl').text('');
            $('.numberlbl').append("Cheque No.<span class='required'>*</span>");
            $('.datelbl').append("Cheque Date<span class='required'>*</span>");
        }else if($(pmode).val() == 'Credit Card' || $(pmode).val() == 'Debit Card') {
            $('.numberlbl,.datelbl').text('');
            $('.numberlbl').append("Transaction No.<span class='required'>*</span>");
            $('.datelbl').append("Transaction Date<span class='required'>*</span>");
        }
    }else{
        $('.transactionno,.transactiondate,.bankname').val('');
        //$('#transactionno-error, #transactiondate-error, #bankname-error,#paidamount-error').text('')
        $('#transactionno-error, #transactiondate-error, #bankname-error').text('')
        $('.payment-details').hide();
    }
}
$('.paymentmode').on('change', function() {
    paymentMode($(this));
});
// Payment type on change event at purchase bill
