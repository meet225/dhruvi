
<?php $__env->startSection('content'); ?>
<div class="panel">
  <div class="panel-body">
    <div class="brand hms_brand">
      <!-- <img class="brand-img" src="<?php echo e(asset('assets/images/icon-2.png')); ?>" alt="..."> -->
      <span>ANTRIX SUPPLIRES</span>
      <!--<h2 class="brand-text font-size-18">
          <?php echo e(trans('panel.site_tag')); ?>

      </h2>-->
    </div>
    <br>
    <h3>Forgot Your Password ?</h3>
    <p>Input your registered email to reset your password</p>
    <?php if(session('status')): ?>
    <div class="alert dark alert-alt alert-info alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('password.email')); ?>" autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="form-group form-material floating" data-plugin="formMaterial">
        <input type="email" name="email" id="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" required autocomplete="email" autofocus placeholder="<?php echo e(trans('global.login_email')); ?>" value="<?php echo e(old('email')); ?>"/>
        <label class="floating-label"><?php echo e(trans('global.login_email')); ?></label>
        <?php if($errors->has('email')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('email')); ?>

            </div>
        <?php endif; ?>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg mt-40"><?php echo e(trans('global.send_password')); ?></button>
    </form>
    <!-- <p>Still no account? Please go to <a href="register-v3.html">Sign up</a></p> -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>