<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/flatpickr/flatpickr.min.css')); ?>">
<!-- Datatable -->
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.min.css')); ?>">
<style type="text/css">
   .modal-open .select2-container {
   z-index: 0;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
   <h1 class="page-title">Create Payment Entry</h1>
   <?php echo e(Breadcrumbs::render('admin.payment_entries.create')); ?>

</div>
<div class="page-content">
      <form method="POST" action='<?php echo e(route("admin.payment_entries.store")); ?>' id="hms_form" autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="panel">
         <div class="panel-body">
            <div class="row">
               <div class="col-md-3">
                  <div class="form-group form-material <?php echo e($errors->has('paymentcode') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label" for="paymentcode">Payment Code<span class="required">*</span></label>
                     <input class="form-control" type="text" name="paymentcode" id="paymentcode" value="<?php echo e(old('paymentcode', $paymentcode['generated_code'])); ?>" maxlength="100" readonly>
                     <input type="hidden" name="paymentcodeid" id="paymentcodeid" value="<?php echo e($paymentcode['sr_no']); ?>">
                     <div class="invalid-feedback">
                        <?php if($errors->has('paymentcode')): ?>
                        <?php echo e($errors->first('paymentcode')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('paymentdatetime') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label" for="paymentdatetime"><b>Payment Date & Time</b><span class="required">*</span></label>
                     <div class="input-group">
                        <span class="input-group-addon">
                        <i class="icon md-calendar" aria-hidden="true"></i>
                        </span>
                        <input class="form-control" type="text" name="paymentdatetime" id="paymentdatetime" value="<?php echo e(old('paymentdatetime','')); ?>">
                     </div>
                     <div class="invalid-feedback">
                        <?php if($errors->has('paymentdatetime')): ?>
                        <?php echo e($errors->first('paymentdatetime')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('customerid') ? 'has-danger' : ''); ?>">
                       <label class="form-control-label" for="customerid">Customer Name<span class="required">*</span></label>
                       <select class="form-control select2" name="customerid" id="customerid">

                       </select>
                       <div class="invalid-feedback">
                           <?php if($errors->has('customerid')): ?>
                               <?php echo e($errors->first('customerid')); ?>

                           <?php endif; ?>
                       </div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="col-md-12">
                  <div class="card border border-info hms_card_primary">
                     <div class="card-header card-header-transparent card-header-bordered bg-info">
                     Bill Details
                     </div>
                     <div class="card-block">
                        <div class="table-responsive" id="bill_detail_table">

                        </div>
                     </div>
                  </div>
               </div>
               <div class="clearfix"></div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('paymentmode') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label" for="paymentmode">Payment Type<span class="required">*</span></label>
                     <select class="form-control select2 paymentmode" name="paymentmode">
                        <?php $__currentLoopData = $paymentmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payid => $payname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($payname); ?>" <?php echo e(((old('paymentmode')==$payname))? 'selected' : ''); ?>><?php echo e($payname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                     <div class="invalid-feedback">
                        <?php if($errors->has('paymentmode')): ?>
                        <?php echo e($errors->first('paymentmode')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('paidamount') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label" for="paidamount">Paid Amount<span class="required">*</span></label>
                     <input class="form-control allow_decimal" type="text" name="paidamount" id="paidamount" value="<?php echo e(old('paidamount')); ?>" data-beforedecimal="7" data-afterdecimal="2" readonly>
                     <div class="invalid-feedback">
                        <?php if($errors->has('paidamount')): ?>
                        <?php echo e($errors->first('paidamount')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
            </div>
            <div class="row payment-details" style="display: none;">
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('transactionno') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label numberlbl" for="transactionno"></label>
                     <input class="form-control transactionno" type="text" name="transactionno" value="<?php echo e(old('transactionno')); ?>" maxlength="100">
                     <div class="invalid-feedback">
                        <?php if($errors->has('transactionno')): ?>
                        <?php echo e($errors->first('transactionno')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('transactiondate') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label datelbl" for="transactiondate"></label>
                     <div class="input-group">
                        <span class="input-group-addon">
                        <i class="icon md-calendar" aria-hidden="true"></i>
                        </span>
                        <input class="form-control transactiondate" type="text" name="transactiondate" value="<?php echo e(old('transactiondate', '')); ?>">
                     </div>
                     <div class="invalid-feedback">
                        <?php if($errors->has('transactiondate')): ?>
                        <?php echo e($errors->first('transactiondate')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="form-group form-material <?php echo e($errors->has('bankname') ? 'has-danger' : ''); ?>">
                     <label class="form-control-label" for="bankname">Bank Name<span class="required">*</span></label>
                     <input class="form-control bankname" type="text" name="bankname" value="<?php echo e(old('bankname')); ?>" maxlength="100">
                     <div class="invalid-feedback">
                        <?php if($errors->has('bankname')): ?>
                        <?php echo e($errors->first('bankname')); ?>

                        <?php endif; ?>
                     </div>
                     <span class="help-block"></span>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="clearfix"></div>
         <div class="container">
            <div class="row justify-content-center">
               <div class="p-1">
                  <button class="btn btn-primary waves-effect waves-classic" type="submit">
                  Save
                  </button>
               </div>
               <div class="p-1">
                  <a href="<?php echo e(url('admin/inventory/payment_entries')); ?>" class="btn btn-secondary waves-effect waves-classic">
                  Cancel
                  </a>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<!-- Purchase bill return Modal -->
<div class="modal fade" id="PBillInfo" tabindex="-1" role="dialog" aria-labelledby="PBillInfoLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="PBillInfoLabel">Bill Details</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <table class="table table-bordered table-hover">
               <thead>
                  <tr>
                     <th scope="col">Bill Amount</th>
                     <th scope="col">Return Amount</th>
                     <th scope="col">Pending Amount</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <td id="ttlInvoiceAmt"></td>
                     <td id="ttlReturnAmt"></td>
                     <td id="ttlPayingAmt"></td>
                  </tr>
               </tbody>
            </table>
         </div>
      </div>
   </div>
 </div>
 <!-- End Purchase bill return Modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('global/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/flatpickr/flatpickr.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/jquery-validate/jquery.validate.min.js')); ?>"></script>
<!-- Bootbox -->
<script src="<?php echo e(asset('global/vendor/bootbox/bootbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/billing.js')); ?>"></script>
<!-- Datatable -->
<script src="<?php echo e(asset('global/vendor/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/datatables.net-responsive-bs4/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript">
   $.ajaxSetup({
      headers: {
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
   });

   jQuery.validator.addMethod('lessThanPendingAmt', function(value, element, param) {
      if (this.optional(element)) return true;
      var pendingamt = parseFloat($(param).val());
      var paying_amt = parseFloat(value);
      return pendingamt >= paying_amt;
   }, "Amount must be less than or equal to pending amount.");

   $(document).ready(function(){
      $( "#paymentdatetime" ).flatpickr({
         enableTime: true,
         time_24hr: true,
         dateFormat: 'd-m-Y H:i',
         defaultDate: new Date()
      });
      $('.transactiondate').flatpickr( {
         dateFormat: 'd-m-Y',
      });

      $('.select2').select2();
      $('.select2, #paymentdatetime,.transactiondate').on('change', function() {
         $(this).valid();
      });

      $("#hms_form").validate({
         rules: {
            paymentcode:{
               required: true,
               maxlength:100
            },
            paymentdatetime:{
               required: true
            },
            customerid: {
               required: true
            },
            paymentmode: {
               required: true
            },
            paidamount: {
               required: true
            },
            "payingamount-0": {
               lessThanPendingAmt: "#pendingamount-0",
               required: true
            },
            transactionno: {
               required: function(element){
                  return $(".paymentmode").val()!="Cash";
               },
               maxlength:100
            },
            transactiondate: {
               required: function(element){
                  return $(".paymentmode").val()!="Cash";
               }
            },
            bankname: {
               required: function(element){
                  return $(".paymentmode").val()!="Cash";
               },
               maxlength:100
            },
         },
         errorPlacement: function (error, element){
            if(element.attr("name") == "transactiondate" || element.attr("name") == "paymentdatetime") {
               $placement=$(element).parent().parent().find('.invalid-feedback');
               error.appendTo($placement);
               $placement.show();
            } else{
               $placement=$(element).parent().find('.invalid-feedback');
               error.appendTo($placement);
               $placement.show();
            }
         },
         onfocusout: function(element) {
            valid_data(element);
         }
      });

      totalPayingAmount();
      lessThanPendingAmount();
      $(document).on("change","#customerid",function(e){
         var customerid = $(this).val();
         $('#bill_detail_table').html('');
         $('#search_modal').modal('toggle');
         $("#paidamount").val('');
         $(".paymentmode").val($(".paymentmode option:contains('Cash')").val()).trigger('change');
         partyBillDetails(customerid)
      });

      // Purchase Bill detail section
      function partyBillDetails(customerid){
         $.ajax({
            url: "<?php echo e(route('admin.party-bills')); ?>",
            type:'get',
            dataType: 'json',
            data: {
               customerid : customerid,
            },
            success:function(data){
               $('#bill_detail_table').html(data);
               // recAmtValidate()
               totalPayingAmount()
               lessThanPendingAmount();
               // billDetSerSor();
            }
         });
      }

      getSingleSelect2List({
         selector:document.getElementById('customerid'),
         placeholder:'Select customer Name...',
         model:'customers',
         field_id_name:'id',
         field_name:'name',
         status:1,
      });

      <?php if(old('customerid')!=''): ?>
         getSingleSelect2List({
            selector:document.getElementById('customerid'),
            placeholder:'Select Customer Name...',
            model:'customers',
            field_id_name:'id',
            field_name:'name',
            status:1,
            whereArr: [{'customerid': "<?php echo e(old('customerid')); ?>"}],
         });
      <?php endif; ?>

      /* getSingleSelect2List({
         selector:document.getElementsByClassName('paymentmode'),
         placeholder:'Select payment type...',
         model:'m_lookupfixed',
         field_id_name:'keyvalue',
         field_name:'keyvalue',
         whereArr:[{'keyname':"paymentmode"}],
         nonehospid:true,
      }); */

      $("#hms_form").submit(function(e){
         e.preventDefault();
         if($('#hms_form').valid()){
            // bootbox.dialog({
            //    message: "Are you sure you want to print this Indent/Requisition?",
            //    title: "ARE YOU SURE?",
            //    buttons: {
            //    danger: {
            //       label: "Confirm",
            //       className: "btn-danger",
            //       callback: function callback() {
            //          callSaveButtonAjax(true);
            //       }
            //    },
            //    main: {
            //       label: "Cancel",
            //       className: "btn-primary",
            //       callback: function callback() {
            //          callSaveButtonAjax(false);
            //       }
            //    },
            //    },
            //    onEscape: function () {
            //       $('button[type="submit"]').removeAttr('disabled', 'disabled');
            //    }
            // });
            // ****Please remove this code when print enable****
            $('button[type="submit"]').removeAttr('disabled', 'disabled');
               callSaveButtonAjax(false);
         }
      });

      function callSaveButtonAjax(printresult)
      {
         var url = "<?php echo e(route('admin.payment_entries.store')); ?>";
         $.ajax({
            url:url,
            type:'POST',
            data:$('#hms_form').serialize(),
            beforeSend: function () { $('#hms_loader').show(); },
            success:function(data){
               if(data.success==true){
                  if (printresult == true) {
                     var invpaymententryid = data.invpaymententryid;
                     var popup = window.open(base_url+'/admin/print/receipt?invpaymententryid='+invpaymententryid,'_blank');
                     popupBlockerChecker.check(popup);
                     window.location.href="<?php echo e(route("admin.payment_entries.index")); ?>";
                  } else {
                     window.location.href="<?php echo e(route("admin.payment_entries.index")); ?>";
                  }
            }else{
               $('#hms_loader').hide();
               toastrError('',data.message);
            }
         },
         error: function(response) {
               printErrorMsg(response.responseJSON.errors);
               $('#hms_loader').hide();
         }
         });
      }

      $(document).on("change","select",function() {
         $(this).valid();
      });
      function printErrorMsg(msg){
         var error_html='';
         $.each( msg, function( key1, value1 ) {
               $.each( value1, function( key2, value2 ) {
                  $('#'+key1).parents('div[class^="form-group"]').addClass('has-danger');
                  $('#'+key1).parents('div[class^="form-group "]').find('.invalid-feedback').html(value2).show();
                  error_html+='<li>'+value2+'</li>';
               });
         });
         toastrErrors(error_html,'The given data was invalid.');
      }

      // Payment Entry > Paid Amount
      function totalPaidAmount(){
         var totalpaidamt = 0;
         $('.bill_grid').each(function(i){
            var row_num = $(this).attr('id').split('-');
            var payingamount = $('[name="payingamount-'+row_num[1]+'"]').val();
            if(typeof payingamount !== 'undefined'){
               totalpaidamt += +payingamount;
            }
         });
         $('#paidamount').val(totalpaidamt.toFixed(2));
         $("#paidamount").valid();
         /* if(totalpaidamt==0.00){
            $('#paidamount').val('');
         } */
      }
      /* Payment Entry > rule for paying amount column */
      function lessThanPendingAmount(){
         $('.bill_grid').each(function(){
            var row_num = $(this).attr('id').split('-');
            $('input[name="payingamount-'+row_num[1]+'"]').rules("add", {
               lessThanPendingAmt: "#pendingamount-"+row_num[1],
                required:true,
            });
         });
      }
      /* Payment Entry > total paying amount */
      function totalPayingAmount(){
         $('.bill_grid').each(function(){
            var row_num = $(this).attr('id').split('-');
            $('input[name="payingamount-'+row_num[1]+'"]').on("keyup", function() {
               totalPaidAmount();
            });
         });
      }
      $(document).on("click","#billReturnDetID",function() {
         $("#PBillInfo").modal('show');
         $("td#ttlInvoiceAmt").text($(this).attr('data-netamount'));
         //$("td#ttlReturnAmt").text($(this).attr('data-returnAmt'));
         $("td#ttlReturnAmt").html($(this).attr('data-returnAmt'));
          $("td#ttlPayingAmt").text($(this).attr('data-pendingamt'));
      });
   });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/payment_entry/form.blade.php ENDPATH**/ ?>