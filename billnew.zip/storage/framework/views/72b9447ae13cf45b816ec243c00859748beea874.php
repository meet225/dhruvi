<?php $__env->startSection('styles'); ?>
    <!-- Datatable -->
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-rowgroup-bs4/dataTables.rowgroup.bootstrap4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-scroller-bs4/dataTables.scroller.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-select-bs4/dataTables.select.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1 class="page-title">Bill List</h1>
        <?php echo e(Breadcrumbs::render('admin.bills.index')); ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bill_add')): ?>
            <div class="page-header-actions">
                <a class="btn btn-sm btn-primary btn-round" href="<?php echo e(route("admin.bills.create")); ?>">
                    Add Bill
                </a>
            </div>
        <?php endif; ?>
    </div>
   
        <div class="per_export"></div>
  
        <div class="per_print"></div>
  
    <div class="page-content">
        <div class="panel">
            <div class="panel-body">
                <table class="table table-bordered table-hover dataTable w-full" id="datatable-List">
                    <thead>
                    <tr>
                        <th class="all">Created_at</th>
                        <th class="all">
                            Bill Code
                        </th>
                        <th class="all">
                            Bill Date & Time
                        </th>
                        <th class="all">
                            Customer Name
                        </th>
                        <th class="all">
                            Grand Total
                        </th>
                        <th class="all">
                            Discount
                        </th>
                        <th class="all">
                            Other Charges
                        </th>
                        <th class="all">
                            Round Off
                        </th>
                        <th class="min-desktop">
                            Net Amount
                        </th>
                        <!-- <th class="min-desktop">
                            Paid Amount
                        </th>
                        <th class="min-desktop">
                            Pending Amount
                        </th> -->

                        <th class="min-desktop">
                            Action
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Datatable -->
    <script src="<?php echo e(asset('global/vendor/datatables.net-bs4/dataTables.config.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-rowgroup-bs4/dataTables.rowGroup.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-scroller-bs4/dataTables.scroller.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-responsive-bs4/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/buttons.html5.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/buttons.flash.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/buttons.print.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/buttons.colVis.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/datatables.net-buttons-bs4/buttons.bootstrap4.min.js')); ?>"></script>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bill_delete')): ?>
    <?php endif; ?>
    <!-- Bootbox -->
    <script src="<?php echo e(asset('global/vendor/bootbox/bootbox.min.js')); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(function(){
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
            $.extend(true, $.fn.dataTable.defaults, {
                order: [[ 1, 'desc' ]]
            });

            columns_arr=[];
            columns_arr.push(
                {data:'created_at', name:'created_at',visible :false,searchable: false},
                {data:'billcode', name:'billcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'billdatetime', name:'billdatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'customer', name:'customer',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'grandtotal', name:'grandtotal',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'discamt', name:'discamt',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'othercharges', name:'othercharges',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'roundoff', name:'roundoff',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                /*{data:'paidamount', name:'paidamount',orderable: false,defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
                {data:'pendingamount', name:'pendingamount',orderable: false,defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},*/
                {data: 'action', name: 'action', orderable: false, searchable: false},
            );

            var table = $('#datatable-List').DataTable({
                buttons: dtButtons,
                responsive:true,
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin.bills.index')); ?>",
                columns: columns_arr,
                'createdRow': function( row, data, dataIndex ) {
                    $(row).attr('data-entry-id',data.purchasebillid);
                },
            });

            $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/purchase_bills/index.blade.php ENDPATH**/ ?>