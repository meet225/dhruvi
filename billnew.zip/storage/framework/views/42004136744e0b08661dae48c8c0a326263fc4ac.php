<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/flatpickr/flatpickr.min.css')); ?>">
    <style type="text/css">
        .modal-open .select2-container {
            z-index: 0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1 class="page-title">View Purchase Bill</h1>
        <?php echo e(Breadcrumbs::render('admin.bills.show',$Bill,$Bill->billcode)); ?>

    </div>
    <div class="page-content">
            <form method="POST" action='<?php echo e(route("admin.bills.update", [$Bill->id])); ?>' id="hms_form" autocomplete="off">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('billcode') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="billcode">Bill Code<span class="required">*</span></label>
                                            <?php if(isset($Bill)): ?>
                                                <input class="form-control" type="text" name="billcode" id="billcode" value="<?php echo e(old('billcode', @$Bill->billcode)); ?>" maxlength="100" readonly>
                                            <?php endif; ?>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('billcode')): ?>
                                                    <?php echo e($errors->first('billcode')); ?>

                                                <?php endif; ?>
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('billdatetime') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="billdatetime"><b>Bill Date & Time</b><span class="required">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="icon md-calendar" aria-hidden="true"></i>
                                                </span>
                                                <?php if(isset($Bill->billdatetime)): ?>
                                                   <input class="form-control" type="text" name="billdatetime" id="billdatetime" value="<?php echo e(date('d-m-Y H:i', strtotime($Bill->billdatetime))); ?>" disabled>
                                                <?php endif; ?>
                                            </div>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('billdatetime')): ?>
                                                    <?php echo e($errors->first('billdatetime')); ?>

                                                <?php endif; ?>
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('customerid') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="customerid">Customer Name<span class="required">*</span></label>
                                            <select class="form-control select2" name="customerid" id="customerid">
                                                <?php if(isset($Bill)): ?>
                                                   <option value="<?php echo e(@$Bill->customerid); ?>" selected=""><?php echo e(@$Bill->customer->name); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('customerid')): ?>
                                                    <?php echo e($errors->first('customerid')); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-12">
                                        <div class="card border border-info hms_card_primary">
                                            <div class="card-header card-header-transparent card-header-bordered bg-info pt-5 pb-5">
                                                <div class="row">
                                                    <div class="col-md-6 line_height_30">
                                                        Items
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-block">
                                                <div class="table-responsive" id="poItemsTbl"></div>
                                                <div class="table-responsive" id="grnItemsTbl"></div>
                                                <div class="table-responsive" id="directItemsTbl">
                                                    <table class="table table-bordered" id="tbl_hms" style="width: 100%">
                                                        <thead>
                                                            <tr>
                                                               <th style="width: 20%;">Item Name<span class="required">*</span></th>
                                                                <th style="width: 5%;">Days<span class="required">*</span></th>
                                                                <th style="width: 5%;">Qty<span class="required">*</span></th>
                                                                
                                                                <th style="width: 5%;">Rate<span class="required">*</span></th>
                                                                <th style="width: 10%;">Total<span class="required">*</span></th>
                                                                <th>Action</th>
                                                                
                                                            </tr>
                                                            </thead>
                                                            <tbody id="tbl_hms_body" data-module="purchase_bill">
                                                        <?php if(isset($Bill)): ?>
                                                              <?php $__currentLoopData = $Bill->billdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="item_grid" id="row-<?php echo e($key); ?>">
                                                                        
                                                                        <td>
                                                                            <select class="form-control itemid" name="itemid-<?php echo e($key); ?>" id="itemid-<?php echo e($key); ?>" style="width: 250px;" disabled>
                                                                                <?php if($details->item): ?>
                                                                                    <option selected="" value="<?php echo e($details->itemid); ?>"><?php echo e($details->item->name); ?></option>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>

                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="days-<?php echo e($key); ?>" id="days-<?php echo e($key); ?>" class="form-control allow_number" maxlength="3" value="<?php echo e($details->days); ?>" style="width: 200px;" readonly="">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="hidden" name="oldqty-<?php echo e($key); ?>" id="oldqty-<?php echo e($key); ?>" class="form-control" value="<?php echo e($details->qty); ?>">
                                                                            <input type="text" name="qty-<?php echo e($key); ?>" class="form-control allow_number" maxlength="10" value="<?php echo e($details->qty); ?>" style="width: 100px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="rate-<?php echo e($key); ?>" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e($details->rate); ?>" style="width: 150px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="totalamount-<?php echo e($key); ?>" class="form-control totalamount" readonly value="<?php echo e($details->netamount); ?>" style="width: 170px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td>
                                                                            <input type="hidden" name="id-<?php echo e($key); ?>" value="<?php echo e($details->id); ?>">
                                                                            
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="item_grid" id="row-0">
                                                                <td>
                                                                    <div class="checkbox-custom checkbox-primary">
                                                                        <input type="checkbox" class="gridChkRow">
                                                                        <label for="gridChkRow"></label>
                                                                    </div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <select class="form-control itemid" name="itemid-0" id="itemid-0" style="width: 250px;">
                                                                    </select>
                                                                    <div class="invalid-feedback"></div>
                                                                </td>  
                                                                <td class="hms_td_row">
                                                                   <input type="text" name="days-0" class="form-control allow_number" maxlength="3" value="" style="width: 200px;">
                                                                   <div class="invalid-feedback"></div>
                                                               </td>                        
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="qty-0" class="form-control allow_number" maxlength="10" style="width: 100px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row" style="width:350px;">
                                                                    <input type="text" name="rate-0" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="totalamount-0" class="form-control totalamount" id="totalamount-0" readonly style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                
                                                                <td></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <div class="panel">
                                    <div class="panel-body totalgrid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="grandtotal" class="col-sm-4 form-control-label">Grand Total <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="<?php echo e(old('discper', @$Bill->grandtotal)); ?>" readonly>
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('grandtotal')): ?>
                                                                <?php echo e($errors->first('grandtotal')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="discount" class="col-sm-4 form-control-label">Discount : </label>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="5" data-afterdecimal="2" value="<?php echo e(old('discper', @$Bill->discper)); ?>" readonly>
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <b class="float-right">%</b>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e(old('discamt', @$Bill->discamt)); ?>" placeholder="Amt" readonly>
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="othercharges" class="col-sm-4 form-control-label">Other Charges : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e(old('othercharges', @$Bill->othercharges)); ?>" readonly>
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('othercharges')): ?>
                                                                <?php echo e($errors->first('othercharges')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="roundoff" class="col-sm-4 form-control-label">Round Off : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="<?php echo e(old('roundoff', @$Bill->roundoff)); ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="netamount" class="col-sm-4 form-control-label">Net Amount <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="<?php echo e(old('netamount', @$Bill->netamount)); ?>" readonly>
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('netamount')): ?>
                                                                <?php echo e($errors->first('netamount')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container">
                                <div class="row justify-content-center">
                                    
                                    <div class="p-1">
                                        <a href="<?php echo e(url('admin/bills')); ?>" class="btn btn-secondary waves-effect waves-classic">
                                            Cancel
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('global/vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/flatpickr/flatpickr.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/inventory.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            <?php if(isset($Bill)): ?>
                $( "#billdatetime" ).flatpickr({
                    enableTime: true,
                    time_24hr: true,
                    dateFormat: session_obj.hospital.branch_settings.select_date_pattern+' H:i',
                });

                $('#documenttype').select2({disabled: true});
                $('#deptid').select2({disabled: true});
                $('#customerid').select2({disabled: true}); 
                $('#taxation').select2({disabled: true}); 

                <?php if($Bill->documenttype == 'PO'): ?>
                $('.gridChkDelete').css("display",'none');
                $('#addToTable').css("display",'none');
                $('.delete-record').css("display",'none');
                <?php endif; ?>

                <?php if($Bill->documenttype == 'GRN'): ?>
                $('.gridChkDelete').css("display",'none');
                $('#addToTable').css("display",'none');
                $('.delete-record').css("display",'none');
                $('.totalgrid').css("pointer-events",'none');
                <?php endif; ?>

            <?php endif; ?>

            $('.selBtnPO').attr('disabled','disabled');
            $('.selBtnGRN').attr('disabled','disabled');
            $('.select2').select2();

            /******* Item Grid ************/
            $('#expirydate-0').flatpickr({
                dateFormat: session_obj.hospital.branch_settings.select_date_pattern,
                minDate: new Date(),
                allowInput:true
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/purchase_bills/view.blade.php ENDPATH**/ ?>