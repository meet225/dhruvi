
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Edit Customer</h1>
    <?php echo e(Breadcrumbs::render('admin.customers.edit',$customer,$customer->name)); ?>

</div>
<div class="page-content">
    <div class="panel">
        <div class="panel-body">
        <form method="POST" id="hms_form" action="<?php echo e(route("admin.customers.update", [$customer->id])); ?>" enctype="multipart/form-data" autocomplete="off">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('name') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="name"><?php echo e(trans('cruds.user.fields.name')); ?><span class="required">*</span></label>
                        <input class="form-control" type="text" name="name" id="name" value="<?php echo e(old('name', $customer->name)); ?>" maxlength="50">
                        <div class="invalid-feedback">
                            <?php if($errors->has('name')): ?>
                            <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                        </div>
                        <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('address') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="address">Address<span class="required">*</span></label>
                        <input class="form-control" type="text" name="address" id="address" value="<?php echo e(old('address', $customer->address)); ?>" maxlength="200">
                        <div class="invalid-feedback">
                            <?php if($errors->has('address')): ?>
                            <?php echo e($errors->first('address')); ?>

                            <?php endif; ?>
                        </div>
                        <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('village') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="village">Village<span class="required">*</span></label>
                        <input class="form-control" type="text" name="village" id="village" value="<?php echo e(old('village', $customer->village)); ?>" maxlength="50">
                        <div class="invalid-feedback">
                            <?php if($errors->has('village')): ?>
                            <?php echo e($errors->first('village')); ?>

                            <?php endif; ?>
                        </div>
                        <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('in_care_of') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="in_care_of">C/O<span class="required">*</span></label>
                        <input class="form-control" type="text" name="in_care_of" id="in_care_of" value="<?php echo e(old('in_care_of', $customer->in_care_of)); ?>" maxlength="50">
                        <div class="invalid-feedback">
                            <?php if($errors->has('in_care_of')): ?>
                            <?php echo e($errors->first('in_care_of')); ?>

                            <?php endif; ?>
                        </div>
                        <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
                    </div>
                </div>
               
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('mobile_no') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="mobile_no"><?php echo e(trans('cruds.user.fields.mobile_no')); ?><span class="required">*</span></label>
                        <input class="form-control us_phone_number" type="text" name="mobile_no" id="mobile_no" value="<?php echo e(old('mobile_no',$customer->mobile_no)); ?>" maxlength="12" autocomplete="none">
                        <div class="invalid-feedback">
                            <?php if($errors->has('mobile_no')): ?>
                            <?php echo e($errors->first('mobile_no')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group form-material <?php echo e($errors->has('status') ? 'has-danger' : ''); ?>">
                        <label class="form-control-label" for="status"><?php echo e(trans('cruds.user.fields.status')); ?><span class="required">*</span></label>
                        <select class="form-control select2" name="status" id="status">
                            <option value="0" <?php echo e((old('status',$customer->status)==0) ? 'selected' : ''); ?>>InActive</option>
                            <option value="1" <?php echo e((old('status',$customer->status)==1) ? 'selected' : ''); ?>>Active</option>
                        </select>
                        <div class="invalid-feedback">
                            <?php if($errors->has('status')): ?>
                            <?php echo e($errors->first('status')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="p-1">
                            <button class="btn btn-primary waves-effect waves-classic" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>  
                        <div class="p-1">
                            <a href="<?php echo e(url('admin/customers')); ?>" class="btn btn-secondary waves-effect waves-classic">
                                Cancel
                            </a>
                        </div>                          
                    </div>
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('global/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/jquery-validate/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('global/vendor/jquery-validate/additional-methods.min.js')); ?>"></script>
<script type="text/javascript">
    $('.select2').select2();
    $('.select2').on('change', function() {
        $(this).valid();
    });
    $("#hms_form").validate({
        rules: {
            name: {
               required: true,
               minlength:3
            },
            address: {
               required: true,
               minlength:3
            },
            village: {
               required: true,
               minlength:3
            },
            status:{
               required: true
            }
        },
        messages: {
            mobile_no: {
                minlength: "Please enter valid mobile number",
            }
       },
        errorPlacement: function (error, element){
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            error.appendTo($placement);
            $placement.show();
        },
        highlight: function(element, errorClass, validClass) {
            $(element).parent().addClass('has-danger').removeClass('has-success');
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            $placement.show();
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).parent().removeClass('has-danger').addClass('has-success');
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            $(element).removeClass('error');
            $placement.hide();
        }
   });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>