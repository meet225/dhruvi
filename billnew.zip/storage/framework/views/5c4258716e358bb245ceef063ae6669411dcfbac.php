<!DOCTYPE html>
<html style="background-color: #d7ca6acc;">
<head>
	<title>Bill</title>
	<style>

	    @page  { margin: <?php echo e($page_margin); ?>; }
	</style>
	<link rel="stylesheet" href="<?php echo e(public_path('assets/css/print.css')); ?>">
</head>
<body >
	<!-- Header -->
	<div id="header">
   		<?php echo $__env->make('paymentbillprint.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<!-- Footer -->
	<div id="footer">
	   <?php echo $__env->make('paymentbillprint.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<!-- Main Content -->
	<div id="content">
		<table id="charge_detail" class="table" cellspacing="0" style="margin-bottom: 20px;">
	    	<thead class="border-bottom">
	    		<tr>
	    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
	    			<th style="text-align: center;" class="pb-10">Bill Code</th>
	    			<th style="text-align: center;" class="pb-10">Bill Date</th>
		    		<th style="text-align: center;" class="pb-10">Paying Amount</th>
	    		</tr>
	    	</thead>
	    	<tbody>
	    		<?php if($payment->details): ?>
	    			<?php $sr=1 ?>
		    		<?php $__currentLoopData = $payment->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpdetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    		<tr class="align-center">
			    		<td class="border-bottom"><?php echo e($sr); ?></td>
			    		<td class="border-bottom"><?php echo e($cpdetails->bill->billcode); ?></td>
			    		<td class="border-bottom"><?php echo e(date('d-m-Y H:i', strtotime($cpdetails->bill->billdatetime))); ?></td>
			    		<td class="border-bottom"><?php echo e($cpdetails->payingamount); ?></td>
		    		</tr>
		    		<?php $sr++ ?>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	<?php else: ?>
		    		<tr>No data found.</tr>
		    	<?php endif; ?>
	    	</tbody>
	    </table>

		<table class="table pt-10 pb-10">
			<tbody>
				<tr>
					<?php
						$f = new \NumberFormatter( locale_get_default(), \NumberFormatter::SPELLOUT );
						$word = $f->format($payment->paidamount);
					?>
					<th>The sum of Rupees</th>
					<td class="border-bottom float-left sumofrupees"><?php echo e(ucwords($word)); ?> by <strong><?php echo e($payment->paymentmode); ?> Payment</strong></td>
				</tr>
				<?php if($payment->paymentmode == 'Debit Card' || $payment->paymentmode == 'Credit Card'): ?>
					<?php
				        $trancdate = date('d-m-Y H:i', strtotime($payment->transactiondate));
				     ?>
					<tr>
						<th>Payment Details</th>
						<td class="border-bottom float-left sumofrupees"><strong>Transaction No. </strong><?php echo e($payment->transactionno); ?>, <strong>Transaction Date</strong> : <?php echo e($trancdate); ?>, <strong><br>Bank Name</strong> : <?php echo e($payment->bankname); ?></td>
					</tr>
				<?php elseif($payment->paymentmode == 'Cheque'): ?>
					<?php
				        $trancdate = date('d-m-Y H:i', strtotime($payment->transactiondate));
				    ?>
					<tr>
						<th>Payment Details</th>
						<td class="border-bottom float-left sumofrupees"><strong>Cheque No. </strong><?php echo e($payment->transactionno); ?>, <strong>Cheque Date</strong> : <?php echo e($trancdate); ?>, <strong><br>Bank Name</strong> : <?php echo e($payment->bankname); ?></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>

		<table class="table mt-10">
			<tbody>
				<tr>
					<td class="border float-left receiptamt"><strong>Rs. <?php echo e($payment->paidamount); ?></strong></td>
					<td></td>
					<td style="width: 20%;height: 70px;border:1px solid #000;"></td>
				</tr>
				<tr>
					<td class="float-left font-size-13"><strong>*Payment by cheque subject to realization.</strong></td>
					<td></td>
					<td class="float-right font-size-14"><strong>Receiver's Signature</strong></td>
				</tr>
			</tbody>
		</table>
	</div>	
</body>
</html><?php /**PATH C:\xampp\htdocs\bill\resources\views/paymentbillprint/bill.blade.php ENDPATH**/ ?>