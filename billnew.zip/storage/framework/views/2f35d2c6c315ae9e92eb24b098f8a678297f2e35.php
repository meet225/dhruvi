
<?php $__env->startSection('content'); ?>
<div class="panel">
  <div class="panel-body">
    <div class="brand hms_brand">
      <!-- <img class="brand-img" src="<?php echo e(asset('assets/images/icon-2.png')); ?>" alt="..."> -->
      <span>ANTRIX SUPPLIRES</span>
      <!-- <h2 class="brand-text font-size-18">
          <?php echo e(trans('panel.site_tag')); ?>

      </h2> -->
    </div>
    <form method="post" action="<?php echo e(route('login')); ?>" autocomplete="off" id="hms_form">
      <?php echo csrf_field(); ?>
      <div class="form-group form-material floating <?php echo e($errors->has('email') ? 'has-danger' : ''); ?>" data-plugin="formMaterial">
        <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email', null)); ?>" required/>
        <label class="floating-label form-control-label"><?php echo e(trans('global.login_email')); ?><span class="required">*</span></label>
        <div class="invalid-feedback">
        <?php if($errors->has('email')): ?>
          <?php echo e($errors->first('email')); ?>

        <?php endif; ?>
        </div>
      </div>
      <div class="form-group form-material floating <?php echo e($errors->has('password') ? 'has-danger' : ''); ?>" data-plugin="formMaterial">
        <input id="password" name="password" type="password"  class="form-control" required/>
        <label class="floating-label form-control-label">Password<span class="required">*</span></label>
        <div class="invalid-feedback">
        <?php if($errors->has('password')): ?>
          <?php echo e($errors->first('password')); ?>

        <?php endif; ?>
        </div>
      </div>
      <div class="form-group clearfix">
        <div class="checkbox-custom checkbox-inline checkbox-primary checkbox-lg float-left">
          <input name="remember" type="checkbox" id="remember">
          <label for="remember"><?php echo e(trans('global.remember_me')); ?></label>
        </div>
        <?php if(Route::has('password.request')): ?>
            <a class="float-right" href="<?php echo e(route('password.request')); ?>"><?php echo e(trans('global.forgot_password')); ?></a>
        <?php endif; ?>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg mt-40"><?php echo e(trans('global.login')); ?></button>
    </form>
    <!-- <p>Still no account? Please go to <a href="register-v3.html">Sign up</a></p> -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('global/vendor/jquery-validate/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript">
$("#hms_form").validate({
  rules: {
      email: {
        email:true,
        required: true,
        minlength:3
      },
      password: {
        required: true,
        minlength:6
      },
  },
  errorPlacement: function (error, element){
      $placement=$(element).parent().find('.invalid-feedback');
      error.appendTo($placement);
      $placement.show();
  },
  highlight: function(element, errorClass, validClass) {
      $(element).parent().addClass('has-danger').removeClass('has-success');
      $placement=$(element).parent().find('.invalid-feedback');
      $placement.show();
  },
  unhighlight: function(element, errorClass, validClass) {
      $(element).parent().removeClass('has-danger').addClass('has-success');
      $placement=$(element).parent().find('.invalid-feedback');
      $(element).removeClass('error');
      $placement.hide();
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/auth/login.blade.php ENDPATH**/ ?>