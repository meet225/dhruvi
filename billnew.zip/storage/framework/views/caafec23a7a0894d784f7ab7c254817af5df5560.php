<table class="table table-bordered" id="tbl_hms">
   <thead>
      <tr>
         <th width="300">Bill Code</th>
         <th width="200">Bill Date</th>
         <th>Bill Amount</th>
         <th>Pending Amount</th>
         <th>Paid Amount</th>
         <th>Paying Amount<span class="required">*</span></th>
      </tr>
   </thead>
   <tbody>
      <?php if(!$bill->isEmpty()): ?>
      <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$billdetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
         //echo "<pre>";print_r($billdetails->toArray());
         $invoiceamount = number_format($billdetails->netamount, 2, '.', '');
         $pendingamount = number_format($billdetails->pendingAmount, 2, '.', '');
         $paidAmount = number_format($billdetails->paidAmount, 2, '.', '');
      ?>

      <tr class="bill_grid" id="row-<?php echo e($key); ?>">
         <input type="hidden" name="purchasebillid-<?php echo e($key); ?>" value="<?php echo e($billdetails->id); ?>">
         <td width="300">
            <div class="d-flex">
               <input type="text" class="form-control" name="invoicecode-<?php echo e($key); ?>" value="<?php echo e($billdetails->billcode); ?>" readonly>
            </div>
            <div class="invalid-feedback"></div>
         </td>
         <td width="200">
            <input type="text" class="form-control" name="invoicedatetime-<?php echo e($key); ?>"  value="<?php echo e(date('d-m-Y H:i', strtotime($billdetails->billdatetime))); ?>" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" name="invoiceamount-<?php echo e($key); ?>" value="<?php echo e($invoiceamount); ?>" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" name="pendingamount-<?php echo e($key); ?>" value="<?php echo e($pendingamount); ?>" id="pendingamount-<?php echo e($key); ?>" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" id ="paidAmount-<?php echo e($key); ?>" value="<?php echo e($paidAmount); ?>" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" name="payingamount-<?php echo e($key); ?>" id="payingamount-<?php echo e($key); ?>" value="0.00">
            <div class="invalid-feedback"></div>
         </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <tr>
         <td colspan="6" style="text-align: center;">No data found.</td>
      </tr>
   <?php endif; ?>
   <?php //exit; ?>
   </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/payment_entry/bill_detail.blade.php ENDPATH**/ ?>