<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHInvpaymententryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('h_invpaymententry', function (Blueprint $table) {
            $table->bigIncrements('invpaymententryid');
            $table->string('paymentcode',100);
            $table->string('paymentcodeid',255);
            $table->dateTime('paymentdatetime');
            $table->uuid('partyid')->nullable();
            /*$table->decimal('payingamount',65,2)->nullable();*/
            $table->decimal('paidamount',65,2)->nullable();
            $table->string('paymentmode',150)->nullable();
            $table->string('transactionno',100)->nullable();
            $table->date('transactiondate')->nullable();
            $table->string('bankname',100)->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->char('stats_flag',1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('h_invpaymententry');
    }
}
