<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDBillsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_bills', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('billid');           
            $table->bigInteger('itemid')->nullable();
            $table->string('days')->nullable();
            $table->bigInteger('qty')->nullable();
            $table->decimal('rate',65,2)->nullable();
            $table->decimal('netamount',65,2)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_bills');
    }
}
