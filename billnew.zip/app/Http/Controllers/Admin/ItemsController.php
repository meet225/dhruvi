<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Item\MassDestroyItemRequest;
use App\Http\Requests\Item\StoreItemRequest;
use App\Http\Requests\Item\UpdateItemRequest;
use App\Models\Item;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use DataTables;

class ItemsController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('item_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if($request->ajax()) {
            $data=Item::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })
                ->addColumn('action', function ($row) {
                    $url = url('admin/items/' . $row->id);
                    $btn  = "";
                    /*if(\Gate::allows('item_show')){
                        $btn .= '<a href="' . $url . '" class="btn btn-info btn-xs">View</a> ';
                    }*/
                    if(\Gate::allows('item_edit')){
                        $btn .= '<a href="' . $url . '/edit" class="btn btn-primary btn-xs">Edit</a> ';
                    }
                    if(\Gate::allows('item_delete')){
                        $btn .= '<a href="' . $url . '" class="delete_row btn btn-danger btn-xs ">Delete</a>';
                    }
                    return $btn;
                })->editColumn('status', function ($row) {
                    if($row->status==1)
                        return '<span class="badge badge-success ml-1">Active</span>';
                    else
                        return '<span class="badge badge-secondary ml-1">InActive</span>';
                })
                ->rawColumns(['action','status'])
                ->make(true);
        }

        return view('admin.items.index');
    }

    public function create()
    {
        abort_if(Gate::denies('item_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.items.create');
    }

    public function store(StoreItemRequest $request)
    {   
        $insert_data = $request->all();
        Item::create($insert_data);
        return redirect()->route('admin.items.index')->with('message', 'Item added successfully.');

    }

    public function edit(Item $item)
    {
        abort_if(Gate::denies('item_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.items.edit', compact('item'));
    }

    public function update(UpdateItemRequest $request, Item $item)
    {
        $item->update($request->all());
        return redirect()->route('admin.items.index')->with('message', 'Item updated successfully.');
    }

    public function show(Item $item)
    {
        abort_if(Gate::denies('item_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.items.show', compact('Item'));
    }

    public function destroy(Item $item)
    {
        abort_if(Gate::denies('item_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if($item->delete()){
            return response()->json([
                'status' => true,
                'message' => 'Record deleted successfully!',
            ]);
        }
        response()->json([
            'status' => false,
            'message' => 'Record not deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyItemRequest $request)
    {
        Item::whereIn('id', request('ids'))->delete();
        return response()->json([
                'status' => true,
                'message' => 'Records deleted successfully!',
            ]);
        /*return response(null, Response::HTTP_NO_CONTENT);*/
    }
}
