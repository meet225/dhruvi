<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Bill;
use App\Models\BillDetail;
use App\Models\PaymentEntry;
use App\Models\PaymentEntryDetail;
use PDF;
use DB;

class PrintBillController extends Controller
{
	public function index(Request $request)
    {
    	$Bill = Bill::where('id',$request->id)->first();
       
    	$page_margin = '180px 50px';
        $payment =PaymentEntry::select('h_invpaymententry.paymentcode','h_invpaymententry.paymentdatetime','d_invpaymententry.payingamount')->leftJoin('d_invpaymententry', 'h_invpaymententry.invpaymententryid', '=', 'd_invpaymententry.invpaymententryid')->where('d_invpaymententry.billid',$request->id)->get();
        $pdf=PDF::loadView('billprint.bill',compact('page_margin','Bill','payment'));
        $print_title = 'Bill-'.$Bill->customer->name.'-'.time();
        return $pdf->stream($print_title.'.pdf');
    }
}