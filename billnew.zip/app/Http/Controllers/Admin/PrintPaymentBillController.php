<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Bill;
use App\Models\BillDetail;
use App\Models\PaymentEntry;
use App\Models\PaymentEntryDetail;
use PDF;
use DB;

class PrintPaymentBillController extends Controller
{
	public function index(Request $request)
    {
    	
    	$page_margin = '180px 50px';
        $payment =PaymentEntry::where('invpaymententryid',$request->id)->first();
        $pdf=PDF::loadView('paymentbillprint.bill',compact('page_margin','payment'));
        $print_title = 'Payment-Bill-'.$payment->customer->name.'-'.time();
        return $pdf->stream($print_title.'.pdf');
    }
}