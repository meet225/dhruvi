<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \App\Traits\UserActionsBy;
use Illuminate\Database\Eloquent\SoftDeletes;
class CodeGeneration extends Model
{
    use SoftDeletes;

    public $table = 'm_codegeneration';
    protected $primaryKey = 'codeid'; 

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'typeid',
        'pattern',
        'startmonth',
        'startwith',
        'leadingzero',
        'tags_separator',
        'status',
        'hospid',
    ];
}
