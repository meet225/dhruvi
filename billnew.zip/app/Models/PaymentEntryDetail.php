<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \App\Traits\UserActionsBy;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentEntryDetail extends Model
{
    use SoftDeletes;
    public $table = 'd_invpaymententry';
    protected $primaryKey = 'invpaymententrydetailid';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'invpaymententryid',
        'billid',
        'invoiceamount',
        'payingamount',
        'hospid'
    ];
    public function bill()
    {
        return $this->hasOne(Bill::class,'id','billid');
    }
}
