<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;
class Bill extends Model
{
    use SoftDeletes;

    public $table = 'bills';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'billcode',
        'billcodeid',
        'billdatetime',
        'customerid',
        'grandtotal',
        'discper',
        'discamt',
        'othercharges',
        'roundoff',
        'netamount',
        'billpay',
        'created_at',
        'updated_at',
        'deleted_at',
    ];


    public function customer()
    {
        return $this->hasOne(Customer::class,'id','customerid');
    }

    public function billdetails()
    {
        return $this->hasMany(BillDetail::class,'billid','id')->orderBy('created_at','asc');
    }
}
