<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \App\Traits\UserActionsBy;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentEntry extends Model
{
    use SoftDeletes;
    public $table = 'h_invpaymententry';
    protected $primaryKey = 'invpaymententryid';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'paymentcode',
        'paymentcodeid',
        'paymentdatetime',
        'partyid',
        'paidamount',
        'paymentmode',
        'transactionno',
        'transactiondate',
        'bankname',
        'hospid'
    ];

    public function customer()
    {
        return $this->hasOne(Customer::class,'id','partyid');
    }

    public function details()
    {
        return $this->hasMany(PaymentEntryDetail::class,'invpaymententryid')->orderBy('created_at','asc');
    }
}
