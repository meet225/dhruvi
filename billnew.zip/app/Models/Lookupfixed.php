<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lookupfixed extends Model
{
	public $table = 'm_lookupfixed';
	public $timestamps = false;
}
