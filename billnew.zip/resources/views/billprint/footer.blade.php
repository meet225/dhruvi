<table class="table mt-0" style="background-color: #d76a83; color: #fff;">
	<thead>
    <tr>
      <th colspan="2" style="text-align: center; font-family: cursive !important;">Turning your dreams into reality....</th>
    </tr>
  </thead>
	<tbody>
		<tr>
			<td class="align-left"><strong>Email: antrixsuppliers@yahoo.com</strong></td>
			<td class="align-right"><strong>Web: www.antrixsuppliers.in</strong></td>
		</tr>
	</tbody>
</table>