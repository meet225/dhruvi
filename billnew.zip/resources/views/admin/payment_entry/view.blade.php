@extends('layouts.admin')
@section('styles')
    <link rel="stylesheet" href="{{ asset('global/vendor/select2/select2.min.css') }}">
    <style type="text/css">
        .modal-open .select2-container {
            z-index: 0;
        }
    </style>
@endsection
@section('content')
<div class="page-header">
    <h1 class="page-title">View Payment Entry</h1>
    {{ Breadcrumbs::render('admin.inventory.payment_entries.show',$payment_entry,$payment_entry->paymentcode) }}
</div>
<div class="page-content">
    <form method="GET">
        <div class="panel">
            <div class="panel-body">
                <div class="row">               
                    <div class="col-md-3">
                        <div class="form-group form-material {{ $errors->has('paymentcode') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="paymentcode">Payment Code<span class="required">*</span></label>
                            <input class="form-control" type="text" name="paymentcode" id="paymentcode" value="{{ old('paymentcode', @$payment_entry->paymentcode) }}" maxlength="100" readonly>
                            <div class="invalid-feedback">
                                @if($errors->has('paymentcode'))
                                {{ $errors->first('paymentcode') }}
                                @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('paymentdatetime') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="paymentdatetime"><b>Payment Date & Time</b><span class="required">*</span></label>
                            <div class="input-group">
                            <span class="input-group-addon">
                            <i class="icon md-calendar" aria-hidden="true"></i>
                            </span>
                            <input class="form-control" type="text" name="paymentdatetime" id="paymentdatetime" value="{{ old('paymentdatetime',display_datetime(['datetime' => $payment_entry->paymentdatetime,'select_datepattern' => TRUE])) }}" disabled>
                            </div>
                            <div class="invalid-feedback">
                                @if($errors->has('paymentdatetime'))
                                {{ $errors->first('paymentdatetime') }}
                                @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('partyid') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="partyid">Party/Vendor Name<span class="required">*</span></label>
                            <select class="form-control select2" name="partyid" id="partyid">
                                @if(isset($payment_entry))
                                    <option value="{{ @$payment_entry->partyid }}" selected="">{{ @$payment_entry->partyVendor->partyname }}</option>
                                @endif
                            </select>
                            <div class="invalid-feedback">
                                @if($errors->has('partyid'))
                                    {{ $errors->first('partyid') }}
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-12">
                        <div class="card border border-info hms_card_primary">
                            <div class="card-header card-header-transparent card-header-bordered bg-info">
                            Purchase Bill Details
                            </div>
                            <div class="card-block">
                            <div class="table-responsive" id="bill_detail_table">
                                
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('paymentmode') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="paymentmode">Payment Type<span class="required">*</span></label>
                            <select class="form-control select2 paymentmode" name="paymentmode" id="paymentmode">
                                <option value="{{ @$payment_entry->paymentmode }}" selected="">{{ @$payment_entry->paymentmode }}</option>
                            </select>
                            <div class="invalid-feedback">
                            @if($errors->has('paymentmode'))
                            {{ $errors->first('paymentmode') }}
                            @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('paidamount') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="paidamount">Paid Amount<span class="required">*</span></label>
                            <input class="form-control allow_decimal" type="text" name="paidamount" id="paidamount" value="{{ old('paidamount',@$payment_entry->paidamount) }}" data-beforedecimal="7" data-afterdecimal="2" readonly>
                            <div class="invalid-feedback">
                            @if($errors->has('paidamount'))
                            {{ $errors->first('paidamount') }}
                            @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                </div>
                <div class="row payment-details" style="display: none;">
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('transactionno') ? 'has-danger' : '' }}">
                            <label class="form-control-label numberlbl" for="transactionno"></label>
                            <input class="form-control transactionno" type="text" name="transactionno" value="{{ old('transactionno', @$payment_entry->transactionno) }}" maxlength="100">
                            <div class="invalid-feedback">
                            @if($errors->has('transactionno'))
                            {{ $errors->first('transactionno') }}
                            @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('transactiondate') ? 'has-danger' : '' }}">
                            <label class="form-control-label datelbl" for="transactiondate"></label>
                            <div class="input-group">
                            <span class="input-group-addon">
                            <i class="icon md-calendar" aria-hidden="true"></i>
                            </span>
                            <input class="form-control transactiondate" type="text" name="transactiondate" value="{{ old('transactiondate', '') }}">
                            </div>
                            <div class="invalid-feedback">
                            @if($errors->has('transactiondate'))
                            {{ $errors->first('transactiondate') }}
                            @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material {{ $errors->has('bankname') ? 'has-danger' : '' }}">
                            <label class="form-control-label" for="bankname">Bank Name<span class="required">*</span></label>
                            <input class="form-control bankname" type="text" name="bankname" value="{{ old('bankname', @$payment_entry->bankname) }}" maxlength="100">
                            <div class="invalid-feedback">
                            @if($errors->has('bankname'))
                            {{ $errors->first('bankname') }}
                            @endif
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="clearfix"></div>
            <div class="container">
               <div class="row justify-content-center">
                  <div class="p-1">
                     <a href="{{ url('admin/inventory/payment_entries') }}" class="btn btn-secondary waves-effect waves-classic">
                     Cancel
                     </a>
                  </div>
               </div>
            </div>
        </div>
    </form>
</div>
@endsection
@section('scripts')
    <script src="{{ asset('global/vendor/select2/select2.min.js')}}"></script>
    <script src="{{ asset('global/vendor/flatpickr/flatpickr.js')}}"></script>
    <script src="{{ asset('assets/js/inventory.js')}}"></script>
    <script type="text/javascript">

        $(document).ready(function(){
            @if(isset($payment_entry))
                $('#partyid').select2({disabled: true});
                $('#paymentmode').select2({disabled: true});

                // Purchase Bill detail section
                var partyid = "{{ $payment_entry->partyid }}";
                partyBillDetails(partyid);
                function partyBillDetails(partyid){
                    $.ajax({
                        url: "{{ route('admin.inventory.party-bills') }}",
                        type:'get',
                        dataType: 'json',
                        data: {
                            partyid : partyid,
                        },
                        success:function(data){
                        $('#bill_detail_table').html(data);
                        // recAmtValidate()
                       /*  totalPayingAmount()
                        lessThanPendingAmount(); */
                        // billDetSerSor();
                        }
                    });
                }
            @endif

        });
    </script>   
@endsection
