@extends('layouts.admin')
@section('styles')
<!-- Datatable -->
<link rel="stylesheet" href="{{asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('global/vendor/datatables.net-rowgroup-bs4/dataTables.rowgroup.bootstrap4.css')}}">
<link rel="stylesheet" href="{{ asset('global/vendor/datatables.net-scroller-bs4/dataTables.scroller.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{ asset('global/vendor/datatables.net-select-bs4/dataTables.select.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{ asset('global/vendor/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.min.css')}}">
@endsection
@section('content')
<div class="page-header">
  <h1 class="page-title">Payment Entry List</h1>
  {{ Breadcrumbs::render('admin.payment_entries.index') }}
  @can('payment_entry_add')
  <div class="page-header-actions">
    <a class="btn btn-sm btn-primary btn-round" href="{{ route("admin.payment_entries.create") }}">
      Add Payment Entry
    </a>
  </div>
  @endcan
</div>
@can('payment_entry_delete')
{{-- <div class="per_delete"></div> --}}
@endcan

<!-- datatable without action column in listing page -->
<div class="per_export noActionInList"></div>

<div class="per_print"></div>

<div class="page-content">
    <div class="panel">
        <div class="panel-body">
            <table class="table table-bordered table-hover dataTable w-full" id="datatable-List">
                <thead>
                    <tr>
                      @can('payment_entry_delete')
                        {{-- <th width="10">

                        </th> --}}
                         @endcan
                         <th>
                            Created_at
                        </th>
                        <th>
                          Payment Code
                        </th>
                        <th>
                          Payment Date & Time
                        </th>
                        <th>
                          Customer Name
                        </th>
                        <th>
                          Payment Type
                        </th>
                        <th>
                          Paid Amount
                        </th>
                        <th>
                          Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<!-- Datatable -->
<script src="{{asset('global/vendor/datatables.net-bs4/dataTables.config.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net/jquery.dataTables.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-bs4/dataTables.bootstrap4.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-rowgroup-bs4/dataTables.rowGroup.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-scroller-bs4/dataTables.scroller.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-responsive-bs4/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.min.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/buttons.html5.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/buttons.flash.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/buttons.print.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/buttons.colVis.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/pdfmake.min.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/vfs_fonts.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/jszip.min.js')}}"></script>
<script src="{{asset('global/vendor/datatables.net-buttons-bs4/buttons.bootstrap4.min.js')}}"></script>
@can('payment_entry_delete')
{{-- <script src="{{asset('global/vendor/datatables.net-select-bs4/dataTables.select.min.js')}}"></script> --}}
@endcan
<!-- Bootbox -->
{{-- <script src="{{asset('global/vendor/bootbox/bootbox.min.js')}}"></script> --}}
<script>
$(function(){
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
            @can('inv_purchase_bill_return_delete')
            @endcan
            $.extend(true, $.fn.dataTable.defaults, {
                order: [[ 1, 'desc' ]]
            });
    columns_arr=[];
    @can('payment_entry_delete')
        // columns_arr.push({data:'select_row', name:'select_row'});
    @endcan
    columns_arr.push(
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'paymentcode', name:'paymentcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'paymentdatetime', name:'paymentdatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'customer', name:'customer',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'paymentmode', name:'paymentmode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'paidamount', name:'paidamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},          
          {data: 'action', name: 'action', orderable: false, searchable: false},
    );

    var table = $('#datatable-List').DataTable({ 
      buttons: dtButtons,
      responsive:true,
      processing: true,
      serverSide: true,
      ajax: "{{ route('admin.payment_entries.index') }}",
      columns: columns_arr,
      'createdRow': function( row, data, dataIndex ) {
        $(row).attr('data-entry-id',data.invpaymententryid);
      },
    }).on('click', '.delete_row', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');

        bootbox.dialog({
          message: "Are you sure you want to delete this record ?",
          title: "Confirm delete",
          buttons: {
            danger: {
              label: "Confirm",
              className: "btn-danger",
              callback: function callback() {
                $.ajax({
                    url:url ,
                    type: 'DELETE',
                    dataType: 'json',
                    data: {method: '_DELETE', "_token": "{{ csrf_token() }}"}
                }).always(function (data) {
                    table.draw();
                    toastrSuccess('',data.message);
                });
              }
            },
            main: {
              label: "Cancel",
              className: "btn-primary"
            }
          }
        });
    });

    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
});
</script>
@endsection