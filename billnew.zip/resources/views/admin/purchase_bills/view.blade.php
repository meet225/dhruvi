@extends('layouts.admin')
@section('styles')
    <link rel="stylesheet" href="{{ asset('global/vendor/select2/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('global/vendor/flatpickr/flatpickr.min.css')}}">
    <style type="text/css">
        .modal-open .select2-container {
            z-index: 0;
        }
    </style>
@endsection
@section('content')
    <div class="page-header">
        <h1 class="page-title">View Purchase Bill</h1>
        {{ Breadcrumbs::render('admin.bills.show',$Bill,$Bill->billcode) }}
    </div>
    <div class="page-content">
            <form method="POST" action='{{ route("admin.bills.update", [$Bill->id]) }}' id="hms_form" autocomplete="off">
                @method('PUT')
                @csrf
                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group form-material {{ $errors->has('billcode') ? 'has-danger' : '' }}">
                                            <label class="form-control-label" for="billcode">Bill Code<span class="required">*</span></label>
                                            @if(isset($Bill))
                                                <input class="form-control" type="text" name="billcode" id="billcode" value="{{ old('billcode', @$Bill->billcode) }}" maxlength="100" readonly>
                                            @endif
                                            <div class="invalid-feedback">
                                                @if($errors->has('billcode'))
                                                    {{ $errors->first('billcode') }}
                                                @endif
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group form-material {{ $errors->has('billdatetime') ? 'has-danger' : '' }}">
                                            <label class="form-control-label" for="billdatetime"><b>Bill Date & Time</b><span class="required">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="icon md-calendar" aria-hidden="true"></i>
                                                </span>
                                                @if(isset($Bill->billdatetime))
                                                   <input class="form-control" type="text" name="billdatetime" id="billdatetime" value="{{ date('d-m-Y H:i', strtotime($Bill->billdatetime))}}" disabled>
                                                @endif
                                            </div>
                                            <div class="invalid-feedback">
                                                @if($errors->has('billdatetime'))
                                                    {{ $errors->first('billdatetime') }}
                                                @endif
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group form-material {{ $errors->has('customerid') ? 'has-danger' : '' }}">
                                            <label class="form-control-label" for="customerid">Customer Name<span class="required">*</span></label>
                                            <select class="form-control select2" name="customerid" id="customerid">
                                                @if(isset($Bill))
                                                   <option value="{{ @$Bill->customerid }}" selected="">{{ @$Bill->customer->name }}</option>
                                                @endif
                                            </select>
                                            <div class="invalid-feedback">
                                                @if($errors->has('customerid'))
                                                    {{ $errors->first('customerid') }}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-12">
                                        <div class="card border border-info hms_card_primary">
                                            <div class="card-header card-header-transparent card-header-bordered bg-info pt-5 pb-5">
                                                <div class="row">
                                                    <div class="col-md-6 line_height_30">
                                                        Items
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-block">
                                                <div class="table-responsive" id="poItemsTbl"></div>
                                                <div class="table-responsive" id="grnItemsTbl"></div>
                                                <div class="table-responsive" id="directItemsTbl">
                                                    <table class="table table-bordered" id="tbl_hms" style="width: 100%">
                                                        <thead>
                                                            <tr>
                                                               <th style="width: 20%;">Item Name<span class="required">*</span></th>
                                                                <th style="width: 5%;">Days<span class="required">*</span></th>
                                                                <th style="width: 5%;">Qty<span class="required">*</span></th>
                                                                
                                                                <th style="width: 5%;">Rate<span class="required">*</span></th>
                                                                <th style="width: 10%;">Total<span class="required">*</span></th>
                                                                <th>Action</th>
                                                                
                                                            </tr>
                                                            </thead>
                                                            <tbody id="tbl_hms_body" data-module="purchase_bill">
                                                        @if(isset($Bill))
                                                              @foreach($Bill->billdetails as $key=>$details)
                                                                    <tr class="item_grid" id="row-{{$key}}">
                                                                        
                                                                        <td>
                                                                            <select class="form-control itemid" name="itemid-{{$key}}" id="itemid-{{$key}}" style="width: 250px;" disabled>
                                                                                @if($details->item)
                                                                                    <option selected="" value="{{$details->itemid}}">{{$details->item->name }}</option>
                                                                                @endif
                                                                            </select>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>

                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="days-{{$key}}" id="days-{{$key}}" class="form-control allow_number" maxlength="3" value="{{$details->days}}" style="width: 200px;" readonly="">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="hidden" name="oldqty-{{$key}}" id="oldqty-{{$key}}" class="form-control" value="{{$details->qty}}">
                                                                            <input type="text" name="qty-{{$key}}" class="form-control allow_number" maxlength="10" value="{{$details->qty}}" style="width: 100px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="rate-{{$key}}" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="{{$details->rate}}" style="width: 150px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="totalamount-{{$key}}" class="form-control totalamount" readonly value="{{$details->netamount}}" style="width: 170px;" readonly>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td>
                                                                            <input type="hidden" name="id-{{$key}}" value="{{$details->id}}">
                                                                            
                                                                        </td>
                                                                    </tr>
                                                                @endforeach
                                                        @else
                                                            <tr class="item_grid" id="row-0">
                                                                <td>
                                                                    <div class="checkbox-custom checkbox-primary">
                                                                        <input type="checkbox" class="gridChkRow">
                                                                        <label for="gridChkRow"></label>
                                                                    </div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <select class="form-control itemid" name="itemid-0" id="itemid-0" style="width: 250px;">
                                                                    </select>
                                                                    <div class="invalid-feedback"></div>
                                                                </td>  
                                                                <td class="hms_td_row">
                                                                   <input type="text" name="days-0" class="form-control allow_number" maxlength="3" value="" style="width: 200px;">
                                                                   <div class="invalid-feedback"></div>
                                                               </td>                        
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="qty-0" class="form-control allow_number" maxlength="10" style="width: 100px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row" style="width:350px;">
                                                                    <input type="text" name="rate-0" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="totalamount-0" class="form-control totalamount" id="totalamount-0" readonly style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                
                                                                <td></td>
                                                            </tr>
                                                        @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <div class="panel">
                                    <div class="panel-body totalgrid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="grandtotal" class="col-sm-4 form-control-label">Grand Total <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="{{ old('discper', @$Bill->grandtotal) }}" readonly>
                                                        <div class="invalid-feedback">
                                                            @if($errors->has('grandtotal'))
                                                                {{ $errors->first('grandtotal') }}
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="discount" class="col-sm-4 form-control-label">Discount : </label>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="5" data-afterdecimal="2" value="{{ old('discper', @$Bill->discper) }}" readonly>
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <b class="float-right">%</b>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="{{ old('discamt', @$Bill->discamt) }}" placeholder="Amt" readonly>
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="othercharges" class="col-sm-4 form-control-label">Other Charges : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="{{ old('othercharges', @$Bill->othercharges) }}" readonly>
                                                        <div class="invalid-feedback">
                                                            @if($errors->has('othercharges'))
                                                                {{ $errors->first('othercharges') }}
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="roundoff" class="col-sm-4 form-control-label">Round Off : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="{{ old('roundoff', @$Bill->roundoff) }}" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="netamount" class="col-sm-4 form-control-label">Net Amount <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" value="{{ old('netamount', @$Bill->netamount) }}" readonly>
                                                        <div class="invalid-feedback">
                                                            @if($errors->has('netamount'))
                                                                {{ $errors->first('netamount') }}
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container">
                                <div class="row justify-content-center">
                                    
                                    <div class="p-1">
                                        <a href="{{ url('admin/bills') }}" class="btn btn-secondary waves-effect waves-classic">
                                            Cancel
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
    </div>
@endsection
@section('scripts')
    <script src="{{ asset('global/vendor/select2/select2.min.js')}}"></script>
    <script src="{{ asset('global/vendor/flatpickr/flatpickr.js')}}"></script>
    <script src="{{ asset('assets/js/inventory.js')}}"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            @if(isset($Bill))
                $( "#billdatetime" ).flatpickr({
                    enableTime: true,
                    time_24hr: true,
                    dateFormat: session_obj.hospital.branch_settings.select_date_pattern+' H:i',
                });

                $('#documenttype').select2({disabled: true});
                $('#deptid').select2({disabled: true});
                $('#customerid').select2({disabled: true}); 
                $('#taxation').select2({disabled: true}); 

                @if($Bill->documenttype == 'PO')
                $('.gridChkDelete').css("display",'none');
                $('#addToTable').css("display",'none');
                $('.delete-record').css("display",'none');
                @endif

                @if($Bill->documenttype == 'GRN')
                $('.gridChkDelete').css("display",'none');
                $('#addToTable').css("display",'none');
                $('.delete-record').css("display",'none');
                $('.totalgrid').css("pointer-events",'none');
                @endif

            @endif

            $('.selBtnPO').attr('disabled','disabled');
            $('.selBtnGRN').attr('disabled','disabled');
            $('.select2').select2();

            /******* Item Grid ************/
            $('#expirydate-0').flatpickr({
                dateFormat: session_obj.hospital.branch_settings.select_date_pattern,
                minDate: new Date(),
                allowInput:true
            });
        });
    </script>
@endsection
