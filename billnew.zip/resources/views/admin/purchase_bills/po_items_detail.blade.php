<table class="table table-bordered" id="tbl_hms">
   <thead>
      <tr>
         <th style="width: 20%;">Item Name(Item Code)<span class="required">*</span></th>
         <th style="width: 10%;">Batch No<span class="required batchDate" style="display: none;">*</span></th>
         <th style="width: 20%;">Expiry Date<span class="required batchDate" style="display: none;">*</span></th>
         <th style="width: 5%;">Qty<span class="required">*</span></th>
         <th style="width: 5%;">Fr. Qty</th>
         <th style="width: 5%;">Rate<span class="required">*</span></th>
         <th style="width: 10%;">Total<span class="required">*</span></th>
         <th style="width: 3%;">Disc(%)</th>
         <th style="width: 5%;">Disc Amt</th>
         <th style="width: 10%;">Net Amount<span class="required">*</span></th>
      </tr>
   </thead>
   <tbody id="tbl_hms_body" data-module="PO">
   @if($purchaseorder)
        @foreach($purchaseorder as $key=>$details)
         <tr class="item_grid" id="row-{{$key}}">
            <td>
               <select class="form-control itemid" style="width: 250px;" disabled="disabled">
                  @if($details->item)
                  <option selected="" value="{{$details->itemid}}">{{$details->item->itemname .' ('. $details->item->itemcode.')' }}</option>
                  @endif
               </select>
               <input type="hidden" name="itemid-{{$key}}" id="itemid-{{$key}}" value="{{$details->item->itemid}}">
               <input type="hidden" name="orderdetailid-{{$key}}" id="orderdetailid-{{$key}}" value="{{$details->orderdetailid}}">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="batchno-{{$key}}" id="batchno-{{$key}}" onfocusout="uniqueBatchNo(this.id)" class="form-control" maxlength="100" style="width: 120px;" value="{{$details->batchno}}">
               <div class="invalid-feedback"></div>
            </td>
            <td>
               <div class="input-group">
                  <span class="input-group-addon">
                  <i class="icon md-calendar" aria-hidden="true"></i>
                  </span>
                  @if($details->expirydate)
                  <input class="form-control expirydate" type="text" name="expirydate-{{$key}}" id="expirydate-{{$key}}" value="{{ old('expirydate', display_datetime(['datetime' => $details->expirydate,'onlydate' => TRUE,'select_datepattern' => TRUE])) }}" style="width: 130px;" readonly>
                  @else
                  <input class="form-control expirydate" type="text" name="expirydate-{{$key}}" id="expirydate-{{$key}}" style="width: 130px;" readonly>
                  @endif
               </div>
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="qty-{{$key}}" class="form-control allow_number" maxlength="10" value="{{$details->qty}}" max="{{$details->qty}}" style="width: 100px;">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="freeqty-{{$key}}" class="form-control allow_number" maxlength="10" value="{{$details->freeqty}}" style="width: 100px;">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="rate-{{$key}}" class="form-control allow_decimal" data-beforedecimal="7" data-afterdecimal="2" value="{{$details->rate}}" style="width: 150px;">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="basicamount-{{$key}}" class="form-control basicamount" id="basicamount-{{$key}}" value="{{$details->basicamount}}" readonly style="width: 150px;">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="discper-{{$key}}" class="form-control discper allow_decimal" data-beforedecimal="3" data-afterdecimal="2" value="{{$details->discper}}" style="width: 60px;">
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="discamt-{{$key}}" class="form-control discamt allow_decimal"data-beforedecimal="7" data-afterdecimal="2" value="{{$details->discamt}}" style="width: 100px;" readonly>
               <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
               <input type="text" name="totalamount-{{$key}}" value="{{$details->netamount}}" class="form-control totalamount" readonly style="width: 170px;">
               <input type="hidden" name="purchaseorderdetailid-{{$key}}" value="{{$details->orderdetailid}}" class="form-control" style="width: 170px;">
               <div class="invalid-feedback"></div>
            </td>
         </tr>
        @endforeach
   @else
      <tr>
         No data found.
      </tr>
   @endif
   </tbody>
</table>
