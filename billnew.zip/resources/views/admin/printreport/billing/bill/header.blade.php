<center><h3 class="border-bottom border-top" style="padding-top: 5px;padding-bottom: 5px;background: #e6e4e4;">Arihant</h3></center>

<table class="table border-bottom" cellspacing="0" style="border-bottom: 1px solid #000;">
  <tbody>
    <tr>
      <td><strong>ANTRIX SUPPLIERS</strong></td>
    </tr>
    <tr>
      <td>
         Nr. Bus Stand, Rangaipura, Ta Petlad
      </td>
    </tr>
    <tr>
      <td class="pb-10">Phone No. 8320863294/ 9427387070</td>
    </tr>
  </tbody>
</table>

<table id="header_table" class="table pt-10" cellspacing="0">
	<tbody>
		<tr>
			<th>Customer Name</th>
			<td>{{ $bill->patient->fullName }}</td>
			<th>Village</th>
			<td>{{ $bill->invoicecode }}</td>
			<th>Mobile No.</th>
			<td>{{ $bill->invoicecode }}</td>
		</tr>
		<tr>
			<th>Address</th>
			<td>{{ $bill->patient->patcode }}</td>
			<th>C/o</th>
			@php
				$estdatetime = display_datetime(['datetime' => $bill->invoicedatetime,'select_datepattern' => TRUE]);
			@endphp
			<td>{{ $estdatetime }}</td>
		</tr>
		<tr>
			<th class="border-bottom">Doctor Name</th>
			<td class="border-bottom">{{ $bill->provider->fullName }}</td>
			<th class="border-bottom">@if($bill->modulename == 'General Visit') OPD No. @endif</th>
			<td class="border-bottom">@if($bill->modulename == 'General Visit'){{ $bill->episode->episodecode }}@endif</td>
		</tr>
	</tbody>
</table>