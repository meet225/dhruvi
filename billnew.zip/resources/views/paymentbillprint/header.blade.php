<center><h3 class="border-bottom border-top" style="padding-top: 5px;padding-bottom: 5px;background: #e6e4e4;">ANTRIX SUPPLIERS <p>High Quality Wedding Decorators Theme Parties</p></h3></center>

<table class="table border-bottom" cellspacing="0" style="border-bottom: 1px solid #000;">
  <tbody>
   <!--  <tr>
      <td><strong></strong></td>
    </tr> -->
    <tr>
      <td>
        Petlad-Nadiad road, Nr.Bus stop, <br>
        Rangaipura<br>
        Taluka: Petlad<br>
        District: Anand<br>
      </td>
    </tr>
    <tr>
      <td class="pb-10">Henalbhai: 9427387070</td>
      <td class="pb-10">Khushi: 8320863294</td>
    </tr>
  </tbody>
</table>

<table id="header_table" class="table pt-10" cellspacing="0">
	<tbody>
		<tr>
			<th>Customer Name</th>
			<td>{{ $payment->customer->name }}</td>
			<th>Address</th>
			<td>{{ $payment->customer->address }}</td>
		</tr>
		<tr>
			<th>Village</th>
			<td>{{ $payment->customer->village }}</td>
			<th>C/o</th>
			<td>{{ $payment->customer->in_care_of }}</td>
		</tr>
		<tr>
			
			<th class="border-bottom">Payment Code</th>
			<td class="border-bottom">
					{{ $payment->paymentcode }}
			</td>
			<th class="border-bottom">Payment Date and time</th>
			@php
				$estdatetime = date('d-m-Y H:i', strtotime($payment->paymentdatetime));
			@endphp
			<td class="border-bottom">{{ $estdatetime }}</td>
		</tr>
	</tbody>
</table>