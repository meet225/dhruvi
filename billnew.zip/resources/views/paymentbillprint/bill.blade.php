<!DOCTYPE html>
<html style="background-color: #d7ca6acc;">
<head>
	<title>Bill</title>
	<style>

	    @page { margin: {{ $page_margin }}; }
	</style>
	<link rel="stylesheet" href="{{public_path('assets/css/print.css')}}">
</head>
<body >
	<!-- Header -->
	<div id="header">
   		@include('paymentbillprint.header')
	</div>

	<!-- Footer -->
	<div id="footer">
	   @include('paymentbillprint.footer')
	</div>

	<!-- Main Content -->
	<div id="content">
		<table id="charge_detail" class="table" cellspacing="0" style="margin-bottom: 20px;">
	    	<thead class="border-bottom">
	    		<tr>
	    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
	    			<th style="text-align: center;" class="pb-10">Bill Code</th>
	    			<th style="text-align: center;" class="pb-10">Bill Date</th>
		    		<th style="text-align: center;" class="pb-10">Paying Amount</th>
	    		</tr>
	    	</thead>
	    	<tbody>
	    		@if($payment->details)
	    			@php $sr=1 @endphp
		    		@foreach($payment->details as $cpdetails)
		    		<tr class="align-center">
			    		<td class="border-bottom">{{ $sr }}</td>
			    		<td class="border-bottom">{{ $cpdetails->bill->billcode }}</td>
			    		<td class="border-bottom">{{ date('d-m-Y H:i', strtotime($cpdetails->bill->billdatetime)) }}</td>
			    		<td class="border-bottom">{{ $cpdetails->payingamount }}</td>
		    		</tr>
		    		@php $sr++ @endphp
		    		@endforeach
		    	@else
		    		<tr>No data found.</tr>
		    	@endif
	    	</tbody>
	    </table>

		<table class="table pt-10 pb-10">
			<tbody>
				<tr>
					<?php
						$f = new \NumberFormatter( locale_get_default(), \NumberFormatter::SPELLOUT );
						$word = $f->format($payment->paidamount);
					?>
					<th>The sum of Rupees</th>
					<td class="border-bottom float-left sumofrupees">{{ ucwords($word) }} by <strong>{{ $payment->paymentmode }} Payment</strong></td>
				</tr>
				@if($payment->paymentmode == 'Debit Card' || $payment->paymentmode == 'Credit Card')
					@php
				        $trancdate = date('d-m-Y H:i', strtotime($payment->transactiondate));
				     @endphp
					<tr>
						<th>Payment Details</th>
						<td class="border-bottom float-left sumofrupees"><strong>Transaction No. </strong>{{ $payment->transactionno }}, <strong>Transaction Date</strong> : {{ $trancdate }}, <strong><br>Bank Name</strong> : {{ $payment->bankname }}</td>
					</tr>
				@elseif($payment->paymentmode == 'Cheque')
					@php
				        $trancdate = date('d-m-Y H:i', strtotime($payment->transactiondate));
				    @endphp
					<tr>
						<th>Payment Details</th>
						<td class="border-bottom float-left sumofrupees"><strong>Cheque No. </strong>{{ $payment->transactionno }}, <strong>Cheque Date</strong> : {{ $trancdate }}, <strong><br>Bank Name</strong> : {{ $payment->bankname }}</td>
					</tr>
				@endif
			</tbody>
		</table>

		<table class="table mt-10">
			<tbody>
				<tr>
					<td class="border float-left receiptamt"><strong>Rs. {{ $payment->paidamount }}</strong></td>
					<td></td>
					<td style="width: 20%;height: 70px;border:1px solid #000;"></td>
				</tr>
				<tr>
					<td class="float-left font-size-13"><strong>*Payment by cheque subject to realization.</strong></td>
					<td></td>
					<td class="float-right font-size-14"><strong>Receiver's Signature</strong></td>
				</tr>
			</tbody>
		</table>
	</div>	
</body>
</html>