// Billing > Grand Total
function grandTotal(){
  var grandtotal = 0;
  $('.charge_grid').each(function(i){
    var row_num = $(this).attr('id').split('-');
    var netamount = $('[name="totalamount-'+row_num[1]+'"]').val();
      if(typeof netamount !== 'undefined'){
        grandtotal += +netamount;
      }
  });
  $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
}

// Inventroy approval total
function grandTotalInvApproval(){
  var grandtotal = 0;
  $('.charge_grid').each(function(i){
    var row_num = $(this).attr('id').split('-');
    var status = $('[name="status-'+row_num[1]+'"]').val();
    if (status=="1") {

        var netamount = $('[name="totalamount-'+row_num[1]+'"]').val();
        if(typeof netamount !== 'undefined'){
          grandtotal += +netamount;
        }
    }
    
  });
  $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
}

// Billing > Discount Percentage
function discount(discper,grandtotal){
  if (discper != '' && grandtotal != '') {
    var discamount = (parseFloat(grandtotal)) * (parseFloat(discper)) / 100;
    if (isFinite(discamount)){
      $('input[name="discamt"]').val(discamount.toFixed(2));
    }
  }else{
    $('input[name="discamt"]').val('');
  }
}
// Billing > Discount Amount
function discountAmount(discamt,grandtotal){
  if (discamt != '' && grandtotal != '') {
    var discper = (parseFloat(discamt)) * 100 / (parseFloat(grandtotal));
    if (isFinite(discper)){
      $('input[name="discper"]').val(discper.toFixed(2));
    }
  }else{
    $('input[name="discper"]').val('');
  }
}
// Billing > Net Amount
function totalNetAmount(grandtotal,discamt,othercharges){
  if (grandtotal != '' && discamt != '' && othercharges != '') {
    var total_netamount = (parseFloat(grandtotal)) - (parseFloat(discamt)) + (parseFloat(othercharges));
    var decimalPart = total_netamount - Math.floor(total_netamount);
    var onlyTwoDecimalPlaces = decimalPart.toFixed(2);
    var explode = onlyTwoDecimalPlaces.split('.');
    if(explode[1] == '00'){
      $('input[name="roundoff"]').val('')
      var final_netamt = (parseFloat(total_netamount));
    }else if(explode[1] > '5'){
      var roundval = 1 - onlyTwoDecimalPlaces;
      $('input[name="roundoff"]').val('+'+roundval.toFixed(2))
      var final_netamt = (parseFloat(total_netamount)) + (parseFloat(roundval));
    }else if(explode[1] < '5'){
      $('input[name="roundoff"]').val('-'+onlyTwoDecimalPlaces)
      var final_netamt = (parseFloat(total_netamount)) - (parseFloat(onlyTwoDecimalPlaces));
    }
    $('input[name="netamount"]').val((final_netamt).toFixed(2));
    $('input[name="netamount"]').trigger('keyup');
  }else{
    $('input[name="netamount"]').val('');
  }
  //IPD=>Advance receipt
  if($('#admissionid').length){
    receivedAmount($('#patid').val(),$('#admissionid').val());
  }
}
/************* Calculation js for Estimate & Bill ***************/
   $('input[name="discper"]').on("keyup", function() {
       var discper=0,grandtotal=0;
       discper += $(this).val();
       grandtotal += $('input[name="grandtotal"]').val();
       discount(discper,grandtotal);
       discountDiagnostic(discper,grandtotal);
       $('input[name="othercharges"]').trigger('keyup');
   });
   // Discount Amount on keyup event
   $('input[name="discamt"]').on("keyup", function() {
       var discamt=0,grandtotal=0;
       discamt += $(this).val();
       grandtotal += $('input[name="grandtotal"]').val();
       discountAmount(discamt,grandtotal);
       discountAmountDiagnostic(discamt,grandtotal);
       //totalNetAmountDiagnostic(grandtotal,discamt)
       $('input[name="othercharges"]').trigger('keyup');
   });
   // Other charges on keyup event
   $('input[name="othercharges"]').on("keyup", function() {
     var discamt = 0,othercharges = 0;
     var grandtotal = $('input[name="grandtotal"]').val();
     discamt += $('input[name="discamt"]').val();
     othercharges += $(this).val();
       totalNetAmountDiagnostic(grandtotal,discamt)
     totalNetAmount(grandtotal,discamt,othercharges);
   });
   /***************** EndCalculation js ********************/
// Payment type on change event
function paymentMode(pmode){
  if($(pmode).val() !== 'Cash'){
    if($(pmode).attr('data-module')=="IPD"){
      $('.refpayment-details').show();
      $('.payment-details').hide();
    }else if($(pmode).val() == null){
      // HMS-I824
      $('.payment-details').hide();
      $('.refpayment-details').hide();
    }else{
      $('.payment-details').show();
      $('.refpayment-details').hide();
    }
    if($(pmode).val() == 'Cheque'){
      $('.numberlbl,.datelbl').text('');
      $('.numberlbl').append("Cheque No.<span class='required'>*</span>");
      $('.datelbl').append("Cheque Date<span class='required'>*</span>");
    }else if($(pmode).val() == 'Credit Card' || $(pmode).val() == 'Debit Card') {
      $('.numberlbl,.datelbl').text('');
      $('.numberlbl').append("Transaction No.<span class='required'>*</span>");
      $('.datelbl').append("Transaction Date<span class='required'>*</span>");
    }
  }else{
    $('.transactionno,.transactiondate,.bankname').val('');
    $('.payment-details,.refpayment-details').hide();
  }
}
$('.paymentmode,.refundPayMode').on('change', function() {
  paymentMode($(this));
});

// Receipt > Received Amount
function totalReceivedAmount(){
  var totalreceiptamt = 0;
  $('.bill_grid').each(function(i){
    var row_num = $(this).attr('id').split('-');
    var receiptamount = $('[name="receiptamount-'+row_num[1]+'"]').val();
      if(typeof receiptamount !== 'undefined'){
        totalreceiptamt += +receiptamount;
      }
  });
  $('#receiptamount').val(totalreceiptamt.toFixed(2));
}
/* Receipt > rule for receiptamount column */
function lessThanPendingAmount(){
  $('.bill_grid').each(function(){
    var row_num = $(this).attr('id').split('-');
    $('input[name="receiptamount-'+row_num[1]+'"]').rules("add", {
      lessThanPendingAmt: "#pendingamount-"+row_num[1],
    });
  });
}
/* Receipt > total receiptamount */
function totalReceiptAmount(){
  $('.bill_grid').each(function(){
    var row_num = $(this).attr('id').split('-');
    $('input[name="receiptamount-'+row_num[1]+'"]').on("keyup", function() {
       totalReceivedAmount();
    });
  });
}
/* Patient > tieup > chargepricelist */
function patTieupChargePrice(patid,date,pricelistfor){
  var formatdate = moment(date).format('YYYY-MM-DD');
  $.ajax({
     url:base_url+'/admin/pat-chargeprice',
     type:'get',
     dataType: 'json',
     data: {
        patid : patid,
        formatdate : formatdate,
        pricelistfor : pricelistfor,
     },
     success:function(data){
        if(data.length !== 0){
           var option = new Option(data.text, data.id, true, true);
           $('#pricelistid').append(option).trigger('change');
        }else{
          if ($('#pricelistid').val() != '') {
            $('#pricelistid').empty();
            $("#clear_charge").trigger('click');
          }
        }
     }
  });
}
/************ IPD Charge Grid Keyup (default row-0) Event *********************/
function chargeGridCalForDefRow(){
  $('#chargedate-0').flatpickr({
     dateFormat: session_obj.hospital.branch_settings.select_date_pattern,
     defaultDate: new Date(),
     allowInput:true
  });
  $('select[name="chargeid-0').on('change', function() {
     var pricelistid = $('#pricelistid').val();
     var providerid = $('#providerid').val();
     var chargeid = $(this).val();
     $.ajax({
        url:base_url+'/admin/ipd/getrate',
        type:'get',
        data: {
           providerid : providerid,
           pricelistid : pricelistid,
           chargeid : chargeid,
        },
        success:function(data){
           $('input[name="chargerate-0').val(data.charges);
           $('input[name="chargerate-0').trigger('keyup');
        }
     });
  });
  $('input[name="duration-0"]').on("keyup", function() {
    // var value=0,chargerate=0;
    var value = $(this).val();
    var chargerate = $('input[name="chargerate-0"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(chargerate));
    if (value != '' && chargerate != '') {
      $('input[name="basicamount-0"]').val(netamount.toFixed(2));
      $('input[name="totalamount-0"]').val(netamount.toFixed(2));
    }else{
      $('input[name="basicamount-0"]').val('');
      $('input[name="totalamount-0"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="chargerate-0"]').on("keyup", function() {
    // var value = 0,duration=0;
    var value = $(this).val();
    var duration = $('input[name="duration-0"]').val();
    var netamount = (parseFloat(value)) * duration;
    if (value != '' && duration != '') {
      $('input[name="basicamount-0"]').val(netamount.toFixed(2));
      $('input[name="totalamount-0"]').val(netamount.toFixed(2));
    }else{
      $('input[name="basicamount-0"]').val('');
      $('input[name="totalamount-0"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="discper-0"]').on("keyup", function() {
    var discper = $(this).val();
    var basicamount = $('input[name="basicamount-0"]').val();
    var discper = $('[name="discper-0"]').val();
    var basicamount = $('[name="basicamount-0"]').val();
    if (isFinite(basicamount) && discper != '' && basicamount != '') {
      if(typeof basicamount !== 'undefined'){
        var discamount = (parseFloat(basicamount)) * (parseFloat(discper)) / 100;
        $('[name="discamt-0"]').val(discamount.toFixed(2));
        var netamount = (parseFloat(basicamount)) - (parseFloat(discamount))
        $('[name="totalamount-0"]').val(netamount.toFixed(2));
      }
    }else{
      $('[name="discamt-0"]').val('');
      $('[name="totalamount-0"]').val(basicamount);
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  });
  $('input[name="discamt-0"]').on("keyup", function() {
    var discamt = $(this).val();
    var basicamount = $('input[name="basicamount-0"]').val();
    var discamt = $('[name="discamt-0"]').val();
    var basicamount = $('[name="basicamount-0"]').val();

    if (isFinite(basicamount) && discamt != '' && basicamount != '' && basicamount != 0) {
      if(typeof basicamount !== 'undefined'){
        var discper = (parseFloat(discamt)) * 100 / (parseFloat(basicamount));
        $('[name="discper-0"]').val(discper.toFixed(2));
        var netamount = (parseFloat(basicamount)) - (parseFloat(discamt));
        $('[name="totalamount-0"]').val(netamount.toFixed(2));
      }
    }else{
      $('[name="discper-0"]').val('');
      $('[name="totalamount-0"]').val(basicamount);
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  });
}
/************ OPD/IPD Charge Grid Keyup Event *********************/
function chargeGridCalculation($ele){
  $('input[name="duration-'+$ele+'"]').on("keyup", function() {
    // var value=0,chargerate=0;
    var value = $(this).val();
    var chargerate = $('input[name="chargerate-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(chargerate));
    if (value != '' && chargerate != '') {
      $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
    }else{
      $('input[name="basicamount-'+$ele+'"]').val('');
      $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="chargerate-'+$ele+'"]').on("keyup", function() {
    // var value = 0,duration=0;
    var value = $(this).val();
    var duration = $('input[name="duration-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * duration;
    if (value != '' && duration != '') {
      $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
    }else{
      $('input[name="basicamount-'+$ele+'"]').val('');
      $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="discper-'+$ele+'"]').on("keyup", function() {
    var discper = $(this).val();
    var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
    var discper = $('[name="discper-'+$ele+'"]').val();
    var basicamount = $('[name="basicamount-'+$ele+'"]').val();
    if (isFinite(basicamount) && discper != '' && basicamount != '') {
      if(typeof basicamount !== 'undefined'){
        var discamount = (parseFloat(basicamount)) * (parseFloat(discper)) / 100;
        $('[name="discamt-'+$ele+'"]').val(discamount.toFixed(2));
        var netamount = (parseFloat(basicamount)) - (parseFloat(discamount))
        $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
      }
    }else{
      $('[name="discamt-'+$ele+'"]').val('');
      $('[name="totalamount-'+$ele+'"]').val(basicamount);
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  });
  $('input[name="discamt-'+$ele+'"]').on("keyup", function() {
    var discamt = $(this).val();
    var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
    var discamt = $('[name="discamt-'+$ele+'"]').val();
    var basicamount = $('[name="basicamount-'+$ele+'"]').val();

    if (isFinite(basicamount) && discamt != '' && basicamount != '' && basicamount != 0) {
      if(typeof basicamount !== 'undefined'){
        var discper = (parseFloat(discamt)) * 100 / (parseFloat(basicamount));
        $('[name="discper-'+$ele+'"]').val(discper.toFixed(2));
        var netamount = (parseFloat(basicamount)) - (parseFloat(discamt))
        $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
      }
    }else{
      $('[name="discper-'+$ele+'"]').val('');
      $('[name="totalamount-'+$ele+'"]').val(basicamount);
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  });
}

/************ Inventory Items Grid Keyup Event *********************/
function iteminvGridCalculation($ele){
  $('input[name="qty-'+$ele+'"]').on("keyup", function() {
    // var value=0,rate=0;
    var value = $(this).val();
    var rate = $('input[name="rate-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * (parseFloat(rate));
    if (value != '' && rate != '') {
      $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="discper-'+$ele+'"]').trigger('keyup');
    }else{
      $('input[name="basicamount-'+$ele+'"]').val('');
      $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="rate-'+$ele+'"]').on("keyup", function() {
    // var value = 0,qty=0;
    var value = $(this).val();
    var qty = $('input[name="qty-'+$ele+'"]').val();
    var netamount = (parseFloat(value)) * qty;
    if (value != '' && qty != '') {
      $('input[name="basicamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
      $('input[name="basicamount-'+$ele+'"]').trigger('keyup');
      $('input[name="totalamount-'+$ele+'"]').trigger('keyup');
      $('input[name="discper-'+$ele+'"]').trigger('keyup');
      $('input[name="grandtotal"]').trigger('keyup');
    }else{
      $('input[name="basicamount-'+$ele+'"]').val('');
      $('input[name="totalamount-'+$ele+'"]').val('');
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  })
  $('input[name="discper-'+$ele+'"]').on("keyup", function() {
    var discper = $(this).val();
    var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
    var discper = $('[name="discper-'+$ele+'"]').val();
    var basicamount = $('[name="basicamount-'+$ele+'"]').val();
    if (isFinite(basicamount) && discper != '' && basicamount != '') {
      if(typeof basicamount !== 'undefined'){
        var discamount = (parseFloat(basicamount)) * (parseFloat(discper)) / 100;
        $('[name="discamt-'+$ele+'"]').val(discamount.toFixed(2));
        var netamount = (parseFloat(basicamount)) - (parseFloat(discamount))
        $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
      }
    }else{
      $('[name="discamt-'+$ele+'"]').val('');
      $('[name="totalamount-'+$ele+'"]').val(basicamount);
    }
    grandTotal();
    $('input[name="discper"]').trigger('keyup');
    $('input[name="othercharges"]').trigger('keyup');
  });
  // $('input[name="discamt-'+$ele+'"]').on("keyup", function() {
  //   var discamt = $(this).val();
  //   var basicamount = $('input[name="basicamount-'+$ele+'"]').val();
  //   var discamt = $('[name="discamt-'+$ele+'"]').val();
  //   var basicamount = $('[name="basicamount-'+$ele+'"]').val();

  //   if (isFinite(basicamount) && discamt != '' && basicamount != '' && basicamount != 0) {
  //     if(typeof basicamount !== 'undefined'){
  //       var discper = (parseFloat(discamt)) * 100 / (parseFloat(basicamount));
  //       $('[name="discper-'+$ele+'"]').val(discper.toFixed(2));
  //       var netamount = (parseFloat(basicamount)) - (parseFloat(discamt))
  //       $('[name="totalamount-'+$ele+'"]').val(netamount.toFixed(2));
  //     }
  //   }else{
  //     $('[name="discper-'+$ele+'"]').val('');
  //     $('[name="totalamount-'+$ele+'"]').val(basicamount);
  //   }
  //   grandTotal();
  //   $('input[name="discper"]').trigger('keyup');
  //   $('input[name="othercharges"]').trigger('keyup');
  // });
}
function indentItemDetails(indent){
    $.ajax({
        url:base_url+'/admin/getIndentData',
        type:'get',
        dataType: 'json',
        data: {
            indentid : indent.indentid,
        },
        success:function(data){
            $('#'+indent.table).html(data.html);
            $('#addToTable').hide()
            $('.gridChkDelete').hide()
            itemInventoryGrid();
          
          if (data.department!="") {
              var newOption = new Option(data.department.departmentName,data.department.departmentID, true, true);
              // Append it to the select
              $('#deptid').append(newOption).trigger('change');
              $('#deptid').valid();
              $('#deptid + .select2-container').css('pointer-events','none');

            }           
            // For Last purchase details
            // $('#datatbl-lastpurchase').DataTable().clear().destroy();
            if($('#documenttype').val()=="Indent/Requisition"){
              $('#refreshBtn').trigger('click');
            }
        }
    });
}
/* inventory po grid end */
/* Refund Settlement & List */
columns_arr=[];
columns_arr.push(
  {data:'invoicecode', name:'invoicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'invoicedatetime', name:'invoicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'refunddatetime', name:'refunddatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'receiptamount', name:'receiptamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'remarks', name:'remarks',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'paymentmode', name:'paymentmode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'modulename', name:'modulename',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'transactionno', name:'transactionno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
);
function patPartialRefund(patid,invoiceid){
  $.ajax({
      url:base_url+'/admin/partial-refund',
      type:'get',
      data :{
        patid: patid,
        invoiceid : invoiceid
      },
     dataType: 'json',
     success:function(data){
        $('#partialsRefund').html(data);
        $('#refund-List').DataTable({
          "footerCallback": function ( row, data, start, end, display ) {
              var api = this.api(), data;
              // Total over this page
              pageTotal = api
                  .column( 3, { page: 'current'} )
                  .data()
                  .reduce( function (a, b) {
                      return parseFloat(a) + parseFloat(b);
                  }, 0 );

              // Update footer
              $(api.column( 3 ).footer()).html(pageTotal.toFixed(2));
          },
          responsive:true,
          processing: true,
          serverSide: true,
          "pageLength": 10,
          "ajax": {
              'type': 'GET',
              'url': base_url+'/admin/bill-refund',
              'data': {
                patid: patid,
                invoiceid : invoiceid,
              },
            },
          columns: columns_arr,
        });
     }
  });
}

/*** Diagnostic billing  start ***/

function patientTestAdviceDetails(test) {
    var formatdate = moment(test.billdate).format('YYYY-MM-DD');
    $.ajax({
        url:base_url+'/admin/getTestData',
        type:'get',
        dataType: 'json',
        data: {
            patid : test.patid,
            advice_id : test.advice_id,
            formatdate : formatdate,
        },
        success:function(data){
            $('#'+test.table).html(data);
            billingChargeGrid();
            /*grandTotalDiagnostic();
            $('input[name="discper"]').trigger('keyup');*/
            var grandtotal = 0;
            $('.charge_grid').each(function(i){
                var row_num = $(this).attr('id').split('-');
                var netamount = $('[name="testamount-'+row_num[1]+'"]').val();
                if(typeof netamount !== 'undefined'){
                    grandtotal += +netamount;
                }
            });
            $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
            var grandtotal = grandtotal.toFixed(2);
            var discamt = 0;
            var discamt = discamt.toFixed(2);
            totalNetAmountDiagnostic(grandtotal,discamt);
        }
    });
}

//on pricelist update at diagnostic bill
function patientTestPrice(test) {
    $.ajax({
        url:base_url+'/admin/getTestRate',
        type:'get',
        dataType: 'json',
        data: {
            patid : test.patid,
            advice_id : test.advice_id,
            pricelistid:test.pricelistid,
        },
        success:function(data){
            $('#'+test.table).html(data);
            billingChargeGrid();
            /*grandTotalDiagnostic();
            $('input[name="discper"]').trigger('keyup');*/
            var grandtotal = 0;
            $('.charge_grid').each(function(i){
                var row_num = $(this).attr('id').split('-');
                var netamount = $('[name="testamount-'+row_num[1]+'"]').val();
                if(typeof netamount !== 'undefined'){
                    grandtotal += +netamount;
                }
            });
            $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
            var grandtotal = grandtotal.toFixed(2);
            var discamt = 0;
            var discamt = discamt.toFixed(2);
            totalNetAmountDiagnostic(grandtotal,discamt);
        }
    });
}

/************ Diagnostic test Grid Keyup Event *********************/
function chargeGridCalculationDiagnostic($ele){
    $('input[name="testrate-'+$ele+'"]').on("keyup", function() {
        // var value = 0,duration=0;
        var value = $(this).val();
        var netamount = (parseFloat(value));
        if (value != '') {
            $('input[name="testamount-'+$ele+'"]').val(netamount.toFixed(2));
        }else{
            $('input[name="testamount-'+$ele+'"]').val('');
        }
        var discper = $('[name="discper-'+$ele+'"]').val();
        if(discper != '' && isFinite(discper) ){
            $('[name="discper-'+$ele+'"]').trigger('keyup');
        }
        grandTotalDiagnostic();
        $('input[name="discper"]').trigger('keyup');
    })
    $('input[name="discper-'+$ele+'"]').on("keyup", function() {
        var discper = $(this).val();
        var discper = $('[name="discper-'+$ele+'"]').val();
        var testrate = $('[name="testrate-'+$ele+'"]').val()
        if (discper != '') {
            if(typeof testrate !== 'undefined' && isFinite(testrate) && testrate!='' && testrate != 0){
                var discamount = (parseFloat(testrate)) * (parseFloat(discper)) / 100;
                $('[name="discamt-'+$ele+'"]').val(discamount.toFixed(2));
                var netamount = (parseFloat(testrate)) - (parseFloat(discamount))
                $('[name="testamount-'+$ele+'"]').val(netamount.toFixed(2));
            }else{
                $('[name="discamt-'+$ele+'"]').val('');
                $('[name="testamount-'+$ele+'"]').val(testrate);
            }
        }else{
            $('[name="discamt-'+$ele+'"]').val('');
            $('[name="testamount-'+$ele+'"]').val(testrate);
        }
        grandTotalDiagnostic();
        $('input[name="discper"]').trigger('keyup');
    });
    $('input[name="discamt-'+$ele+'"]').on("keyup", function() {
        var discamt = $(this).val();
        var discamt = $('[name="discamt-'+$ele+'"]').val();
        var testrate = $('[name="testrate-'+$ele+'"]').val();

        if (isFinite(testrate) && discamt != '' && testrate != '' && testrate != 0) {
            if(typeof testrate !== 'undefined'){
                var discper = (parseFloat(discamt)) * 100 / (parseFloat(testrate));
                $('[name="discper-'+$ele+'"]').val(discper.toFixed(2));
                var netamount = (parseFloat(testrate)) - (parseFloat(discamt))
                $('[name="testamount-'+$ele+'"]').val(netamount.toFixed(2));
            }
        }else{
            $('[name="discper-'+$ele+'"]').val('');
            $('[name="testamount-'+$ele+'"]').val(testrate);
        }
        grandTotalDiagnostic();
        $('input[name="discper"]').trigger('keyup');
    });
}

//Diagnostic Billing > Grand Total
function grandTotalDiagnostic(){
    var grandtotal = 0;
    $('.charge_grid').each(function(i){
        var row_num = $(this).attr('id').split('-');
        var netamount = $('[name="testamount-'+row_num[1]+'"]').val();
        if(typeof netamount !== 'undefined'){
            grandtotal += +netamount;
        }
    });
    $('input[name="grandtotal"]').val(grandtotal.toFixed(2));
}
//Diagnostic Billing > Discount Percentage
function discountDiagnostic(discper,grandtotal){
    if (discper != '' && grandtotal != '') {
        var discamount = (parseFloat(grandtotal)) * (parseFloat(discper)) / 100;
        if (isFinite(discamount)){
            //$('input[name="discamt"]').trigger('keyup');
            $('input[name="discamt"]').val(discamount.toFixed(2));
        }
    }else{
        $('input[name="discamt"]').val('');
    }
}
//Diagnostic Billing > Discount Amount
function discountAmountDiagnostic(discamt,grandtotal){
    if (discamt != '' && grandtotal != '') {
        var discper = (parseFloat(discamt)) * 100 / (parseFloat(grandtotal));
        if (isFinite(discper)){
            $('input[name="discper"]').val(discper.toFixed(2));
        }
    }else{
        $('input[name="discper"]').val('');
    }
}
//Diagnostic Billing > Net Amount
function totalNetAmountDiagnostic(grandtotal,discamt){
    if (grandtotal != '' && discamt != '') {
        var total_netamount = (parseFloat(grandtotal)) - (parseFloat(discamt));
        var decimalPart = total_netamount - Math.floor(total_netamount);
        var onlyTwoDecimalPlaces = decimalPart.toFixed(2);
        var explode = onlyTwoDecimalPlaces.split('.');
        if(explode[1] == '00'){
            $('input[name="roundoff"]').val('')
            var final_netamt = (parseFloat(total_netamount));
        }else if(explode[1] > '5'){
            var roundval = 1 - onlyTwoDecimalPlaces;
            $('input[name="roundoff"]').val('+'+roundval.toFixed(2))
            var final_netamt = (parseFloat(total_netamount)) + (parseFloat(roundval));
        }else if(explode[1] < '5'){
            $('input[name="roundoff"]').val('-'+onlyTwoDecimalPlaces)
            var final_netamt = (parseFloat(total_netamount)) - (parseFloat(onlyTwoDecimalPlaces));
        }
        final_netamt = (final_netamt).toFixed(2);
        $('input[name="netamount"]').val(final_netamt);
    }else{
        $('input[name="netamount"]').val('');
    }
}
/*** Diagnostic billing  end ***/

/*** Diagnostic Refuse ***/
function grandTotalRefuse(){
    var grandtotal = 0;
    $('.test_grid').each(function(i){
        var row_num = $(this).attr('id').split('-');
        var netamount = $('[name="testamount-'+row_num[1]+'"]').val();
        if(typeof netamount !== 'undefined'){
            grandtotal += +netamount;
        }
    });
    var grandtotal = grandtotal.toFixed(2);
    $('input[name="grandtotal"]').val(grandtotal);
    $('input[name="receiptamount"]').val(grandtotal);
    totalNetAmountRefuse(grandtotal);
}
function totalNetAmountRefuse(grandtotal){
    if (grandtotal != '') {
        var total_netamount = (parseFloat(grandtotal));
        var decimalPart = total_netamount - Math.floor(total_netamount);
        var onlyTwoDecimalPlaces = decimalPart.toFixed(2);
        var explode = onlyTwoDecimalPlaces.split('.');
        if(explode[1] == '00'){
            $('input[name="roundoff"]').val('')
            var final_netamt = (parseFloat(total_netamount));
        }else if(explode[1] > '5'){
            var roundval = 1 - onlyTwoDecimalPlaces;
            $('input[name="roundoff"]').val('+'+roundval.toFixed(2))
            var final_netamt = (parseFloat(total_netamount)) + (parseFloat(roundval));
        }else if(explode[1] < '5'){
            $('input[name="roundoff"]').val('-'+onlyTwoDecimalPlaces)
            var final_netamt = (parseFloat(total_netamount)) - (parseFloat(onlyTwoDecimalPlaces));
        }
        $('input[name="netamount"]').val((final_netamt).toFixed(2));
    }else{
        $('input[name="netamount"]').val('');
    }
}

/*** Diagnostic Refuse ***/
/* Diagnostic & Laboratory Refund History */
refundColumnsArr=[];
refundColumnsArr.push(
  {data:'refusecode', name:'refusecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'refusedate', name:'refusedate',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'refunddatetime', name:'refunddatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'receiptamount', name:'receiptamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'remarks', name:'remarks',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'paymentmode', name:'paymentmode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'modulename', name:'modulename',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
  {data:'transactionno', name:'transactionno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
);
function patRefundHistory(patid,refuseid,url1,url2){
  $.ajax({
      url:base_url+'/'+url1,
      type:'get',
      data :{
        patid: patid,
        refuseid : refuseid
      },
     dataType: 'json',
     success:function(data){
        $('#partialsRefund').html(data);
        $('#refund-List').DataTable({
          "footerCallback": function ( row, data, start, end, display ) {
              var api = this.api(), data;
              // Total over this page
              pageTotal = api
                  .column( 3, { page: 'current'} )
                  .data()
                  .reduce( function (a, b) {
                      return parseFloat(a) + parseFloat(b);
                  }, 0 );

              // Update footer
              $(api.column( 3 ).footer()).html(pageTotal.toFixed(2));
          },
          responsive:true,
          processing: true,
          serverSide: true,
          "pageLength": 10,
          "ajax": {
              'type': 'GET',
              'url': base_url+'/'+url2,
              'data': {
                patid: patid,
                refuseid : refuseid,
              },
            },
          columns: refundColumnsArr,
        });
     }
  });
}
/* End Diagnostic & Laboratory Refund History */
