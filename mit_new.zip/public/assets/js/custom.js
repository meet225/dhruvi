(function (global, factory) {
  var mod = {
    exports: {}
  };
  factory(global.jQuery, global.Site);
})(this, function (_jquery, _Site) {
  'use strict';

  var _jquery2 = babelHelpers.interopRequireDefault(_jquery);

  (0, _jquery2.default)(document).ready(function () {
    (0, _Site.run)();
  });
});
/**********Select2 ***************/
$('.select-all').click(function () {
  let $select2 = $(this).parent().siblings('.select2')
  $select2.find('option').prop('selected', 'selected')
  $select2.trigger('change')
})
$('.deselect-all').click(function () {
  let $select2 = $(this).parent().siblings('.select2')
  $select2.find('option').prop('selected', '')
  $select2.trigger('change')
});
/********** END Select2 ***************/
var toastr_opt={
  "closeButton": true,
  "debug": false,
  "newestOnTop": true,
  "progressBar": true,
  "positionClass": "toast-top-right",
  "preventDuplicates": false,
  "onclick": null,
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
};
function toastrSuccess(msg,title){
  toastr.success(msg,title,toastr_opt);
}
function toastrWarning(msg,title){
  toastr.warning(msg,title,toastr_opt);
}
function toastrErrors(msg,title){
  toastr.error(msg,title,toastr_opt);
}
function toastrError(msg,title){
  toastr.error(msg,title,toastr_opt);
}
$('.us_phone_number').keydown(function (e) {
   var key = e.charCode || e.keyCode || 0;
   $text = $(this);
   if (key !== 8 && key !== 9) {
       if ($text.val().length === 3) {
           $text.val($text.val() + '-');
       }
       if ($text.val().length === 7) {
           $text.val($text.val() + '-');
       }
   }
   return ((event.shiftKey && event.keyCode == 9) || (!e.shiftKey && (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))));
});

$(document).on("input",".allow_decimal",function(evt) {
   var beforedecimal=$(this).data('beforedecimal');
   var afterdecimal=$(this).data('afterdecimal');

   this.value = this.value
      .replace(/[^\d.]/g, '')
      .replace(new RegExp("(^[\\d]{" + beforedecimal + "})[\\d]", "g"), '$1')
      .replace(/(\..*)\./g, '$1')
      .replace(new RegExp("(\\.[\\d]{" + afterdecimal + "}).", "g"), '$1');
 });

$(document).on("input",".allow_max",function(evt) {
    var value = $(this).val();
    var maxval=$(this).data('maxval');
    if((value!=='') && (value.indexOf('.') === -1)){
      $(this).val(Math.max(Math.min(value,maxval),-maxval));
    }
});

$(document).on("paste",".allow_decimal",function(evt) {
   var beforedecimal=$(this).data('beforedecimal');
   var afterdecimal=$(this).data('afterdecimal');

   var element = this;
   setTimeout(function () {
      var text = $(element).val();
      var copyText=text.split('.');
      var fullTxt='';
      if(copyText[1]){
        var text1=copyText[0].slice(0, beforedecimal);
        var text2=copyText[1].slice(0, afterdecimal);
        fullTxt=text1+'.'+text2;
      }else{
        fullTxt=copyText[0].slice(0, beforedecimal);
      }
      $(element).val(fullTxt);
  }, 100);
});
$(document).on("input", ".allow_pincode",function(evt) {
  var totaldigits=$(this).data('totaldigits');
  this.value = this.value
      .replace(/[^0-9]/g, '')
      .replace(new RegExp("(^[\\d]{" + totaldigits + "})[\\d]", "g"), '$1');
});

$(document).on("input", ".allow_number",function(evt) {
  var totaldigits=$(this).data('totaldigits');
  this.value = this.value
      .replace(/[^0-9]/g, '')
      .replace(new RegExp("(^[\\d]{" + totaldigits + "})[\\d]", "g"), '$1');
});
$(document).on("paste",".allow_number",function(evt) {
   var totaldigits=$(this).data('totaldigits');

   var element = this;
   setTimeout(function () {
      var text = $(element).val();
      var fullTxt=text.slice(0, totaldigits);
      $(element).val(fullTxt);
  }, 100);
});
$('.allow_alphanumeric_dash').keydown(function (e) {
  var k = e.keyCode || e.which;
    var ok = k >= 65 && k <= 90 || // A-Z
      k >= 96 && k <= 105 || // a-z
      k >= 35 && k <= 40 || // arrows
      k == 9 || //tab
      k == 46 || //del
      k == 8 || // backspaces
      k == 189 || // dash
      (!e.shiftKey && k >= 48 && k <= 57); // only 0-9 (ignore SHIFT options)

    if(!ok || (e.ctrlKey && e.altKey)){
      e.preventDefault();
    }
});

function getSingleSelect2List(obj)
{
  var allowClear=false;
  var dropdownParent=false;
  if(obj.hasOwnProperty("allowClear")){
    allowClear=true;
  }
  if(obj.hasOwnProperty("dropdownParent")){
    dropdownParent=$(obj.dropdownParent);
  }
  if(obj.hasOwnProperty("width")){
    width=$(obj.width);
  }else{
    width='resolve';
  }
  $(obj.selector).select2({
    dropdownParent:dropdownParent,
    allowClear:allowClear,
    placeholder: obj.placeholder,
    width: width,
    ajax: {
      url:base_url+'/admin/select2_find',
      type:"POST",
      dataType:'json',
      delay:250,
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      data: function (params) {
        return {
          term: $.trim(params.term),
          model:obj.model,
          model_id:obj.model_id,
          join_model:obj.join_model,
          join_field_id:obj.join_field_id,
          field_id_name:obj.field_id_name,
          field_name:obj.field_name,
          status:obj.status,
          is_admin:obj.is_admin,
          page: params.page || 1,
          multicolumns:obj.multicolumns,
          whereArr:obj.whereArr,
          whereNotColumns:obj.whereNotColumns,
          whereNotArr:obj.whereNotArr,
          whereRaw:obj.whereRaw,
          multicolumnssearch:obj.multicolumnssearch,
          orderBy:obj.orderBy
        };
      },
      processResults: function (data) {
        if(obj.hasOwnProperty("disabledOptArr")){
            var data_modified = $.map(data.results, function(prObj){
            if(obj.hasOwnProperty("disabledOptArr")){
              if($.inArray(prObj.id,obj.disabledOptArr) != -1){
                prObj.disabled = true;
              }
            }
            return prObj;
          });
          return { results: data_modified };
        }else{
          return {
            results: data.results,
            'pagination':{'more':data.more}
          };
        }
      },
      cache: true
    }
  }).on('select2:select', function(e) {
    var data = e.params.data;
    $(this).next('.select2-container').find('.select2-selection__rendered').text(data.text);
 });
}
function getSingleSelect2ListOld(obj){
  $.ajax({
      url:base_url+'/admin/select2_find_old',
      type:"POST",
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      data: {
          model:obj.model,
          join_model:obj.join_model,
          field_id_name:obj.field_id_name,
          field_name:obj.field_name,
          status:obj.status,
          is_admin:obj.is_admin,
          multicolumns:obj.multicolumns,
          whereArr:obj.whereArr,
          whereNotColumns:obj.whereNotColumns,
          whereNotArr:obj.whereNotArr,
          whereRaw:obj.whereRaw,
          multicolumnssearch:obj.multicolumnssearch,
        },

  }).then(function (data) {
      var option = new Option(data.text, data.id, true, true);
      $(obj.selector).append(option).trigger('change');
      // manually trigger the `select2:select` event
      $(obj.selector).trigger({
          type: 'select2:select',
          params: {
              data: data
          }
      });
  });
}

function country_state(countryid,state_field_name)
{
  $('#'+state_field_name).html('');
  getSingleSelect2List({
      selector:document.getElementById(state_field_name),
      placeholder:'Select State...',
      model:'m_state',
      field_id_name:'stateid',
      field_name:'statename',
      status:1,
      whereArr:[{'countryid':countryid}],
  });
}

function getAge(birthdate,dayfieldname,monthfieldname,yearfieldname)
{
  var now = new Date();

  var yearNow = now.getYear();
  var monthNow = now.getMonth();
  var dateNow = now.getDate();

  var dob = new Date(birthdate.substring(6,10),
      birthdate.substring(0,2)-1,
      birthdate.substring(3,5)
  );

  var yearDob = dob.getYear();
  var monthDob = dob.getMonth();
  var dateDob = dob.getDate();
  var age = {};
  var ageString = yearString = monthString = dayString = "";

  yearAge = yearNow - yearDob;

  if (monthNow >= monthDob)
      var monthAge = monthNow - monthDob;
  else {
      yearAge--;
      var monthAge = 12 + monthNow -monthDob;
  }

  if (dateNow >= dateDob)
      var dateAge = dateNow - dateDob;
  else
  {
      monthAge--;
      var dateAge = 31 + dateNow - dateDob;
      if (monthAge < 0) {
          monthAge = 11;
          yearAge--;
      }
  }
  $('#'+dayfieldname).val('');
  $('#'+monthfieldname).val('');
  $('#'+yearfieldname).val('');
  if (birthdate) {
    $('#'+dayfieldname).val(dateAge);
    $('#'+monthfieldname).val(monthAge);
    $('#'+yearfieldname).val(yearAge);
    $('#full_age').val(yearAge+'-Years '+monthAge+'-Months '+dateAge+'-Days ');
  }
}
function distinctDropdown(obj)
{
    if(this.ajax_call){
      this.ajax_call.abort();
    }
    $('#'+obj.selector).typeahead({
      hint: true,
      highlight: true,
      minLength: 1
    },
    {
      source: function(query, processSync, processAsync ) {
          if(this.ajax_call){
            this.ajax_call.abort();
          }

          this.ajax_call = $.ajax({
              url:base_url+'/admin/autocomplete_data',
              type:'POST',
              beforeSend:function(){
                if(this.ajax_call){
                  this.ajax_call.abort();
                }
              },
              data: {
                  search: query,
                  model:obj.model,
                  field_name:obj.field_name,
                  status:obj.status,
                  deleted_at:obj.deleted_at,
              },
              success:function(data){
                  return processAsync(data);
              },
          });
        },
        limit: 'Infinity',
    });
};

// Common Code for Modal Search
function getCommonModalSearch(obj)
{
  $.ajax({
    'type': 'POST',
    'url': base_url+'/admin/get_modal_search_content',
    'data': {
      modal_file_path:obj.search_modal_file_path,
      patient_tabular_selection:obj.patient_tabular_selection,
      tablular_selection:obj.tablular_selection,
      default_module_name:obj.module_list_name,
    },
    beforeSend:function(){
      $('#hms_loader').show();
    },
    success: function(response){
      if (obj.patient_individual_list) {
        $('#module_content').html(response);
      } else {
        $('body').append(response);
        // Display Modal
        if (obj.from != 'registration') {
          $('#search_modal').modal('show');
        }
      }

      if ($('#search_modal #modal_table_data thead tr').length == 1) {
         $('#search_modal #modal_table_data thead tr').clone(true).appendTo( '#search_modal #modal_table_data thead' );
      }
      $('#search_modal #modal_table_data thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        if (title) {
          $(this).html( '<input type="text" class="form-control text-center" placeholder="Search" />' );
        }
        $( 'input', this ).on( 'keyup change', function () {
          if ( search_modal_table.column(i).search() !== this.value ) {
            search_modal_table
              .column(i)
              .search( this.value )
              .draw();
          }
        });
      });

      var search_modal_table = $('#search_modal #modal_table_data').DataTable({
        "destroy":true,
        orderCellsTop: true,
        fixedHeader: true,
        //responsive:true,
        processing: true,
        serverSide: true,
        scrollY:       "300px",
        scrollX:       true,
        scrollCollapse:true,
        columnDefs: [
            { width: 10, targets: 0 }
        ],
        fixedColumns: true,
        //"scrollX": true,
        "ajax": {
          'type':'POST',
          'url': base_url+'/admin/get_common_search_modal',
          'data': function(data){
            return $.extend( {obj}, data, {
              primary_id: obj.default_primary_id,
              module_name: obj.search_module_name,
              whereNotColumns:obj.whereNotColumns,
              whereNotArr:obj.whereNotArr,
              whereArr:obj.whereArr,
              module_list_name:obj.module_list_name,
              default_foreign:obj.default_foreign,
              isIpdBill:obj.isIpdBill,
              admission:obj.admission
            });
          },
        },
         order: [[1, 'desc']],
        columns: obj.data_column_array,
      });

      $(document).on('change','#module_list', function() {
        search_modal_table.draw();
      });

      $('table').on('draw.dt', function() {
        $('[data-toggle="tooltip"]').tooltip();
      });

      $('#hms_loader').hide();
    }
  });
}
//For Select Radio Button in global modal search
$(document).on("click", "#modal_table_data tbody tr",function(e){
  if (e.target.type !== 'radio') {
    $(':radio', this).trigger('click');
  }
});
$(document).on("hidden.bs.modal", "#search_modal",function(e){
    $("#search_modal").remove();
});
//Clear patient search
$(document).on("click", "#clear_modal_search",function(){
  $('#patname').val('');
  $('#patid').val('');
  $('#patientid').val('');
  $('#modulename').val('');
  $('#moduleid').val('');
  if ($('#patmobileno').length > 0) {
    $('#patmobileno').html('');
  }
  if(window.location.href.indexOf("vital_entries/") != -1){
    var url = window.location.href;
    window.history.replaceState(null, null, url.substring(0, url.lastIndexOf('/')));
  }

});
//Clear provider search
$(document).on("click", "#clear_provider_search",function(){
  $('#providername').val('');
  $('#providerid').val('');
});

// Delete Single Parent Record
var isShow = 0
function deleteSingleParentRecord(obj){
  $.ajax({
      url: base_url+'/admin/check_child_record',
      type:'post',
      dataType: 'json',
      data: {
        primary_id : obj.primary_id,
        parent_tablename:obj.parent_tablename,
        whereArr:obj.whereArr,
      },
      success:function(data){

        if(data.status==true){
          if(isShow == 0){
              isShow = 1
          bootbox.dialog({
          message: "Are you sure you want to delete this record ?",
          title: "Confirm delete",
          buttons: {
            danger: {
              label: "Confirm",
              className: "btn-danger",
              callback: function callback() {
                $.ajax({
                    url:obj.url,
                    type: 'DELETE',
                    dataType: 'json',
                    data: {method: '_DELETE'}
                }).always(function (data) {
                    isShow = 0
                   if (data.status==false) {
                      bootbox.alert({
                          message: data.message,
                          size: 'medium'
                      });
                   }else{
                    if(obj.hasOwnProperty('table')){
                      obj.table.draw();
                    }else if(obj.hasOwnProperty('removeRow')){
                      obj.removeRow.remove();
                    }
                    toastrSuccess('',data.message);
                  }
                });
              }
            },
            main: {
              label: "Cancel",
              className: "btn-primary",
                callback: function callback() {
                    isShow = 0
                }
            }
          },
          onEscape: function() {
            // THMS-471
            isShow = 0
          }
        });
          }
        }else{
            if(isShow == 0) {
                isShow = 1
                bootbox.alert({
                    message: "You can't delete this record, the selected record is associated with another module(s).",
                    size: 'medium',
                    callback: function callback() {
                        isShow = 0
                    }
                });
            }
        }
      }
  });
}
// Delete Multiple Parent Record
function deleteMassDestroyParentRecord(obj){

  $.ajax({
    url: base_url+'/admin/check_child_massdestroy',
    type:'POST',
    dataType: 'json',
    data: {
      primary_id : obj.primary_id,
      parent_tablename:obj.parent_tablename,
      whereArr:obj.whereArr,
    },
    success:function(data){
      if(data.status==true){
        var ids = data.ids;
        if(ids.length != obj.primary_id.length){
          var msg = "Some records have been deleted";
        }else{
          var msg = "Are you sure you want to delete multiple Data/Records?";
        }
      if(isShow == 0) {
          isShow = 1
          bootbox.dialog({
              message: msg,
              title: "Confirm delete",
              buttons: {
                  danger: {
                      label: "Confirm",
                      className: "btn-danger",
                      callback: function callback() {
                          var obj1 = {};
                          obj1[obj.parent_primaryid] = ids;
                          obj1['_method'] = 'DELETE';
                          $.ajax({
                              method: 'POST',
                              url: obj.url,
                              data: obj1
                          }).always(function (data) {
                              isShow = 0
                              if (data.status == false) {
                                  bootbox.alert({
                                      message: data.message,
                                      size: 'medium'
                                  });
                              } else {
                                  if (obj.hasOwnProperty('table')) {
                                      obj.table.draw();
                                  } else if (obj.hasOwnProperty('removeRow')) {
                                      obj.removeRow.remove();
                                  }
                                  toastrSuccess('', data.message);
                              }
                          });
                      }
                  },
                  main: {
                      label: "Cancel",
                      className: "btn-primary",
                      callback: function callback() {
                          isShow = 0
                      }
                  }
              },
              onEscape: function() {
                // THMS-471
                isShow = 0
              }
          });
      }
      }else{
      if(isShow == 0) {
        isShow = 1
        bootbox.alert({
            message: "You can't delete these records, the selected records are associated with another module(s).",
            size: 'medium',
            callback: function callback() {
                isShow = 0
            }
        });
      }
      }
    }
  });
}

//This function is used onclick event on webcam button
function webcam() {
  Webcam.set({
    width: 300,
    height: 300,
    image_format: 'jpeg',
    jpeg_quality: 90
  });
  if(Webcam.attach( '#my_camera' )){
    $('.webcam').removeClass('d-none');
  }
}

// This function is used to take snapshot for webcam functionality
function take_snapshot() {
  Webcam.snap( function(data_uri) {
    $("#webcam_image").val(data_uri);
    document.getElementById('webcam_result').innerHTML = '<img src="'+data_uri+'"/><a id="remove_webcam_image" href="javascript:void(0)" style="display: inline;" onClick="remove_webcam_image()">&#215;</a>';
  });
}

// To clear webcam image
function remove_webcam_image() {
  $('#webcam_result').html('');
  $('#webcam_image').val('');
};

// Quick Patient Add Modal
function quickPatientAdd(obj)
{
  $.ajax({
    'type': 'GET',
    'url': base_url+'/admin/get_quick_add_patient_content',
    'data': {
      modal_file_path:obj.add_patient_modal_file_path,
    },
    success: function(response){
      // Patient Modal Close
      $('#search_modal').modal('hide');

      $('body').append(response);
      // $('body').addClass('modal-open');

      // Open Quick add patient modal
      setTimeout(function () {
        $('#quick_add_patient_modal').modal('show');
        $('#quick_add_patient_modal').on('shown.bs.modal', function (e) {
          $.validator.addMethod("emailPattern", function(value, element, regexpr) {
              if(value.trim()!=''){
                return regexpr.test(value);
              }
              return true;
          }, "Please enter a valid email.");

          $("#quick_add_patient_form").validate({
            ignore:[],
            rules: {
              patcode: {
                required: true,
              },
              regdate:{
                required: true
              },
              bloodgroup:{
                required: true
              },
              firstname: {
                required: true,
                maxlength: 100,
              },
              middlename: {
                maxlength: 100,
              },
              lastname: {
                maxlength: 100,
                required: true,
              },
              gender: {
                required: true
              },
              city: {
                maxlength: 100
              },
              emailid: {
                email: true,
                emailPattern: /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
              },
              mobileno: {
                required: true,
                minlength: session_obj.hospital.mobilenolength,
                maxlength: session_obj.hospital.mobilenolength
              },
            },
            messages: {
              emailid: {
                pattern: "Please enter a valid email address.",
              },
              mobileno: {
                minlength: "Please enter valid mobile number",
              },
            },
            errorPlacement: function (error, element){
              if(element.attr("name") == "gender") {
                $placement=$(element).parent().parent().find('.invalid-feedback');
                error.appendTo($placement);
                $placement.show();
              }else{
                $placement=$(element).parent().find('.invalid-feedback');
                error.appendTo($placement);
                $placement.show();
              }
            },
            highlight: function(element, errorClass, validClass) {
              $(element).parent().addClass('has-danger').removeClass('has-success');
              $placement=$(element).parent().find('.invalid-feedback');
              $placement.show();
            },
            unhighlight: function(element, errorClass, validClass) {
              $(element).parent().removeClass('has-danger').addClass('has-success');
              $placement=$(element).parent().find('.invalid-feedback');
              $(element).removeClass('error');
              $placement.hide();
            }
          });
        });
      }, 500);

    }
  });
}

/*******************Common Master Values************************/
function getCommonModalDataByType(type,maindivid,fieldname,typetext){
  $.ajax({
    beforeSend:function(){
      $('#hms_loader').show();
    },
    data:{'type':type,typetext:typetext.trim()},
    url:base_url+'/admin/commons/create',
    success: function(res){
      $('body').append(res);
      $('#commonmaster_modal_form')[0].reset();
      $('#commonmaster_modal').attr('maindivid',maindivid);
      $('#commonmaster_modal').attr('fieldname',fieldname);
      $('#commonmaster_modal').attr('type',type);
      $('#commonmaster_modal').modal('show');
      $('#hms_loader').hide();
      $('#addcommonmaster_modal input[name=commonmaster_type]').val(type);
      $('#addcommonmaster_modal #cMTypeTxt').text(type.toUpperCase());
      filterCommonmasterTbl(type,$('#hms_cm_grpnames').val());
    }
  });
}
function filterCommonmasterTbl(type,groupname){
  var search_modal_table = $('#commonmaster_modal #commonmaster_tbl').DataTable({
  responsive:true,
  processing: true,
  serverSide: true,
  "ajax": {
    type:'GET',
    url: base_url+'/admin/commons',
    data:{
      type:type,
      groupname:groupname
    },
    complete: function (red) {
      $('#commonmaster_tbl #cm_sel_th_btn').find('i').removeClass('md-check-square').addClass('md-minus-square');
      $('#commonmaster_modal #cm_add_sel_val').prop('disabled',true);
    }
  },
  order: [[1, 'asc']],
  columnDefs: [ {
      orderable: false,
      className: 'select-checkbox',
      targets:   0
  } ],
  select: {
      style:    'multi',
      selector: 'td:first-child'
  },
  columns:[
    {data:'select_row', name:'select_row', orderable: false, searchable: false},
    {data:'groupname', name:'groupname',className: "breakLine"},
    {data:'description', name:'description',className: "breakLine"},
    {data: 'action', name: 'action', orderable: false, searchable: false},
  ],
  'createdRow': function( row, data, dataIndex ) {
    $(row).attr('data-entry-id',data.commonid);
  },
});
}
$(document).on("hidden.bs.modal", "#commonmaster_modal",function(e){
   e.preventDefault();
   $("#commonmaster_modal").remove();
});
$(document).on("click", "#add_commonmaster_btn",function(e){
  e.preventDefault();
  $('#addcommonmaster_modal .modal-title').text('Add Master');
  $('#addcommonmaster_modal input[name=commonmaster_mode]').val('add');
  $('#addcommonmaster_modal input[name=groupname]').val('');
  $('#addcommonmaster_modal [name=description]').val('');
  $('#addcommonmaster_modal input[name=commonmaster_id]').val('');
  $('#addcommonmaster_modal label.error').hide();
  $('#addcommonmaster_modal').modal('show');
  $('#addcommonmaster_modal').css('z-index',1705);
  $('#commonmaster_modal').css('opacity',0.8);
});
$(document).on("submit", "#commonmaster_modal_form",function(e){
  e.preventDefault();
  if($('#commonmaster_modal_form').valid()){
    var formdata = $(this).serialize(); // here $(this) refere to the form its submitting
    $.ajax({
        type: 'POST',
        url: base_url+'/admin/commons',
        data: formdata,
        beforeSend:function(){
          $('#hms_loader').show();
        },
        success: function(res){
          $('#addcommonmaster_modal input[name=groupname]').val('');
          $('#addcommonmaster_modal [name=description]').val('');
          $('#addcommonmaster_modal').modal('hide');
          if(res.success==true){
            toastrSuccess('',res.message);
            var $cMModal=$('#commonmaster_modal');
            $("#commonmaster_modal").modal('hide');
            setTimeout(function(){
              getCommonModalDataByType($cMModal.attr('type'),$cMModal.attr('maindivid'),$cMModal.attr('fieldname'),$cMModal.attr('typetext'));
            },300);
          }else{
            toastrError('',res.message);
          }
          $('#hms_loader').hide();
        },
    });
  }
});
$(document).on("hidden.bs.modal", "#addcommonmaster_modal",function(e){
  $('#commonmaster_modal').css('opacity',1);
  $('body').addClass('modal-open');
});
$(document).on("click","#commonmaster_tbl tbody tr",function(e){
  var cm_tbl_trs=$('#commonmaster_tbl > tbody  > tr');
  var ids = [];
    /*if ($(this).hasClass('selected')) {
        $(this).removeClass('selected');
    }*/
  cm_tbl_trs.each(function(e){
    if($(this).hasClass('selected')){
      ids.push($(this).data('entry-id'));
    }
  });
  if(cm_tbl_trs.length==ids.length){
    $('#commonmaster_tbl #cm_sel_th_btn').find('i').removeClass('md-minus-square').addClass('md-check-square');
  }else{
    $('#commonmaster_tbl #cm_sel_th_btn').find('i').removeClass('md-check-square').addClass('md-minus-square');

  }
  if(ids.length>0){
    $('#commonmaster_modal #cm_add_sel_val').prop('disabled',false);
  }else{
    $('#commonmaster_modal #cm_add_sel_val').prop('disabled',true);
  }
});
$(document).on("click","#commonmaster_tbl #cm_sel_th_btn",function(e){
  $cm_sel_icon=$(this).find('i');

  if($(this).find('i').hasClass('md-check-square')){
    $('#commonmaster_tbl tbody tr').removeClass('selected');
    $cm_sel_icon.removeClass('md-check-square').addClass('md-minus-square');
    $('#commonmaster_modal #cm_add_sel_val').prop('disabled',true);
  }else{
    $('#commonmaster_tbl tbody tr').removeClass('selected').addClass('selected');
    $cm_sel_icon.removeClass('md-minus-square').addClass('md-check-square');

    if($('#commonmaster_tbl tbody tr td').hasClass('dataTables_empty')){
      $('#commonmaster_modal #cm_add_sel_val').prop('disabled',true);
    }else{
      $('#commonmaster_modal #cm_add_sel_val').prop('disabled',false);
    }
  }

    //code for show selected row
        var cm_tbl_trs=$('#commonmaster_tbl > tbody  > tr');
        var cm_values = [];
        cm_tbl_trs.each(function(e){
            if($(this).hasClass('selected')){
                cm_values.push($('td:eq(2)',this).text());
            }
        });
        var rowscnt=cm_values.length;
        if(rowscnt > 0){
            $('span.select-info ').remove('');
            $('div#commonmaster_tbl_info').append('<span class="select-info"><span class="select-item">'+rowscnt+' rows selected</span></span>');
        }else{
            $('span.select-info ').html('');
        }
    //code for show selected row
});
$(document).on("click","#commonmaster_modal #cm_add_sel_val",function(e){
  var cm_tbl_trs=$('#commonmaster_tbl > tbody  > tr');
  var cm_values = [];
  cm_tbl_trs.each(function(e){
    if($(this).hasClass('selected')){
      cm_values.push($('td:eq(2)',this).text());
    }
  });
  cm_values=cm_values.join(', ');
  var cm_maindivid=$('#commonmaster_modal').attr('maindivid');
  var cm_fieldname=$('#commonmaster_modal').attr('fieldname');
  $('#'+cm_maindivid).find('[name='+cm_fieldname+']').val(cm_values);
  $('#commonmaster_modal').modal('hide');
});
$(document).on("click", ".edit_commonmaster_btn",function(e){
  e.preventDefault();
  $this=$(this);
  $('#addcommonmaster_modal .modal-title').text('Edit Master');
  $(".form-control").removeClass("error");
  $('#addcommonmaster_modal input[name=commonmaster_mode]').val('edit');
  $('#addcommonmaster_modal input[name=commonmaster_id]').val($this.data('id'));
  $('#addcommonmaster_modal input[name=groupname]').val($this.closest('tr').find('td:nth-child(2)').text());
  $('#addcommonmaster_modal [name=description]').val($this.closest('tr').find('td:nth-child(3)').text());
  $('#addcommonmaster_modal label.error').hide();
  $('#addcommonmaster_modal').modal('show');
  $('#addcommonmaster_modal').css('z-index',1705);
  $('#commonmaster_modal').css('opacity',0.8);
});
$(document).on("click", ".delete_commonmaster_btn",function(e){
  e.preventDefault();
  var commonid=$(this).data('id');
  bootbox.dialog({
          size: 'small',
              message:'Are you sure you want to delete this record ?',
              title: "Confirm delete",
              buttons: {
                danger: {
                  label: "Confirm",
                  className: "btn-danger",
                  callback: function callback() {
                    $.ajax({
                        url:base_url+'/admin/commons/'+commonid,
                        type: 'DELETE',
                                data: {commonid:commonid,'_method': '_DELETE'},
                        beforeSend:function(){
                          $('#hms_loader').show();
                        },
                        success:function(data){
                            if(data.success==true){
                              var $cMModal=$('#commonmaster_modal');
                              $("#commonmaster_modal").modal('hide');
                              setTimeout(function(){
                                getCommonModalDataByType($cMModal.attr('type'),$cMModal.attr('maindivid'),$cMModal.attr('fieldname'),$cMModal.attr('typetext'));
                              },300);
                              toastrSuccess('',data.message);
                            }else{
                              toastrError('',data.message);
                            }
                            $('#hms_loader').hide();
                        },
                        error: function(response){
                          $('#hms_loader').hide();
                        },
                    });
                  }
              },
                main: {
                  label: "Cancel",
                  className: "btn-primary"
                }
              }
    });
});

/*******************End Common Master Values************************/

// Multi selection array passing to the common search modal
function patient_multi_selection_array(view)
{
  switch(view) {
    case 'General Visit':
      var file_name = 'admin.partials.episode_patient_list';
      var data_column_array =  [
        {data:'select_row', name:'select_row', orderable: false, searchable: false},
        {data:'created_at', name:'created_at',visible :false,searchable: false},
        {data:'episodecode', name:'episodecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'episodedatetime', name:'episodedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patepisodeno', name:'patepisodeno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'age_gender', name:'age_gender',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'unPayable':
      var file_name = 'admin.partials.episode_patient_list';
      var data_column_array =  [
        {data:'select_row', name:'select_row', orderable: false, searchable: false},
        {data:'created_at', name:'created_at',visible :false,searchable: false},
        {data:'episodecode', name:'episodecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'episodedatetime', name:'episodedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patepisodeno', name:'patepisodeno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'age_gender', name:'age_gender',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'Appointment':
      var file_name = 'admin.partials.appointment_patient_list';
      var data_column_array =  [
        {data:'select_row', name:'select_row', orderable: false, searchable: false},
        {data:'created_at', name:'created_at',visible :false,searchable: false},
        {data:'appno', name:'appno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'app_start', name:'app_start',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'UHID', name:'UHID',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'age_gender', name:'age_gender',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'admissions':
      var file_name = 'admin.partials.admission_search_modal';
      var data_column_array =  [
        {data:'select_row', name:'select_row', orderable: false, searchable: false},
        {data:'created_at', name:'created_at',visible :false,searchable: false},
        {data:'admissioncode', name:'admissioncode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'admissiondatetime', name:'admissiondatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'bedno', name:'bedno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'wardname', name:'wardname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'opdbill':
      var file_name = 'admin.partials.bill_search_modal';
      var data_column_array =  [
         {data:'select_row', name:'select_row', orderable: false, searchable: false},
         {data:'created_at', name:'created_at',visible :false,searchable: false},
         {data:'invoicecode', name:'invoicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'invoicedatetime', name:'invoicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'receiptamount', name:'receiptamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'discper', name:'discper',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'discamt', name:'discamt',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'othercharges', name:'othercharges',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'roundoff', name:'roundoff',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'ipdbill':
      var file_name = 'admin.partials.bill_search_modal';
      var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
         {data:'invoicecode', name:'invoicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'invoicedatetime', name:'invoicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'receiptamount', name:'receiptamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'discper', name:'discper',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'discamt', name:'discamt',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'othercharges', name:'othercharges',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'roundoff', name:'roundoff',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
         {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'Diagnostic':
      var file_name = 'admin.partials.diagnostic.advice_search_modal';
      var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'patientcode', name:'patientcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'testadvicecode', name:'testadvicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'testadvicedatetime', name:'testadvicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'casetype', name:'casetype',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'emailid', name:'emailid',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"}
      ];
      break;
    case 'DiagnosticBill':
          var file_name = 'admin.partials.diagnostic.diagnosticbills';
          var data_column_array =  [
              {data:'select_row', name:'select_row', orderable: false, searchable: false},
              {data:'created_at', name:'created_at',visible :false,searchable: false},
              {data:'billcode', name:'billcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
              {data:'invoicedatetime', name:'invoicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
              {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
              {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
              {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          ];
          break;
    case 'Laboratory':
      var file_name = 'admin.partials.laboratory.advice_search_modal';
      var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'patientcode', name:'patientcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'testadvicecode', name:'testadvicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'testadvicedatetime', name:'testadvicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'casetype', name:'casetype',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'emailid', name:'emailid',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"}
      ];
      break;
    case 'LabBill':
      var file_name = 'admin.partials.laboratory.labbills';
      var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'labbillcode', name:'labbillcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'labbilldatetime', name:'labbilldatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
      ];
      break;
    case 'LabBillRefuse':
        var file_name = 'admin.partials.laboratory.labbills_refuse';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'labbillcode', name:'labbillcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'labbilldatetime', name:'labbilldatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          ];
        break;
    case 'DiagnosticRefuse':
        var file_name = 'admin.partials.diagnostic.servicerefuse';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'refusecode', name:'refusecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'refusedate', name:'refusedate',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
        break;
    case 'LabServiceRefuse':
        var file_name = 'admin.partials.laboratory.servicerefuse_modal';
        var data_column_array =  [
            {data:'select_row', name:'select_row', orderable: false, searchable: false},
            {data:'created_at', name:'created_at',visible :false,searchable: false},
            {data:'refusecode', name:'refusecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
            {data:'refusedate', name:'refusedate',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
            {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
            {data:'providername', name:'providername',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
        break;
    case 'Indent':
        var file_name = 'admin.partials.inventory.indent_search_modal';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'indentcode', name:'indentcode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'indentdatetime', name:'indentdatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'indentgeneratedby', name:'indentgeneratedby',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'from_department', name:'from_department',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'to_department', name:'to_department',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
        break;
    case 'purchase_order':
        var file_name = 'admin.partials.inventory.po_search_modal';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'ordercode', name:'ordercode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'orderdatetime', name:'orderdatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'party_vendor', name:'party_vendor',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'grandtotal', name:'grandtotal',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'orderstatus', name:'orderstatus',orderable: false,defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
        break;
    case 'grn_bill':
        var file_name = 'admin.partials.inventory.grn_search_modal';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'grncode', name:'grncode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'grndatetime', name:'grndatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'party_vendor', name:'party_vendor',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'department', name:'department',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
      break;
    case 'purchase_bill':
        var file_name = 'admin.partials.inventory.pb_search_modal';
        var data_column_array =  [
          {data:'select_row', name:'select_row', orderable: false, searchable: false},
          {data:'created_at', name:'created_at',visible :false,searchable: false},
          {data:'invoicecode', name:'invoicecode',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'invoicedatetime', name:'invoicedatetime',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'party_vendor', name:'party_vendor',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'grandtotal', name:'grandtotal',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'discamt', name:'discamt',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'othercharges', name:'othercharges',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'roundoff', name:'roundoff',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          {data:'netamount', name:'netamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          // {data:'paidamount', name:'paidamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
          // {data:'pendingamount', name:'pendingamount',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        ];
      break;
    default:
      var file_name = 'admin.partials.patient_list';
      var data_column_array =  [
        {data:'select_row', name:'select_row', orderable: false, searchable: false},
        {data:'created_at', name:'created_at',visible :false,searchable: false},
        {data:'patientname', name:'patientname',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'city', name:'city',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'gender', name:'gender',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'birthdate', name:'birthdate',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'ageyears', name:'ageyears',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'bloodgroup', name:'bloodgroup',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'mobileno', name:'mobileno',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"},
        {data:'emailid', name:'emailid',defaultContent:"<span class='dashTable' data-dash='dash'>-</span>"}
      ];
  }
  var new_array = {'file_name':file_name, 'data_column_array':data_column_array}
  return new_array;
}

// Removing Combination of server & client side validation message
$('.combination_sc_validation').on('keyup', function() {
  $(this).find('.invalid-feedback').html('');
});
/************ Delete multiple row from grid layout *********/
$(document).on("click",".gridSelectall",function(e) {
  var tblId=$(this).closest('tr').closest('table');

  if($(tblId).find('.gridChkRow').length > 0){
    if(this.checked){
        $(tblId).find('.gridChkRow').prop('checked',true);
    }else{
        $(tblId).find('.gridChkRow').prop('checked',false);
    }
  }else{
    $(this).prop('checked',false);
  }
});
$(document).on("click",".gridChkRow",function(e) {
  var tbodyId=$(this).closest('tr').parent('tbody').attr('id');
  var tblId=$(this).closest('tr').closest('table');

  var totalRow=$('#'+tbodyId).find('.gridChkRow');
  var chkRows=$('#'+tbodyId).find('.gridChkRow:checked');

  if(this.checked){
      if(totalRow.length==chkRows.length){
         $(tblId).find('.gridSelectall').prop('checked',true);
      }
  }else{
      $(tblId).find('.gridSelectall').prop('checked',false);
  }
});

$(document).on("click",".gridChkDelete",function(e) {
  var tbodyId=$(this).data('tableid');
  var tblId=$('#'+tbodyId).closest('table');
  var chkRows=$('#'+tbodyId).find('.gridChkRow:checked');
  if(chkRows.length===0){
    bootbox.alert({
        message: "No rows selected.",
        size: 'small'
    });
    return;
  }else if(chkRows.length===1){
    var msg = "Are you sure you want to delete this record ?";
  }else if(chkRows.length>1){
    var msg = "Are you sure you want to delete multiple Data/Records?";
  }
  bootbox.dialog({
       message:msg,
       title: "Confirm delete",
       buttons: {
         danger: {
           label: "Confirm",
           className: "btn-danger",
           callback: function callback() {
            $.each( chkRows, function( key, value ) {
              $(this).closest('tr').remove();
            });
            $(tblId).find('.gridSelectall').prop('checked',false);
            var billModule=$('#'+tbodyId).data('module');
            if(billModule=="estimate" || billModule=="billing"){
              grandTotal();
              $('input[name="discper"]').trigger('keyup');
              $('input[name="othercharges"]').trigger('keyup');
            }
            else if(billModule=="GRN"){
              grandTotal();
              $('input[name="discper"]').trigger('keyup');
              $('input[name="tcsper"]').trigger('keyup');
              $('input[name="othercharges"]').trigger('keyup');
              // $('input[name="discper"]','input[name="discamt"]','input[name="othercharges"]','input[name="tcsper"]','input[name="tcsamount"]').val('');
            }
           }
         },
         main: {
           label: "Cancel",
           className: "btn-primary"
         }
       }
  });
});
/************ End delete multiple row from grid layout *********/
/************ End delete multiple row from grid test layout *********/
$(document).on("click",".gridChkDeleteTest",function(e) {
    var tbodyId=$(this).data('tableid');
    var tblId=$('#'+tbodyId).closest('table');
    var chkRows=$('#'+tbodyId).find('.gridChkRow:checked');
    if(chkRows.length===0){
        bootbox.alert({
            message: "No rows selected.",
            size: 'small'
        });
        return;
    }else if(chkRows.length===1){
        var msg = "Are you sure you want to delete this record ?";
    }else if(chkRows.length>1){
        var msg = "Are you sure you want to delete multiple Data/Records?";
    }
    bootbox.dialog({
        message:msg,
        title: "Confirm delete",
        buttons: {
            danger: {
                label: "Confirm",
                className: "btn-danger",
                callback: function callback() {
                    $.each( chkRows, function( key, value ) {
                        $(this).closest('tr').remove();
                    });
                    $(tblId).find('.gridSelectall').prop('checked',false);
                    grandTotalRefuse();
                }
            },
            main: {
                label: "Cancel",
                className: "btn-primary"
            }
        }
    });
});
/************ End delete multiple row from grid test layout *********/

/************ Multiple File Preview Before Uploade *********/
$(document).on("click",".inputDocFiles",function(e){
  this.value = null;
});
$(document).on("change",".inputDocFiles",function(e){
  var html='';
  $this=$(this).closest('td');
  $.each(event.target.files, function(item,value){
    var file=URL.createObjectURL(value);
    var filename=event.target.files[item].name;
    var ext=filename.split('.').pop();
    var fileIcon='';
    if(ext=='png' || ext=='jpg'|| ext=='jpeg'){
      fileIcon='<i class="fas fa-image"></i>';
    }else if(ext=='pdf'){
      fileIcon='<i class="fas fa-file-pdf"></i>';
    }else{
      fileIcon='<i class="fas fa-file-word"></i>';
    }
    html+='<a class="btn btn-info btn-sm p-5" title="'+filename+'" style="margin:5px 2px;" href="'+file+'" target="_blank"><div class="dpaDelBtn" data-node="'+item+'"><i class="fas fa-times-circle"></i></div>'+fileIcon+'</a>';
  });
  $this.find('.DocsPrevArea').html(html);
  $this.find('input[name^=pfilesnodes-]').val('');
});
$(document).on("click",".dpaDelBtn",function(e) {
  e.preventDefault();
  $this=$(this);
  if($this.data('mode')!='edit'){

    $input=$this.closest('td').find('.btn-file input');
    $pfilesnodes=$this.closest('td').find('input[name^=pfilesnodes-]');
    $DocsPrevArea=$this.closest('td').find('.DocsPrevArea');
    var files=$input[0].files;

    $value=$pfilesnodes.val();
    if($value!=''){
      $value=$value.split(',');
    }else{
      $value=[];
    }

    if($.inArray($this.data('node'),$value) <= 0){
      $value.push($this.data('node'));
      $pfilesnodes.val($value.join());
    }

    $this.parent().remove();
    if($DocsPrevArea.find('a').length==0){
      $input.val('');
    }
  }else{
    $crTd=$this.closest('td');
    $input=$crTd.prev('td').find('.btn-file input');
    bootbox.dialog({
     size: "small",
     message:"Are you sure you want to delete this record ?",
     title: "Confirm delete",
     buttons: {
       danger: {
         label: "Confirm",
         className: "btn-danger",
         callback: function callback(){
          $this.parent().remove();
          if($crTd.html().trim()==''){
            $input.val('');
          }
          toastrSuccess('','File Deleted successfully');
         }
       },
       main: {
         label: "Cancel",
         className: "btn-primary"
       }
     }
    });
  }
});
/************ End Multiple File Preview Before Uploade *********/



// Disabled button after form submit
$('form').submit(function(){
  if ($(this).valid() == true) {
      $(this).find('button[type="submit"]').attr('disabled', 'disabled');
  }
  return true;
});

$('.modal').on('shown.bs.modal', function (e) {
  var id = $(this).attr('id');
  if ($('#'+id+' button').is(':disabled')) {
    $(this).find('button[type="submit"]').removeAttr('disabled');
  }
});
/******** Unauthorized Redirecition ********************/
$(document).ajaxError(function(event, jqxhr, settings, exception) {
    if(exception == 'Unauthorized'){
        window.location = base_url+'/login';
    }
});

/********** End Unauthorized Redirecition**********************/
/********** toggle status update code **********************/
function updateStatus(obj) {
    $.ajax({
        method: 'POST',
        url: base_url+'/admin/update_status',
        data: {
            id:obj.id,
            status:obj.status,
            table_name:obj.table_name,
            id_field_name:obj.id_field_name,
            status_field_name:obj.status_field_name
        },
        beforeSend:function(){
            $('#hms_loader').show();
        },
        success:function(data){
            obj.table.ajax.reload( null, false );
            setTimeout(function(){$('#hms_loader').hide();}, 5000);
            if(data.status == false){
                toastrError('',data.message);
            }else{
                toastrSuccess('',data.message);
            }

        },
        error: function(response){
            $('#hms_loader').hide();
        },
    });

}
/********** toggle status update code **********************/
/** valid call **/
function valid_data(element) {
    $element = $(element);
    //Remove whitespace
    if ( $element.is(':input') || $element.is(':textarea') ) {
        $element.val($.trim($element.val()));
    }
    $element.valid();
}
/** valid call **/
var popupBlockerChecker = {
    check: function(popup_window){
        var scope = this;
        if (popup_window) {
            if(/chrome/.test(navigator.userAgent.toLowerCase())){
                setTimeout(function () {
                    scope.is_popup_blocked(scope, popup_window);
                },200);
            }else{
                popup_window.onload = function () {
                    scope.is_popup_blocked(scope, popup_window);
                };
            }
        } else {
            scope.displayError();
        }
    },
    is_popup_blocked: function(scope, popup_window){
        if ((popup_window.innerHeight > 0)==false){
            scope.displayError();
        }
    },
    displayError: function(){
       alert("Popup Blocker is enabled! Please add this site to your exception list.");
    }
};

function getvalStatus(sel)
{
  if (sel.name=='pastPregStatus' && sel.value=='No') {
    $('.p').find('input:text').val('');
    $field1Status=$form.find("select[name=pastPregStatus]");
     $field1Status.val('No');
     callGDStatusTblAction($field1Status.data('tableid'),'No');
     $form.find("select[name=pastPregStatus]").prop("disabled", true);
  }
  if (sel.name=='abortionStatus' && sel.value=='No') {
    $('.a').find('input:text').val('');
    $field2Status=$form.find("select[name=abortionStatus]");
    $field2Status.val('No');
    callGDStatusTblAction($field2Status.data('tableid'),'No');
    $form.find("select[name=abortionStatus]").prop("disabled", true);
  }

}

//code for redirect flash
function redirectWithFlashMessage(redirect, status, message) {
    var params = {
        status : status,
        message : message
    };
    $.ajax({
        type: 'POST',
        url: base_url+'/admin/flash_data',
        data: params
    }).done(function () {
        window.location.href = redirect;
    });
}
//code for redirect flash
