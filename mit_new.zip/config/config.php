<?php
return[
  'developer_admin'=>[
    'email'=>'admin@admin.com',
    'code'=>'DEVSADMIN'
  ],
  'days'=>[
    'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'
  ],
  'months'=>[
    '01'=>'January',
    '02'=>'February',
    '03'=>'March',
    '04'=>'April',
    '05'=>'May',
    '06'=>'June',
    '07'=>'July',
    '08'=>'August',
    '09'=>'September',
    '10'=>'October',
    '11'=>'November',
    '12'=>'December'
  ],
   'documenttypes' => [
    'bill'=>'Bill',
    'payment_entry'=>'Payment Entry',  
   ],
   'deault_date_pattern' => 'Y-m-d',
   'documenttypes_tbl' => [
      'Bill'=> [
        'tbl'=>'App\Models\Bill',
        'code'=>'billcode',
        'codeid'=>'billcodeid'
      ],      
   ],
   'codegeneration_pattern' => [
    'doctypecode'=>'[DOC]',
    'year'=>'[YYYY]',
    'year_month'=>'[YYMM]',
    'month_year'=>'[MMYY]',
    'year_year'=>'[YY-YY]',
    'year_sr'=>'[YYSR]',
    'month_sr'=>'[MMSR]',
    'sr'=>'[SR]',
   ],
  'consent_template'=>[
    'Full Name'=>'{{full_name}}',
    'Contact No'=>'{{contact_no}}',
    'Address'=>'{{address}}',
    'Blood Group'=>'{{blood_group}}',
    'Age'=>'{{age}}',
  ],
 
 
];
