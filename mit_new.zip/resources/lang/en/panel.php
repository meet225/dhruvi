<?php

return [
    'site_title' => 'S S Tredig',
    'site_tag' => '',
    'site_full_title' => 'S S Tredig',
];
