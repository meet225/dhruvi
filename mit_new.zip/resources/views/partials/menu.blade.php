<div class="site-menubar">
  <div class="site-menubar-body">
    <div>
      <div>
        <ul class="site-menu" data-plugin="menu">
          <li class="site-menu-item">
            <a class="animsition-link" href="#">
                <i class="site-menu-icon md-view-dashboard" aria-hidden="true"></i>
                <span class="site-menu-title">Dashboard</span>
            </a>
          </li>
           
            @can('user_access')
            <li class="site-menu-item {{ request()->is("admin/users") || request()->is("admin/users/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route("admin.users.index") }}">
                <span class="site-menu-title">Users</span>
              </a>
            </li>
            @endcan

            @can('permission_access')
            <li class="site-menu-item {{ request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.permissions.index') }}">
                <span class="site-menu-title">Permission</span>
              </a>
            </li>
            @endcan
            
            @can('role_access')
            <li class="site-menu-item {{ request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.roles.index') }}">
                <span class="site-menu-title">Role</span>
              </a>
            </li>
            @endcan

            @can('customer_access')
            <li class="site-menu-item {{ request()->is("admin/customers") || request()->is("admin/customers/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.customers.index') }}">
                <span class="site-menu-title">Customer</span>
              </a>
            </li>
            @endcan

            @can('item_access')
            <li class="site-menu-item {{ request()->is("admin/items") || request()->is("admin/items/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.items.index') }}">
                <span class="site-menu-title">Items</span>
              </a>
            </li>
            @endcan

            <li class="site-menu-item {{ request()->is("admin/bills") || request()->is("admin/bills/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.bills.index') }}">
                <span class="site-menu-title">bills</span>
              </a>
            </li>

            <li class="site-menu-item {{ request()->is("admin/payment_entries") || request()->is("admin/payment_entries/*") ? "active" : "" }}">
              <a class="animsition-link" href="{{ route('admin.payment_entries.index') }}">
                <span class="site-menu-title">Payment</span>
              </a>
            </li>
        </ul>
      </div>
    </div>
  </div>
</div>