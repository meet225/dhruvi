<!DOCTYPE html>
<html>
<head>
	<title>{{ $print_title }}</title>
	<style>
	    @page { margin: {{ $page_margin }}; }
	</style>
	<link rel="stylesheet" href="{{public_path('assets/css/print.css')}}">
</head>
<body>
	<!-- Header -->
	<div id="header">
   		@include('admin.printreport.billing.bill.header')
	</div>

	<!-- Main Content -->
	<div id="content">
	    <table id="charge_detail" class="table" cellspacing="0" style="margin-bottom: 20px;">
	    	<thead class="border-bottom">
	    		<tr>
	    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
	    			<th style="text-align: center;" class="pb-10">Charge Code</th>
	    			<th style="text-align: center;" class="pb-10">Charge Name</th>
		    		<th style="text-align: center;" class="pb-10">Qty</th>
		    		<th style="text-align: center;" class="pb-10">Charges</th>
		    		<th style="text-align: center;" class="pb-10">Discount(%)</th>
		    		<th style="text-align: center;" class="pb-10">Total Amount</th>
	    		</tr>
	    	</thead>
	    	<tbody>
	    		@if($bill->chargepricedetails)
	    			@php $sr=1 @endphp
		    		@foreach($bill->chargepricedetails as $cpdetails)
		    		<tr class="align-center">
			    		<td class="border-bottom">{{ $sr }}</td>
			    		<td class="border-bottom">{{ $cpdetails->charge->chargecode }}</td>
			    		<td class="border-bottom">{{ $cpdetails->charge->chargename }}</td>
			    		<td class="border-bottom">{{ $cpdetails->duration }}</td>
			    		<td class="border-bottom">{{ $cpdetails->chargerate }}</td>
			    		<td class="border-bottom">{{ $cpdetails->discper }}</td>
			    		<td class="border-bottom">{{ $cpdetails->totalamount }}</td>
		    		</tr>
		    		@php $sr++ @endphp
		    		@endforeach
		    	@else
		    		<tr>No data found.</tr>
		    	@endif
	    	</tbody>
	    </table>
	    <table id="footer_table" class="table">
			<tbody>
				<tr>
					<td><strong>Grand Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $bill->totalamount }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td><strong>Discount &nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $bill->discper ?? 'N/A'}} % ({{$bill->discamt??'N/A'}}) </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td><strong>Other Charges &nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $bill->othercharges ?? 'N/A'}} </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td><strong>Payable Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong class="align-left">{{ $bill->netamount }}</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td><strong>Receivable Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $receivable_amt }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</tbody>
		</table>

		@if(!$bill->refunds->isEmpty())
			<div class="page-break"></div>

			<center><h4 style="padding-top: 5px;padding-bottom: 5px;background: #e6e4e4">Refund Against Bill</h4></center>
			<table class="table" cellspacing="0">
		    	<thead class="border-bottom">
		    		<tr>
		    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
		    			<th style="text-align: center;" class="pb-10">Refund Code</th>
		    			<th style="text-align: center;" class="pb-10">Refund Date</th>
			    		<!-- <th style="text-align: center;" class="pb-10">Receipt Amount</th> -->
			    		<th style="text-align: center;" class="pb-10">Reason For</th>
			    		<th style="text-align: center;" class="pb-10">Payment Mode</th>
			    		<th style="text-align: center;" class="pb-10">Refunded Amount</th>
		    		</tr>
		    	</thead>
		    	<tbody>
	    			@php $sr=1 @endphp
		    		@foreach($bill->refunds as $rfdetails)

		    		@php
			        	$refdatetime = display_datetime(['datetime' => $rfdetails->refunddatetime,'select_datepattern' => TRUE]);
			     	@endphp
		    		<tr class="align-center">
			    		<td class="border-bottom">{{ $sr }}</td>
			    		<td class="border-bottom">{{ $rfdetails->refundcode }}</td>
			    		<td class="border-bottom">{{ $refdatetime }}</td>
			    		<!-- <td class="border-bottom">{{ $bill->receiptdetails[0]->receiptamount }}</td> -->
			    		<td class="border-bottom">{{ $rfdetails->remarks }}</td>
			    		<td class="border-bottom">{{ $rfdetails->paymentmode }}</td>
			    		<td class="border-bottom">{{ $rfdetails->receiptamount }}</td>
		    		</tr>
		    		@php $sr++ @endphp
		    		@endforeach
		    	</tbody>
		    </table>
		    <table class="table" cellspacing="0">
			<tbody>
				<tr>
					<td class="align-right"><strong>Refunded Amount : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span>{{ $bill->refunds->sum('receiptamount') }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</tbody>
		</table>
	    @endif
	</div>	
</body>
</html>