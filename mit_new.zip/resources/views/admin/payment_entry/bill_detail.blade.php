<table class="table table-bordered" id="tbl_hms">
   <thead>
      <tr>
         <th width="300">Bill Code</th>
         <th width="200">Bill Date</th>
         <th>Bill Amount</th>
         <th>Pending Amount</th>
         <th>Paid Amount</th>
         <th>Paying Amount<span class="required">*</span></th>
      </tr>
   </thead>
   <tbody>
      @if(!$bill->isEmpty())
      @foreach($bill as $key=>$billdetails)
      <?php
         //echo "<pre>";print_r($billdetails->toArray());
         $invoiceamount = number_format($billdetails->netamount, 2, '.', '');
         $pendingamount = number_format($billdetails->pendingAmount, 2, '.', '');
         $paidAmount = number_format($billdetails->paidAmount, 2, '.', '');
      ?>

      <tr class="bill_grid" id="row-{{ $key }}">
         <input type="hidden" name="purchasebillid-{{ $key }}" value="{{ $billdetails->id }}">
         <td width="300">
            <div class="d-flex">
               <input type="text" class="form-control" name="invoicecode-{{ $key }}" value="{{ $billdetails->billcode }}" readonly>
            </div>
            <div class="invalid-feedback"></div>
         </td>
         <td width="200">
            <input type="text" class="form-control" name="invoicedatetime-{{ $key }}"  value="{{date('d-m-Y H:i', strtotime($billdetails->billdatetime))}}" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" name="invoiceamount-{{ $key }}" value="{{ $invoiceamount }}" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" name="pendingamount-{{ $key }}" value="{{ $pendingamount }}" id="pendingamount-{{ $key }}" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control" id ="paidAmount-{{ $key }}" value="{{ $paidAmount }}" readonly>
            <div class="invalid-feedback"></div>
         </td>
         <td>
            <input type="text" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" name="payingamount-{{ $key }}" id="payingamount-{{ $key }}" value="0.00">
            <div class="invalid-feedback"></div>
         </td>
      </tr>
      @endforeach
      @else
      <tr>
         <td colspan="6" style="text-align: center;">No data found.</td>
      </tr>
   @endif
   <?php //exit; ?>
   </tbody>
</table>
