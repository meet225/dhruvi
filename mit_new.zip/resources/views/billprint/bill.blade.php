<!DOCTYPE html>
<html style="background-color: #d7ca6acc;">
<head>
	<title>Bill</title>
	<style>

	    @page { margin: {{ $page_margin }}; }
	</style>
	<link rel="stylesheet" href="{{public_path('assets/css/print.css')}}">
</head>
<body >
	<!-- Header -->
	<div id="header">
   		@include('billprint.header')
	</div>

	<!-- Footer -->
	<div id="footer">
	   @include('billprint.footer')
	</div>

	<!-- Main Content -->
	<div id="content">
	    <table id="charge_detail" class="table" cellspacing="0" style="margin-bottom: 30%;margin-top: 3%;">
	    	<thead class="border-bottom">
	    		<tr>
	    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
	    			<th style="text-align: center;" class="pb-10">Items</th>
		    		<th style="text-align: center;" class="pb-10">Qty</th>
		    		<th style="text-align: center;" class="pb-10">Day</th>
		    		<th style="text-align: center;" class="pb-10">Rate</th>
		    		<th style="text-align: center;" class="pb-10">Total</th>
	    		</tr>
	    	</thead>
	    	<tbody>
	    		@if($Bill->billdetails)
	    			@php $sr=1 @endphp
		    		@foreach($Bill->billdetails as $cpdetails)
		    		<tr class="align-center">
			    		<td>{{ $sr }}</td>
			    		<td>{{ $cpdetails->item->name }}</td>
			    		<td>{{ $cpdetails->days }}</td>
			    		<td>{{ $cpdetails->qty }}</td>
			    		<td>{{ $cpdetails->rate }}</td>
			    		<td>{{ $cpdetails->netamount }}</td>
		    		</tr>
		    		@php
		    		 $sr++ 
		    		@endphp
		    		@endforeach
		    	@else
		    		<tr>No data found.</tr>
		    	@endif
	    	</tbody>
	    </table>
	    <table class="table" cellpadding="4" cellspacing="6">
			<tbody>
				<tr>
					<td class="align-right"><strong>Grand Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $Bill->grandtotal }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Discount &nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $Bill->discper }} % ({{$Bill->discamt}})</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Other Charges  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left">{{ $Bill->othercharges??'N/A' }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Net Amount : &nbsp;&nbsp;&nbsp;&nbsp;</strong><span>{{ $Bill->netamount }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>

				<tr>
					<?php
						$f = new \NumberFormatter( locale_get_default(), \NumberFormatter::SPELLOUT );
						$word = $f->format($Bill->netamount);
					?>
					<td class="border-top border-bottom"><strong>Amount in Words : {{ ucwords($word) }}</strong></td>
				</tr>

			</tbody>
		</table>
		@if(isset($payment))
			<div class="page-break"></div>

			<center><h4 style="padding-top: 5px;padding-bottom: 5px;background: #e6e4e4">Payment Against Bill</h4></center>
			<table class="table" cellspacing="0">
		    	<thead class="border-bottom">
		    		<tr>
		    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
		    			<th style="text-align: center;" class="pb-10">Payment Code</th>
		    			<th style="text-align: center;" class="pb-10">Payment Date</th>
			    		<th style="text-align: center;" class="pb-10">Received Amount</th>
		    		</tr>
		    	</thead>
		    	<tbody>
	    			@php $sr=1; $sumTotal = 0; @endphp
		    		@foreach($payment as $payments)

		    		@php
			        	$datetime = date('d-m-Y H:i', strtotime($payments->paymentdatetime));
			     	@endphp
		    		<tr class="align-center">
			    		<td class="border-bottom">{{ $sr }}</td>
			    		<td class="border-bottom">{{ $payments->paymentcode }}</td>
			    		<td class="border-bottom">{{ $datetime }}</td>
			    		<td class="border-bottom">{{ $payments->payingamount }}</td>
		    		</tr>
		    		@php $sr++; $sumTotal = $sumTotal + $payments->payingamount; @endphp
		    		@endforeach
		    	</tbody>
		    </table>
		    <table class="table" cellspacing="0">
			<tbody>
				<tr>
					<td class="align-right"><strong>Total Received Amount : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span>{{ $sumTotal }}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</tbody>
		</table>
	    @endif
	</div>	
</body>
</html>