<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;
class BillDetail extends Model
{
    use SoftDeletes;

    public $table = 'd_bills';
    protected $primaryKey = 'id';
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'billid',
        'itemid',
        'days',
        'qty',
        'rate',
        'netamount',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function item()
    {
        return $this->belongsTo(Item::class,'itemid');
    }
}
