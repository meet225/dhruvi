<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \App\Traits\UserActionsBy;
use App\Models\Master\Medicine;

class DocumentType extends Model
{
    use SoftDeletes;
    public $table = 'm_documenttype';
    protected $primaryKey = 'typeid'; 

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'typecode',
        'typename',
    ]; // mandatory fields when add from request.

    public function codegenerations()
    {
        return $this->hasMany(\App\Models\CodeGeneration::class,'typeid')->latest();
    }
}