<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CodeGeneration;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use DataTables;
use App\Models\Master\DocumentType;

class CodeGenerationsController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('code_generation_view'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.code_generations.create');
    }

    public function store(Request $request)
    {
        $tags_separator = 'F';
        if ($request->input('spc_char') == '\\') {
            $tags_separator = 'B';
        } elseif ($request->input('spc_char') == '-') {
            $tags_separator = 'D';
        } elseif ($request->input('spc_char') == '') {
            $tags_separator = null;
        }
        $data = CodeGeneration::where('typeid',$request->input('typeid'))->latest()->first();
        if ($data) {
            CodeGeneration::where('typeid',$request->input('typeid'))->update(['status'=>'0']);
        }
        $insert_data = $request->all();
       

        $last_str = substr($request->input('pattern'), -1);
        if($last_str == '/' || $last_str == '\\' || $last_str == '-'){
            $pattern = substr($request->input('pattern'), 0, -1);
        }else{
            $pattern = $request->input('pattern');
        }

        if ($request->input('spc_char') == '') {
            $ptn_exp = explode('[', $pattern);            
            $pattern = '';
            for ($i=1; $i < count($ptn_exp); $i++) { 
                if ($i == 1) {
                    $pattern .= '['.$ptn_exp[$i];
                } else {
                    $pattern .= '~['.$ptn_exp[$i];                    
                }
            }
        }
        $insert_data['pattern'] = str_replace(array(' ',','), '',$pattern);
        $insert_data['tags_separator'] = $tags_separator;

        /*Bug ID : 4224*/
        $doctype = DocumentType::select('typename')->where('typeid',$request->typeid)->where('hospid',session('login_data.hospital.id'))->first();
        $docTblArr=config('config.documenttypes_tbl');
        $docArr=[];
        foreach ($docTblArr as $key => $doc) {
            if($key==$doctype->typename){
                array_push($docArr,$doc);
            }
        }
        if(!empty($docArr)){
            $code = app('App\Http\Controllers\Admin\CommonController')->CodeGenerationPattern($doctype->typename,$request->startwith,false,$insert_data);
            $foundRecord = $docArr[0]['tbl']::where($docArr[0]["code"],$code['generated_code'])->where('hospid',session('login_data.hospital.id'))->withTrashed()->first();
            if ($foundRecord!=null) {
                return redirect()->back()->with('message', 'This pattern is already exists.');
                // return Redirect::back()->withErrors(['msg' => 'This pattern is already exists.']);
            }else{
                // save pattern
                $code_generation = CodeGeneration::create($insert_data);
                return redirect()->route('admin.code_generations.index')->with('message', 'Code Generated successfully.');
            }
        }
        /*End Bug ID : 4224*/
    }

    public function fetch_codegen_data($typeid)
    {
        $data = CodeGeneration::where('typeid',$typeid)->latest()->first();
        return response()->json($data);
    }

}
