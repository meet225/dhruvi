<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Bill;
use App\Models\PaymentEntry;
use App\Models\PaymentEntryDetail;
use App\Models\Lookupfixed;
use Symfony\Component\HttpFoundation\Response;
use Gate;
use DataTables;
use Carbon\Carbon;
use DB;

class PaymentEntryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        abort_if(Gate::denies('payment_entry_view'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if($request->ajax()) {
            $data = PaymentEntry::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })
                ->addColumn('action', function ($row) {
                    $url = url('admin/payment_entries/' . $row->invpaymententryid);
                    $urlprint = url('admin/print/billpayment?id=' . $row->invpaymententryid);
                    $btn  = "";
                    /* if(\Gate::allows('payment_entry_view')){
                        $btn .= '<a href="' . $url . '" class="btn btn-primary btn-xs mb-1">View</a> ';
                    } */
                    $btn .= '<a href="' . $urlprint . '" class="btn btn-info btn-xs mb-1">Print</a> ';
                    return $btn;
                })->editColumn('paymentdatetime', function ($row) {
                    if($row->paymentdatetime){
                        return Carbon::parse($row->paymentdatetime)->format('d-m-Y H:i');
                    }
                })
                ->addColumn('customer', function ($row) {
                    if ($row->partyid) {
                        $customer = $row->customer->name;
                        $customer_length = strlen($customer);
                        if ($customer_length > 25) {
                            $customer = '<span data-toggle="tooltip" data-placement="top" title="'.$customer.'">'.substr($customer,0,22).'...</span>';
                        }
                        return $customer;
                    }
                })
                ->rawColumns(['action','customer'])
                ->make(true);
        }

        return view('admin.payment_entry.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort_if(Gate::denies('payment_entry_add'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $autogenrcode = app('App\Http\Controllers\Admin\CommonController')->updatedCodeGenPattern(config('config.documenttypes.payment_entry'),'\App\Models\PaymentEntry','paymentcode','paymentcodeid');
        $paymentcode = app('App\Http\Controllers\Admin\CommonController')->CodeGenerationPattern(config('config.documenttypes.payment_entry'),$autogenrcode,true);
        $paymentmode = Lookupfixed::where('keyname','paymentmode')->pluck('keyvalue','lookupfixid');
        return view('admin.payment_entry.form',compact('paymentcode','paymentmode'));
    }

    public function store(Request $request)
    {
        $insert_data = $request->all();
        /*print_r($insert_data);
        exit();*/
        $insert_data['partyid']=$insert_data['customerid'];        
        if($request->input('paymentdatetime')){
            $insert_data['paymentdatetime'] = Carbon::parse($request->input('paymentdatetime'))->format('Y-m-d H:i:s');
        }
        // $insert_data['paidamount'] = $request->paidamount;
        if($request->input('transactiondate')){
            $insert_data['transactiondate'] = Carbon::parse($request->input('transactiondate'))->format('Y-m-d');
        }
        $payment_entry = PaymentEntry::create($insert_data);

        if($payment_entry){
            $keys = array_keys($insert_data);
            $pattern='/purchasebillid-/';
            $rows = preg_grep($pattern, $keys);

            foreach($rows as $key => $val){
                $row_id=explode('-', $val)[1];
                $insertArr['invpaymententryid']=$payment_entry->invpaymententryid;
                $insertArr['billid']=$insert_data['purchasebillid-'.$row_id];
                $insertArr['invoiceamount']=$insert_data['invoiceamount-'.$row_id];
                $insertArr['payingamount']=$insert_data['payingamount-'.$row_id];
                $pendingamount = $insert_data['pendingamount-'.$row_id];
                if($insertArr['payingamount']!=0){
                    if ($insertArr['payingamount'] == $pendingamount) {
                      Bill::where('id',$insertArr['billid'])->update(['billpay'=>1]);
                    }
                    PaymentEntryDetail::create($insertArr);
                }
            }
        }
        return response()->json(['success'=>true,'message'=>'Payment entry added successfully.']);
    }

    public function show(PaymentEntry $payment_entry)
    {
        // echo "<pre>";print_r($payment_entry);exit;
        abort_if(Gate::denies('inv_purchase_bill_return_view'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.payment_entry.view', compact('payment_entry'));
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function getPartyBills(Request $request)
    {
        $html = '';
        if(isset($request->customerid) && !empty($request->customerid)){
            $whereArr = [
                'bills.customerid'=>$request->customerid,
                'bills.billpay'=>0
            ];
            $data = Bill::selectRaw('bills.id,bills.billcode,bills.billdatetime,bills.netamount,bills.netamount-ifnull(sum(p_entry.payingamount),0) as pendingAmount, ifnull(sum(p_entry.payingamount),0) as paidAmount')
                ->leftJoin('d_invpaymententry as p_entry','p_entry.billid','=','bills.id')
                ->where($whereArr)
                ->whereNull('bills.deleted_at')
                ->whereNull('p_entry.deleted_at')
                ->groupBy('bills.id')
                ->havingRaw('pendingAmount>0')
                ->orderBy('bills.created_at','desc')
                ->get();
            // print_r($data);
            // exit();
            $html = view("admin.payment_entry.bill_detail")->with(["bill" => $data])->render();
            // echo "<pre>";print_r($data->toArray());
            // exit();
        }
        return response()->json($html);
    }
}
