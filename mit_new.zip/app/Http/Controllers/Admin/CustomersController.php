<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Customer\MassDestroyCustomerRequest;
use App\Http\Requests\Customer\StoreCustomerRequest;
use App\Http\Requests\Customer\UpdateCustomerRequest;
use App\Models\Role;
use App\Models\Customer;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use DataTables;

class CustomersController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('customer_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if($request->ajax()) {
            $data=Customer::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })
                ->addColumn('action', function ($row) {
                    $url = url('admin/customers/' . $row->id);
                    $btn  = "";
                    /*if(\Gate::allows('customer_show')){
                        $btn .= '<a href="' . $url . '" class="btn btn-info btn-xs">View</a> ';
                    }*/
                    if(\Gate::allows('customer_edit')){
                        $btn .= '<a href="' . $url . '/edit" class="btn btn-primary btn-xs">Edit</a> ';
                    }
                    if(\Gate::allows('customer_delete')){
                        $btn .= '<a href="' . $url . '" class="delete_row btn btn-danger btn-xs ">Delete</a>';
                    }
                    return $btn;
                })->editColumn('status', function ($row) {
                    if($row->status==1)
                        return '<span class="badge badge-success ml-1">Active</span>';
                    else
                        return '<span class="badge badge-secondary ml-1">InActive</span>';
                })
                ->rawColumns(['action','status'])
                ->make(true);
        }

        return view('admin.customers.index');
    }

    public function create()
    {
        abort_if(Gate::denies('customer_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.customers.create');
    }

    public function store(StoreCustomerRequest $request)
    {   
        $insert_data = $request->all();
        $insert_data['mobile_no'] = preg_replace('/[^0-9]/', '',$request->input('mobile_no'));
        Customer::create($insert_data);
        return redirect()->route('admin.customers.index')->with('message', 'Customer added successfully.');

    }

    public function edit(Customer $customer)
    {
        abort_if(Gate::denies('customer_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.customers.edit', compact('customer'));
    }

    public function update(UpdateCustomerRequest $request, Customer $customer)
    {
        $customer->update($request->all());
        return redirect()->route('admin.customers.index')->with('message', 'Customer updated successfully.');
    }

    public function show(Customer $customer)
    {
        abort_if(Gate::denies('customer_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.customers.show', compact('customer'));
    }

    public function destroy(Customer $customer)
    {
        abort_if(Gate::denies('customer_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if($customer->delete()){
            return response()->json([
                'status' => true,
                'message' => 'Record deleted successfully!',
            ]);
        }
        response()->json([
            'status' => false,
            'message' => 'Record not deleted successfully!',
        ]);
    }

    public function massDestroy(MassDestroyCustomerRequest $request)
    {
        Customer::whereIn('id', request('ids'))->delete();
        return response()->json([
                'status' => true,
                'message' => 'Records deleted successfully!',
            ]);
        /*return response(null, Response::HTTP_NO_CONTENT);*/
    }
}
