<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Bill;
use App\Models\BillDetail;
use App\Models\PaymentEntry;
use App\Models\PaymentEntryDetail;
use App\Models\Lookupfixed;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\Inventory\Bill\StoreBillRequest;
use App\Http\Requests\Inventory\Bill\UpdateBillRequest;
use App\Http\Requests\Inventory\Bill\MassDestroyBillRequest;
use Gate;
use DataTables;
use DB;
use Carbon\Carbon;
class BillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        /*abort_if(Gate::denies('bill_view'), Response::HTTP_FORBIDDEN, '403 Forbidden');*/
        if($request->ajax()) {
            $data = Bill::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('select_row', function ($row) {
                    return '';
                })
                ->addColumn('action', function ($row) {
                    $urlprint = url('admin/print/bill?id=' . $row->id);
                    $url = url('admin/bills/' . $row->id);
                    http://localhost/bill/admin/print/bill?id=1
                    $btn  = "";
                    // if(\Gate::allows('inv_purchase_bill_view')){
                    $btn .= '<a href="' . $url . '" class="btn btn-primary btn-xs mb-1">View</a> ';
                   
                    $btn .= '<a href="' . $urlprint . '" class="btn btn-info btn-xs mb-1">Print</a> ';
                    return $btn;
                })->editColumn('billdatetime', function ($row) {
                  return Carbon::parse($row->billdatetime)->format('d-m-Y H:i');
                })
                ->addColumn('customer', function ($row) {
                    if ($row->customerid) {
                        $customer = $row->customer->name;
                        $customer_length = strlen($customer);
                        if ($customer_length > 25) {
                            $customer = '<span data-toggle="tooltip" data-placement="top" title="'.$customer.'">'.substr($customer,0,22).'...</span>';
                        }
                        return $customer;
                    }
                })
                /*->addColumn('paidamount', function ($row) {
                    if ($row->Billid) {
                        if(isset($row->paymentdetails[0])){
                            $paidamount = $row->paymentdetails[0]->paidamount;
                        }else {
                            $paidamount = 0;
                        }
                        return number_format((float)$paidamount, 2, '.', '');
                    }
                })
                ->addColumn('pendingamount', function ($row) {
                    if ($row->Billid && $row->netamount) {
                        if(isset($row->paymentdetails[0])){
                            $paidamount = $row->paymentdetails[0]->paidamount;
                        }else {
                            $paidamount = 0;
                        }

                        $pendingamount = $row->netamount - $paidamount;
                        return number_format((float)$pendingamount, 2, '.', '');
                    }
                })*/
                // ->orderColumn('billcode', function($query,$order) {
                //     $query->orderByRaw('CAST(billcodeid AS UNSIGNED) '.$order);
                // })
                // ->orderColumn('customer', function($query,$order) {
                //     $query->leftJoin('customers','bills.customerid','=','customers.id')
                //         ->orderBy('customers.name', $order);
                // })
                // ->filterColumn('customer', function($query, $keyword) {
                //     $query->whereHas('customer', function ( $q ) use ( $keyword ) {
                //         $q->where('customer', 'LIKE', "%$keyword%");
                //     });
                // })
                /*->filterColumn('paidamount', function ($query, $keyword) {
                    $query->whereHas('paymentdetails', function ( $q ) use ( $keyword ) {
                        $q->whereRaw("payingamount LIKE ?",  "%$keyword%");
                    });
                })*/
                ->rawColumns(['action','customer'/*, 'paidamount', 'pendingamount'*/])
                ->make(true);
        }
        return view('admin.purchase_bills.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /*abort_if(Gate::denies('inv_purchase_bill_add'), Response::HTTP_FORBIDDEN, '403 Forbidden');*/
        $autogenrcode = app('App\Http\Controllers\Admin\CommonController')->updatedCodeGenPattern(config('config.documenttypes.bill'),'\App\Models\Bill','billcode','billcodeid');
        $billcode = app('App\Http\Controllers\Admin\CommonController')->CodeGenerationPattern(config('config.documenttypes.bill'),$autogenrcode,true);
        $paymentmode = Lookupfixed::where('keyname','paymentmode')->pluck('keyvalue','lookupfixid');
        return view('admin.purchase_bills.form',compact('billcode', 'paymentmode'));
        //return view('admin.inventories.purchase_bills.form',compact('billcode','department'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $insert_data = $request->all();
        $insert_data['billdatetime'] = Carbon::parse($request->input('invoicedatetime'))->format('Y-m-d H:i:s');
        $ind_data = Bill::create($insert_data);
        if($ind_data){
            $keys = array_keys($insert_data);
            $pattern='/itemid-/';
            $rows = preg_grep($pattern, $keys);

            foreach($rows as $key => $val){
                $row_id=explode('-', $val)[1];
                $insertArr['qty']=$insert_data['qty-'.$row_id];
                $insertArr['billid']=$ind_data->id;
                $insertArr['itemid']=$insert_data['itemid-'.$row_id];
                $insertArr['days']=$insert_data['days-'.$row_id];
                $insertArr['rate']=$insert_data['rate-'.$row_id];
                $insertArr['netamount']=$insert_data['totalamount-'.$row_id];
                BillDetail::create($insertArr);
            }
        }
        // Generate Payment Entry
        if(isset($request->paymentmode)) {

            $receiptcode = $this->receiptCode();

            $rec_data['paymentcode'] = $receiptcode['generated_code'];
            $rec_data['paymentcodeid'] = $receiptcode['sr_no'];
            $rec_data['partyid'] = $request->customerid;
            if($request->input('billdatetime')){
                $rec_data['paymentdatetime'] =Carbon::parse($request->input('billdatetime'))->format('Y-m-d H:i:s');
            }
            /*$rec_data['payingamount'] = $request->payingamount;*/
            $rec_data['paidamount'] = $request->paidamount;
            $rec_data['paymentmode'] = $request->paymentmode;
            if($request->input('transactiondate')){
               $rec_data['transactiondate'] = Carbon::parse($request->input('transactiondate'))->format('Y-m-d');
            }
            $rec_data['transactionno'] = $request->transactionno;
            $rec_data['bankname'] = $request->bankname;
            $rc_data = PaymentEntry::create($rec_data);

            $rec_detail['invpaymententryid'] = $rc_data->invpaymententryid;
            $rec_detail['billid'] = $ind_data->id;
            $rec_detail['invoiceamount'] = $ind_data->netamount;
            $rec_detail['payingamount'] = $rc_data->paidamount;
            if ($rec_detail['payingamount'] == $request->netamount) {
                      Bill::where('id',$rec_detail['billid'])->update(['billpay'=>1]);
            }
            $rd_data = PaymentEntryDetail::create($rec_detail);
        }
        // End Generate Payment Entry
        return response()->json(['success'=>true,'message'=>'Purchase Bill added successfully.','Billid'=>$ind_data->id]);
    }
    public function receiptCode()
    {
        $get_last_inserted_uhid = PaymentEntry::select('*')->withTrashed()->latest()->first();
        $incremented_patcode = 0;
        if ($get_last_inserted_uhid) {
            $incremented_patcode = $get_last_inserted_uhid->paymentcodeid + 1;
        }
        $receiptcode = app('App\Http\Controllers\Admin\CommonController')->CodeGenerationPattern(config('config.documenttypes.payment_entry'),$incremented_patcode);
        return $receiptcode;
    }
    public function getItemStock($itemid)
    {
        $item = DB::table('m_invitem')->where('itemid',$itemid)->whereNull('deleted_at')->first()->current_stock;
        return $item;
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Inventory\Bill  $Bill
     * @return \Illuminate\Http\Response
     */
    public function show(Bill $Bill)
    {
        /*abort_if(Gate::denies('inv_purchase_bill_view'), Response::HTTP_FORBIDDEN, '403 Forbidden');*/
        $purchase_order = BillDetail::where('billid',$Bill->id)->get();
        return view('admin.purchase_bills.view', compact('Bill','purchase_order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Inventory\Bill  $Bill
     * @return \Illuminate\Http\Response
     */
    public function edit(Bill $Bill)
    {
        abort_if(Gate::denies('inv_purchase_bill_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $purchase_order = PurchaseOrderDetail::where('orderitemstatus','1')
                    ->where('orderid',$Bill->purchaseorderid)
                    ->whereNull('deleted_at')->get();

        return view('admin.inventories.purchase_bills.form', compact('Bill','purchase_order'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Inventory\Bill  $Bill
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBillRequest $request, Bill $Bill)
    {
        $update_data = $request->all();
        $update_data['hospid'] = session('login_data.hospital.id');
        $update_data['invoicedatetime'] = store_utc_datetime(['datetime' => $request->input('invoicedatetime'),'select_datepattern' => TRUE]);
        $update_data['billdate'] = store_utc_datetime(['datetime' => $request->input('billdate'),'onlydate' => TRUE,'select_datepattern' => TRUE]);

        $Bill->update($update_data);

        $department=Department::where('iswarehoue',1)->where('status',1)->where('hospid',session('login_data.hospital.id'))->first();
        $BilldIds=[];
        $keys = array_keys($update_data);
        $pattern='/batchno-/';
        $rows = preg_grep($pattern, $keys);

        foreach($rows as $key => $val){
            $row_id=explode('-', $val)[1];

            $updatearr['itemid']=$update_data['itemid-'.$row_id];
            if (isset($update_data['goodsreceivednoteitemid-'.$row_id])) {
                $updatearr['goodsreceivednoteitemid']=$update_data['goodsreceivednoteitemid-'.$row_id];
            }
            if (isset($update_data['purchaseorderdetailid-'.$row_id])) {
               $updatearr['purchaseorderdetailid']=$update_data['purchaseorderdetailid-'.$row_id];
            }
            if($update_data['batchno-'.$row_id] != ''){
                $updatearr['batchno']=$update_data['batchno-'.$row_id];
                $updatearr['expirydate']=store_utc_datetime(['datetime' => $update_data['expirydate-'.$row_id],'onlydate'=>TRUE,'select_datepattern' => TRUE]);
            }else{
                $updatearr['batchno']= NULL;
                $updatearr['expirydate']=NULL;
            }
            $updatearr['qty']=$update_data['qty-'.$row_id];
            $updatearr['freeqty']=$update_data['freeqty-'.$row_id];
            $updatearr['rate']=$update_data['rate-'.$row_id];
            $updatearr['basicamount']=$update_data['basicamount-'.$row_id];
            $updatearr['discper']=$update_data['discper-'.$row_id];
            $updatearr['discamt']=$update_data['discamt-'.$row_id];
            $updatearr['taxable']=0.00;
            $updatearr['netamount']=$update_data['totalamount-'.$row_id];
            $updatearr['hospid'] = session('login_data.hospital.id');

            if(isset($update_data['Billdetailid-'.$row_id])){
                //Update
                $Billdetailid=$update_data['Billdetailid-'.$row_id];
                $BilldIds[]=$Billdetailid;
                BillDetail::where('Billdetailid',$Billdetailid)->where('Billid',$Bill->Billid)->update($updatearr);

                // Update in current item stock
                $current_stock = $this->getItemStock($update_data['itemid-'.$row_id]);
                $updatedStock = $current_stock - $update_data['oldqty-'.$row_id] + $update_data['qty-'.$row_id];

                // Update item entry in ItemDetail table
                $itmDtArr['itemid']=$update_data['itemid-'.$row_id];
                $itmDtArr['Billid']=$Bill->Billid;
                $itmDtArr['deptid'] = $department?$department->deptid:NULL;
                if($update_data['batchno-'.$row_id] != ''){
                    $itmDtArr['batchno']=$update_data['batchno-'.$row_id];
                    $itmDtArr['expiry_date']=store_utc_datetime(['datetime' => $update_data['expirydate-'.$row_id],'onlydate'=>TRUE,'select_datepattern' => TRUE]);
                }else{
                    $itmDtArr['batchno']= NULL;
                    $itmDtArr['expiry_date']=NULL;
                }
                /*if($update_data['expirydate-'.$row_id]!=''){
                    $itmDtArr['expiry_date']=store_utc_datetime(['datetime' => $update_data['expirydate-'.$row_id],'onlydate'=>TRUE,'select_datepattern' => TRUE]);
                }
                $itmDtArr['batchno']=$update_data['batchno-'.$row_id];*/
                $itmDtArr['qty']=$update_data['qty-'.$row_id];
                $itmDtArr['hospid'] = session('login_data.hospital.id');
                if ($Bill->documenttype!="GRN") {

                   TransactionHistoryOne::where('itemid',$update_data['itemid-'.$row_id])->where('batchno',$update_data['batchno-'.$row_id])->where('Billid',$Bill->Billid)->update($itmDtArr);
                }
            }else{
                //Add
                $updatearr['Billid']=$Bill->Billid;
                $cpd=BillDetail::create($updatearr);
                $BilldIds[]=$cpd->Billdetailid;

                // Add item entry in ItemDetail table
                $itmDtArr['itemid']=$update_data['itemid-'.$row_id];
                $itmDtArr['Billid']=$Bill->Billid;
                $itmDtArr['deptid'] = $department?$department->deptid:NULL;
                if($update_data['batchno-'.$row_id] != ''){
                    $itmDtArr['batchno']=$update_data['batchno-'.$row_id];
                    $itmDtArr['expiry_date']=store_utc_datetime(['datetime' => $update_data['expirydate-'.$row_id],'onlydate'=>TRUE,'select_datepattern' => TRUE]);
                }else{
                    $itmDtArr['batchno']= NULL;
                    $itmDtArr['expiry_date']=NULL;
                }
                /*if($update_data['expirydate-'.$row_id]!=''){
                    $itmDtArr['expiry_date']=store_utc_datetime(['datetime' => $update_data['expirydate-'.$row_id],'onlydate'=>TRUE,'select_datepattern' => TRUE]);
                }
                $itmDtArr['batchno']=$update_data['batchno-'.$row_id];*/
                $itmDtArr['qty']=$update_data['qty-'.$row_id];
                $itmDtArr['hospid'] = session('login_data.hospital.id');
                TransactionHistoryOne::create($itmDtArr);
                // Add in current item stock
                $current_stock = $this->getItemStock($update_data['itemid-'.$row_id]);
                $updatedStock = $current_stock + $update_data['qty-'.$row_id];
            }
            if ($Bill->documenttype!="GRN") {

                if($updatedStock){
                    \DB::commit();
                    DB:: table('m_invitem')->where('itemid', $update_data['itemid-'.$row_id])->update(array('current_stock' => $updatedStock));
                }
           }
        }
       if ($Bill->documenttype!="GRN") {
            // If delete item, stock deduct from the item master
            $deletBillItem = BillDetail::whereNotIn('Billdetailid',$BilldIds)->where('Billid',$Bill->Billid)->get();
            if($deletBillItem){
                foreach ($deletBillItem as $bill) {
                    $current_stock = $this->getItemStock($bill->itemid);
                    $updatedStock = $current_stock - $bill->qty;
                    DB:: table('m_invitem')->where('itemid', $bill->itemid)->update(array('current_stock' => $updatedStock));
                    TransactionHistoryOne::where('itemid', $bill->itemid)->where('batchno', $bill->batchno)->where('Billid', $Bill->Billid)->delete();
                }
            }
            BillDetail::whereNotIn('Billdetailid',$BilldIds)->where('Billid',$Bill->Billid)->delete();

       }
       return response()->json(['success'=>true,'message'=>'Purchase Bill updated successfully.']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Inventory\Bill  $Bill
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bill $Bill)
    {
        abort_if(Gate::denies('inv_purchase_bill_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        // If delete item, stock deduct from the item master
        $deletbillItem = BillDetail::where('Billid',$Bill->Billid)->get();

        if($deletbillItem && $Bill->documenttype!="GRN"){
            foreach ($deletbillItem as $bill) {
                $current_stock = $this->getItemStock($bill->itemid);
                $updatedStock = $current_stock - $bill->qty;
                DB:: table('m_invitem')->where('itemid', $bill->itemid)->update(array('current_stock' => $updatedStock));
            }
        }

        BillDetail::where('Billid', $Bill->Billid)->delete();

        if ($Bill->documenttype!="GRN") {

            TransactionHistoryOne::where('Billid', $Bill->Billid)->delete();
        }
        if($Bill->delete()){
            return response()->json([
                'status' => true,
                'message' => 'Purchase Bill deleted successfully!',
            ]);
        }
        response()->json([
            'status' => false,
            'message' => 'Purchase Bill not deleted!',
        ]);
    }

    public function massDestroy(MassDestroyBillRequest $request)
    {
        // If mass delete, stock deduct from the item master
        $deletbillItem = BillDetail::where('Billid',request('Billids'))->get();
        if($deletbillItem){
            foreach ($deletbillItem as $bill) {
                if (empty($bill->goodsreceivednoteitemid) || $bill->goodsreceivednoteitemid ==NULL) {
                    $current_stock = $this->getItemStock($bill->itemid);
                    $updatedStock = $current_stock - $bill->qty;
                    DB:: table('m_invitem')->where('itemid', $bill->itemid)->update(array('current_stock' => $updatedStock));
                }
            }
        }

        BillDetail::whereIn('Billid', request('Billids'))->delete();
        TransactionHistoryOne::whereIn('Billid', request('Billids'))->delete();
        if(Bill::destroy(request('Billids'))){
            return response()->json([
                'status' => true,
                'message' => 'Records deleted successfully!',
            ]);
        }
        return response()->json([
            'status' => false,
            'message' => 'Records not deleted successfully!',
        ]);
    }

    public function getBillNo(Request $request){
        if(isset($request->billid) && $request->billid != ''){
            $billno = Bill::where('hospid',session('login_data.hospital.id'))
                ->where('billno',$request->billno)
                ->where('partyid',$request->partyid)
                ->where('Billid','!=',$request->billid)
                ->get();
        }else{
            $billno = Bill::where('hospid',session('login_data.hospital.id'))
                ->where('billno',$request->billno)
                ->where('partyid',$request->partyid)
                ->get();
        }
        $cntflg = 0;
        if(isset($billno) && $billno->count() > 0){
            $cntflg = 1;
        }
        return response()->json(['success'=>true,'cntFlg'=>$cntflg]);
    }

    public function getPOItemsData(Request $request)
    {
        $html = '';
        if($request->orderid){
            $purchaseorder = PurchaseOrderDetail::where('orderid',$request->orderid)
                ->where('orderitemstatus','1')
                ->whereNull('deleted_at')->get();

            $p_order = PurchaseOrder::where('purchaseorderid',$request->orderid)
                        ->whereIn('orderstatus',['1','3'])->whereNull('deleted_at')->first();

            $html = view("admin.inventories.purchase_bills.po_items_detail")->with(["purchaseorder" => $purchaseorder])->render();
        }
        return response()->json(['html' => $html, 'partyid' => $p_order->partyid, 'customer' => $p_order->partyVendor->customer,'grandtotal'=>$p_order->grandtotal,'disc_per'=>$p_order->discper,'disc_amt'=>$p_order->discamt,'othercharges'=>$p_order->othercharges,'round_off'=>$p_order->roundoff,'netamount'=>$p_order->netamount]);
    }

    public function getGRNItemsData(Request $request)
    {
        $html = '';
        if($request->grnid){
            $GRNDetail = GRNDetail::where('grnid',$request->grnid)
                ->whereNull('deleted_at')->get();

            $p_order = GRN::where('grnid',$request->grnid)->whereNull('deleted_at')->first();

            $html = view("admin.inventories.purchase_bills.grn_items_detail")->with(["GRNDetail" => $GRNDetail])->render();
        }
        return response()->json(['html' => $html, 'partyid' => $p_order->partyid, 'customer' => $p_order->partyVendor->customer, 'grandtotal'=>$p_order->grandtotal,'disc_per'=>$p_order->discper,'disc_amt'=>$p_order->discamt,'othercharges'=>$p_order->othercharges,'TCS_amt'=>$p_order->tcsamount,'TCS_per'=>$p_order->tcsper,'round_off'=>$p_order->roundoff,'netamount'=>$p_order->netamount]);
    }
}
