<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Gate;
use DB;
use Illuminate\Support\Facades\Schema;
use App\Models\DocumentType;
use App\Models\CodeGeneration;
use Illuminate\Support\Str;
class CommonController extends Controller
{
    public function select2Find(Request $request)
    {
        $page = $request->page;

        $resultCount = 15;

        $offset = ($page - 1) * $resultCount;

        $whereArr=[];
        if($request->status){
            $whereArr['status']=$request->status;
        }

        if($request->keyname){
            $whereArr['keyname']=$request->keyname;
        }
        
        if ($request->country_field_name) {
            $whereArr[$request->country_field_name] = $request->country;
        }
        if (Schema::hasColumn($request->model, 'deleted_at')){
            $whereArr['deleted_at']=NULL;
        }

        $q = DB::table($request->model);

        if($request->multicolumns){
            $select_colums=$request->multicolumns;
        }else{
            $select_colums[0]=$request->field_id_name.' as id';
            $select_colums[1]=$request->field_name.' as text';
        }

        foreach($select_colums as $col){
           $q->selectRaw($col);
        }
        
        $q->where($whereArr)->where($request->field_name,'LIKE','%'.$request->term.'%');

        if($request->isvaccine) {
            $q->where($request->field_id_name,'!=',$request->isvaccine);
        }
        $data = $q->skip($offset)->take($resultCount)->get();

        $q1 = DB::table($request->model)->select($request->field_id_name.' as id',$request->field_name.' as text')->where($whereArr)->where($request->field_name,'LIKE','%'.$request->term.'%');
        if($request->isvaccine) {
            $q1->where($request->field_id_name,'!=',$request->isvaccine);
        }
        $count = $q1->count();

        $endCount = $offset + $resultCount;

        $morePages = $count > $endCount;

        $results = array(
          "results" => $data,
          "pagination" => array(
            "more" => $morePages
          )
        );
        return response()->json($results);
    }

    public function updatedCodeGenPattern($doc_type,$model,$column,$codeid,$whereArr=[])
    {
        $new_sr_no=0;
        $doctype = \App\Models\DocumentType::select('typeid')->where('typeid','1')->first();
        if($doctype){
            $codegeneration = $doctype->codegenerations->first();
        }
        if ($codegeneration) {
            $new_sr_no=$codegeneration->startwith;
        }
        $value = $this->CodeGenerationPattern($doc_type,$new_sr_no);
        $foundRecord = $model::where($column,$value['generated_code'])->withTrashed()->first();
        $inc_code = 0;
        if ($foundRecord) {
                $q = $model::where($column,'!=','0')->withTrashed()->latest();
                if($whereArr!=''){
                    $q->where($whereArr);
                }
                $lastRecord=$q->first();
                if ($lastRecord) {
                    // $inc_code = $lastRecord->$codeid + 1;
                    $len=strlen($lastRecord->$codeid);
                    $inc_code=str_pad($lastRecord->$codeid + 1, $len, '0', STR_PAD_LEFT);
                }
        }else{
            if($codegeneration){
                $inc_code = $value['sr_no'];
            }else{
                $inc_code = '000001';
            }
        }
        return $inc_code;
    }

    // Code for Code generation pattern by Document Type
    public function CodeGenerationPattern($document_type,$new_sr_no,$flag=false,$pattern = null)
    {
        $doctype = DocumentType::select('typeid','typecode')->where('typename',$document_type)->first();

        if ($doctype) {
            $codegeneration = CodeGeneration::where('typeid',$doctype->typeid)->latest()->first();
            $generated_code = $sr_pattern = '';

            if ($codegeneration || $pattern) {
                if($pattern!=null){
                    $generated_code = $pattern['pattern'];
                }else{
                    $generated_code = $codegeneration->pattern;
                }
                $sr_pattern = $new_sr_no;

                if (strpos($generated_code, config('config.codegeneration_pattern.doctypecode')) !== false){
                    $generated_code = str_replace(config('config.codegeneration_pattern.doctypecode'), $doctype->typecode, $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.year')) !== false){
                    $generated_code = str_replace(config('config.codegeneration_pattern.year'), date('Y'), $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.year_month')) !== false){
                    $generated_code = str_replace(config('config.codegeneration_pattern.year_month'), date('ym'), $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.month_year')) !== false){
                    $generated_code = str_replace(config('config.codegeneration_pattern.month_year'), date('my'), $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.year_year')) !== false){
                    $year_year_pattern = date('y', strtotime("-1 years")).'-'.date('y');
                    $generated_code = str_replace(config('config.codegeneration_pattern.year_year'), $year_year_pattern, $generated_code);
                }
                
                if (strpos($generated_code, config('config.codegeneration_pattern.year_sr')) !== false){
                    if ($new_sr_no == 0) {
                        if($pattern!=null){
                            $sr_pattern = $pattern['startmonth'].date('y').str_repeat(0, $pattern['leadingzero']).$pattern['startwith'];
                        }else{
                            if($flag==true){
                                $sr_pattern = $new_sr_no;
                            }else{
                                $sr_pattern = $codegeneration->startmonth.date('y').str_repeat(0, $codegeneration->leadingzero).$codegeneration->startwith;
                            }
                        }
                    }else {
                        if($pattern!=null){
                             $sr_pattern = $pattern['startmonth'].date('y').str_repeat(0,$pattern['leadingzero']).$new_sr_no;
                        }else{
                            if($flag==true){
                                $sr_pattern = $new_sr_no;
                            }else{
                                $sr_pattern = $codegeneration->startmonth.date('y').str_repeat(0,$codegeneration->leadingzero).$new_sr_no;
                            }
                        }
                    }
                    $generated_code = str_replace(config('config.codegeneration_pattern.year_sr'), $sr_pattern, $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.month_sr')) !== false){
                    if ($new_sr_no == 0) {
                        if($pattern!=null){
                             $sr_pattern = date('m').str_repeat(0, $pattern['leadingzero']).$pattern['startwith'];
                        }else{
                            $sr_pattern = date('m').str_repeat(0, $codegeneration->leadingzero).$codegeneration->startwith;
                        }
                    }else {
                        if($pattern!=null){
                            $sr_pattern = date('m').str_repeat(0,$pattern['leadingzero']).$new_sr_no;
                        }else{
                            if($flag==true){
                                $sr_pattern = $new_sr_no;
                            }else{
                                $sr_pattern = date('m').str_repeat(0,$codegeneration->leadingzero).$new_sr_no;
                            }
                        }
                    }
                    $generated_code = str_replace(config('config.codegeneration_pattern.month_sr'), $sr_pattern, $generated_code);
                }

                if (strpos($generated_code, config('config.codegeneration_pattern.sr')) !== false){
                    if ($new_sr_no == 0) {
                        if($pattern!=null){
                            $sr_pattern = str_repeat(0, $pattern['leadingzero']).$pattern['startwith'];
                        }else{
                            if($flag==false){
                                $sr_pattern = str_repeat(0, $codegeneration->leadingzero).$codegeneration->startwith;
                            }
                        }
                    } else {
                        if($pattern!=null){
                            $sr_pattern  =str_repeat(0,$pattern['leadingzero']).$new_sr_no;
                        }else{
                            if($flag==false){
                                $sr_pattern  =str_repeat(0,$codegeneration->leadingzero).$new_sr_no;
                            }
                        }
                    }
                    $generated_code = str_replace(config('config.codegeneration_pattern.sr'), $sr_pattern, $generated_code);
                }
               
                if (strpos($generated_code, '~') != false) {
                    $generated_code = str_replace('~', '', $generated_code);
                }
            } else {
                if ($new_sr_no == 0) {
                    $new_sr_no = 1;
                }
                if($flag==true){
                    $generated_code = '/'.$doctype->typecode.'/'.date('Y').'/'.$new_sr_no;
                    $sr_pattern = $new_sr_no;
                }else{
                    $generated_code = '/'.$doctype->typecode.'/'.date('Y').'/'.'00000'.$new_sr_no;
                    $sr_pattern = '00000'.$new_sr_no;
                }
            }

        } else {
            $generated_code = Str::random(8);
            $sr_pattern = $new_sr_no;
        }
        // print_r($generated_code);echo "<br>";exit();
        return array('generated_code' => $generated_code, 'sr_no' => $sr_pattern);
    }

}
