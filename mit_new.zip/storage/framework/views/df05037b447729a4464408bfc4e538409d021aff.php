<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/flatpickr/flatpickr.min.css')); ?>">
    <style type="text/css">
        .modal-open .select2-container {
            z-index: 0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <?php if(isset($bill)): ?>
            <h1 class="page-title">Edit Bill</h1>
            <?php echo e(Breadcrumbs::render('admin.bills.edit',$bill,$bill->billcode)); ?>

        <?php else: ?>
            <h1 class="page-title">Create Bill</h1>
            <?php echo e(Breadcrumbs::render('admin.bills.create')); ?>

        <?php endif; ?>
    </div>
    <div class="page-content">
        <?php if(isset($bill)): ?>
            <form method="POST" action='<?php echo e(route("admin.bills.update", [$bill->purchasebillid])); ?>' id="hms_form" autocomplete="off">
                <?php echo method_field('PUT'); ?>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route("admin.bills.store")); ?>" id="hms_form" autocomplete="off">
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="panel">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('billcode') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="billcode">Bill Code<span class="required">*</span></label>
                                            <?php if(isset($bill)): ?>
                                                <input class="form-control" type="text" name="billcode" id="billcode" value="<?php echo e(old('billcode', @$bill->billcode)); ?>" maxlength="100" readonly>
                                            <?php else: ?>
                                                <input class="form-control" type="text" name="billcode" id="billcode" value="<?php echo e(old('billcode', $billcode['generated_code'])); ?>" maxlength="100" readonly>
                                                <input type="hidden" name="billcodeid" id="billcodeid" value="<?php echo e($billcode['sr_no']); ?>">
                                            <?php endif; ?>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('billcode')): ?>
                                                    <?php echo e($errors->first('billcode')); ?>

                                                <?php endif; ?>
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('billdatetime') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="billdatetime"><b>Bill Date & Time</b><span class="required">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="icon md-calendar" aria-hidden="true"></i>
                                                </span>
                                                <?php if(isset($bill->billdatetime)): ?>
                                                    <input class="form-control" type="text" name="billdatetime" id="billdatetime" value="<?php echo e(old('billdatetime', display_datetime(['datetime' => $bill->billdatetime,'select_datepattern' => TRUE]))); ?>">
                                                <?php else: ?>
                                                    <input class="form-control" type="text" name="billdatetime" id="billdatetime" value="<?php echo e(old('billdatetime','')); ?>">
                                                <?php endif; ?>
                                            </div>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('billdatetime')): ?>
                                                    <?php echo e($errors->first('billdatetime')); ?>

                                                <?php endif; ?>
                                            </div>
                                            <span class="help-block"></span>
                                        </div>
                                    </div>
                
                                    <!-- for PO -->

                                    <!-- End for PO -->
                                    <div class="col-md-4">
                                        <div class="form-group form-material <?php echo e($errors->has('customerid') ? 'has-danger' : ''); ?>">
                                            <label class="form-control-label" for="customerid">Customer Name<span class="required">*</span></label>
                                            <select class="form-control select2" name="customerid" id="customerid">
                                                <?php if(isset($bill)): ?>
                                                    <option value="<?php echo e(@$bill->customerid); ?>" selected=""><?php echo e(@$bill->customer->name); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <div class="invalid-feedback">
                                                <?php if($errors->has('customerid')): ?>
                                                    <?php echo e($errors->first('customerid')); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                    <div class="col-md-12">
                                        <div class="card border border-info hms_card_primary">
                                            <div class="card-header card-header-transparent card-header-bordered bg-info pt-5 pb-5">
                                                <div class="row">
                                                    <div class="col-md-6 line_height_30">
                                                        Items
                                                    </div>
                                                    <div class="col-md-6 text-right">
                                                            <button class="btn btn-success btn-sm" type="button" id="addToTable">
                                                                <i class="icon md-plus" aria-hidden="true"></i> Add Item
                                                            </button>
                                                            <button class="btn btn-danger btn-sm gridChkDelete" type="button" data-tableid="tbl_hms_body">Delete
                                                            </button>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-block">
                                                <div class="table-responsive" id="poItemsTbl"></div>
                                                <div class="table-responsive" id="grnItemsTbl"></div>
                                                <div class="table-responsive" id="directItemsTbl">
                                                    <table class="table table-bordered" id="tbl_hms" style="width: 100%">
                                                        <thead>
                                                        <tr>
                                                            
                                                            <th style="width: 5%;">
                                                                <div class="checkbox-custom checkbox-primary">
                                                                    <input type="checkbox" class="gridSelectall" data-tableid="tbl_hms_body">
                                                                    <label for="gridSelectall"></label>
                                                                </div>
                                                            </th>
                                                         
                                                            <th style="width: 20%;">Item Name<span class="required">*</span></th>
                                                            <th style="width: 5%;">Days<span class="required">*</span></th>
                                                            <th style="width: 5%;">Qty<span class="required">*</span></th>
                                                            
                                                            <th style="width: 5%;">Rate<span class="required">*</span></th>
                                                            <th style="width: 10%;">Total<span class="required">*</span></th>
                                                            <th>Action</th>
                                                        </tr>
                                                        </thead>
                                                        <tbody id="tbl_hms_body" data-module="purchase_bill">
                                                        <?php if(isset($bill)): ?>
                                                              <?php $__currentLoopData = $bill->billdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="item_grid" id="row-<?php echo e($key); ?>">
                                                                        <td>
                                                                            <div class="checkbox-custom checkbox-primary">
                                                                                <input type="checkbox" class="gridChkRow">
                                                                                <label for="gridChkRow"></label>
                                                                            </div>
                                                                        </td>
                                                                        <td>
                                                                            <select class="form-control itemid" name="itemid-<?php echo e($key); ?>" id="itemid-<?php echo e($key); ?>" style="width: 250px;">
                                                                                <?php if($details->item): ?>
                                                                                    <option selected="" value="<?php echo e($details->itemid); ?>"><?php echo e($details->item->name); ?></option>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>

                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="days-<?php echo e($key); ?>" id="days-<?php echo e($key); ?>" class="form-control allow_number" maxlength="3" value="<?php echo e($details->days); ?>" style="width: 200px;">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="hidden" name="oldqty-<?php echo e($key); ?>" id="oldqty-<?php echo e($key); ?>" class="form-control" value="<?php echo e($details->qty); ?>">
                                                                            <input type="text" name="qty-<?php echo e($key); ?>" class="form-control allow_number" maxlength="10" value="<?php echo e($details->qty); ?>" style="width: 100px;">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="rate-<?php echo e($key); ?>" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e($details->rate); ?>" style="width: 150px;">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td class="hms_td_row">
                                                                            <input type="text" name="totalamount-<?php echo e($key); ?>" class="form-control totalamount" readonly value="<?php echo e($details->netamount); ?>" style="width: 170px;">
                                                                            <div class="invalid-feedback"></div>
                                                                        </td>
                                                                        <td>
                                                                            <input type="hidden" name="id-<?php echo e($key); ?>" value="<?php echo e($details->id); ?>">
                                                                            <button class="btn btn-danger btn-xs delete-record">
                                                                                Delete
                                                                            </button>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="item_grid" id="row-0">
                                                                <td>
                                                                    <div class="checkbox-custom checkbox-primary">
                                                                        <input type="checkbox" class="gridChkRow">
                                                                        <label for="gridChkRow"></label>
                                                                    </div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <select class="form-control itemid" name="itemid-0" id="itemid-0" style="width: 250px;">
                                                                    </select>
                                                                    <div class="invalid-feedback"></div>
                                                                </td>  
                                                                <td class="hms_td_row">
                                                                   <input type="text" name="days-0" class="form-control allow_number" maxlength="3" value="" style="width: 200px;">
                                                                   <div class="invalid-feedback"></div>
                                                               </td>                        
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="qty-0" class="form-control allow_number" maxlength="10" style="width: 100px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row" style="width:350px;">
                                                                    <input type="text" name="rate-0" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                <td class="hms_td_row">
                                                                    <input type="text" name="totalamount-0" class="form-control totalamount" id="totalamount-0" readonly style="width: 150px;">
                                                                    <div class="invalid-feedback"></div>
                                                                </td>
                                                                
                                                                <td></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group form-material <?php echo e($errors->has('paymentmode') ? 'has-danger' : ''); ?>">
                                                            <label class="form-control-label" for="paymentmode">Payment Type</label>
                                                            <select class="form-control select2 paymentmode" name="paymentmode">
<!--                                                                <option value="">Select payment type...</option>-->
                                                                <?php $__currentLoopData = $paymentmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payid => $payname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                    <option value="<?php echo e($payname); ?>" <?php echo e(((old('paymentmode')==$payname))? 'selected' : ''); ?>><?php echo e($payname); ?></option>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <div class="invalid-feedback">
                                                                <?php if($errors->has('paymentmode')): ?>
                                                                    <?php echo e($errors->first('paymentmode')); ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <span class="help-block"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group form-material <?php echo e($errors->has('paidamount') ? 'has-danger' : ''); ?>">
                                                            <label class="form-control-label" for="paidamount">Paid Amount</label>
                                                            <input class="form-control allow_decimal" type="text" name="paidamount" id="paidamount" value="<?php echo e(old('paidamount','')); ?>" data-beforedecimal="10" data-afterdecimal="2">
                                                            <div class="invalid-feedback">
                                                                <?php if($errors->has('paidamount')): ?>
                                                                    <?php echo e($errors->first('paidamount')); ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <span class="help-block"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 payment-details" style="display: none;">
                                        <div class="panel">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group form-material <?php echo e($errors->has('transactionno') ? 'has-danger' : ''); ?>">
                                                            <label class="form-control-label numberlbl" for="transactionno"></label>
                                                            <input class="form-control transactionno" type="text" name="transactionno" id="transactionno" value="<?php echo e(old('transactionno', '')); ?>" maxlength="100">
                                                            <div class="invalid-feedback">
                                                                <?php if($errors->has('transactionno')): ?>
                                                                    <?php echo e($errors->first('transactionno')); ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <span class="help-block"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group form-material <?php echo e($errors->has('transactiondate') ? 'has-danger' : ''); ?>">
                                                            <label class="form-control-label datelbl" for="transactiondate"></label>
                                                            <div class="input-group">
                            <span class="input-group-addon">
                            <i class="icon md-calendar" aria-hidden="true"></i>
                            </span>
                                                                <input class="form-control transactiondate" type="text" name="transactiondate" id="transactiondate" value="<?php echo e(old('transactiondate', '')); ?>">
                                                            </div>
                                                            <div class="invalid-feedback">
                                                                <?php if($errors->has('transactiondate')): ?>
                                                                    <?php echo e($errors->first('transactiondate')); ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <span class="help-block"></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group form-material <?php echo e($errors->has('bankname') ? 'has-danger' : ''); ?>">
                                                            <label class="form-control-label" for="bankname">Bank Name<span class="required">*</span></label>
                                                            <input class="form-control bankname" type="text" name="bankname" id="bankname" value="<?php echo e(old('bankname', '')); ?>" maxlength="100">
                                                            <div class="invalid-feedback">
                                                                <?php if($errors->has('bankname')): ?>
                                                                    <?php echo e($errors->first('bankname')); ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <span class="help-block"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="panel">
                                    <div class="panel-body totalgrid">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="grandtotal" class="col-sm-4 form-control-label">Grand Total <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" name ="grandtotal" id="grandtotal" readonly>
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('grandtotal')): ?>
                                                                <?php echo e($errors->first('grandtotal')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="discount" class="col-sm-4 form-control-label">Discount : </label>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" name ="discper" id="discper" data-beforedecimal="5" data-afterdecimal="2" value="<?php echo e(old('discper', @$bill->discper)); ?>">
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <b class="float-right">%</b>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <input type="text" class="form-control allow_decimal" name ="discamt" id="discamt" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e(old('discamt', @$bill->discamt)); ?>" placeholder="Amt">
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="othercharges" class="col-sm-4 form-control-label">Other Charges : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control allow_decimal" name ="othercharges" id="othercharges" data-beforedecimal="10" data-afterdecimal="2" value="<?php echo e(old('othercharges', @$bill->othercharges)); ?>">
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('othercharges')): ?>
                                                                <?php echo e($errors->first('othercharges')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="roundoff" class="col-sm-4 form-control-label">Round Off : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" name ="roundoff" id="roundoff" value="<?php echo e(old('roundoff', @$bill->roundoff)); ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group form-material row">
                                                    <label for="netamount" class="col-sm-4 form-control-label">Net Amount <span class="required">*</span>: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" class="form-control" name ="netamount" id="netamount" readonly value="<?php echo e(old('netamount', @$bill->netamount)); ?>">
                                                        <div class="invalid-feedback">
                                                            <?php if($errors->has('netamount')): ?>
                                                                <?php echo e($errors->first('netamount')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="p-1">
                                        <button class="btn btn-primary waves-effect waves-classic" type="submit">Save</button>
                                    </div>
                                    <div class="p-1">
                                        <a href="<?php echo e(url('admin/inventory/purchase_bills')); ?>" class="btn btn-secondary waves-effect waves-classic">
                                            Cancel
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('global/vendor/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/flatpickr/flatpickr.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/jquery-validate/jquery.validate.min.js')); ?>"></script>
    <!-- Bootbox -->
    <script src="<?php echo e(asset('global/vendor/bootbox/bootbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/inventory.js')); ?>"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        jQuery.validator.addMethod('lessThanTotalAmt', function(value, element, param) {
            if (this.optional(element)) return true;
            var discamt = parseFloat(value);
            var totalamount = parseFloat($(param).val());
            return discamt <= totalamount;
        }, "Must be less than or equal to Total Amount.");

       

        jQuery.validator.addMethod('lessThanEqualNetAmt', function(value, element, param) {
            if (this.optional(element)) return true;
            var netamt = parseFloat(value);
            var payingamt = parseFloat($(param).val());
            return netamt <= payingamt;
        }, "Must be less than or equal to Net Amount.");

        $(document).ready(function(){
            <?php if(isset($bill)): ?>
            $( "#billdatetime" ).flatpickr({
                enableTime: true,
                time_24hr: true,
                dateFormat: 'd-m-Y H:i',
            });
            $('.transactiondate').flatpickr( {
                 dateFormat: 'd-m-Y',
              });
            $('.item_grid').each(function () {
                var row_num = $(this).attr('id').split('-');
                <?php if($bill->documenttype == 'Direct'): ?>
                var itemid = $('select[name="itemid-' + row_num[1] + '"]').val();
                <?php else: ?>
                var itemid = $('input[name="itemid-' + row_num[1] + '"]').val();
                <?php endif; ?>
                chkItemValidation(row_num, itemid);
            });
            <?php else: ?>
            $( "#billdatetime" ).flatpickr({
                enableTime: true,
                time_24hr: true,
                dateFormat: 'd-m-Y H:i',
                defaultDate: new Date()
            });
            $('.transactiondate').flatpickr( {
                 dateFormat: 'd-m-Y',
              });
            <?php endif; ?>
            
    
           $('.select2').select2();
            $("#hms_form").validate({
                rules: {
                    billcode:{
                        required: true,
                        maxlength:100
                    },
                    billdatetime:{
                        required: true
                    },
                    documenttype:{
                        required: true
                    },
                    customerid:{
                        required: true
                    },
                    grandtotal: {
                        required: true
                    },
                    discper: {
                        range: [0, 100]
                    },
                    netamount: {
                        required: true
                    },
                    "itemid-0":{
                        required: true,
                        // unique_item:true
                    },
                    "days-0":{
                        required: true,
                        maxlength:5,
                    },
                    "qty-0": {
                        maxlength: 10,
                        required: true
                    },
                    "rate-0": {
                        required: true,
                        maxlength:13
                    },
                    "totalamount-0": {
                        required: true
                    },
                    discamt: {
                        lessThanTotalAmt: "#grandtotal"
                    },
                    paymentmode: {
                        required: function(element){
                            return $("#paidamount").val()!="";
                        },
                    },
                    paidamount: {
                        required: function(element){
                            return ($(".paymentmode").val() != null && $(".paymentmode").val() != '');
                        },
                        lessThanEqualNetAmt: "#netamount"
                    },
                    transactionno: {
                        required: function(element){
                            return $(".paymentmode").val()!="Cash";
                        },
                        maxlength:100
                    },
                    transactiondate: {
                        required: function(element){
                            return $(".paymentmode").val()!="Cash";
                        }
                    },
                    bankname: {
                        required: function(element){
                            return $(".paymentmode").val()!="Cash";
                        },
                        maxlength:100
                    },
                },
                messages: {
                    'batchno-0': {
                        pattern: "Please enter alphanumeric batch no"
                    },
                },
                errorPlacement: function (error, element){
                    if(element.attr("name") == "billdate" || element.attr("name") == "billdatetime" || element.hasClass('expirydate') || element.attr("name") == "transactiondate") {
                        $placement=$(element).parent().parent().find('.invalid-feedback');
                    }else{
                        $placement=$(element).parent().find('.invalid-feedback');
                    }
                    error.appendTo($placement);
                    $placement.show();
                },
                onfocusout: function(element) {
                    valid_data(element);
                }
            });

            getSingleSelect2List({
                selector:document.getElementById('documenttype'),
                placeholder:'Select Document Type...',
                model:'m_lookupfixed',
                field_id_name:'keyvalue',
                field_name:'keyvalue',
                whereArr:[{'keyname':"invdocumenttypebill"}],
            });

            <?php if(old('documenttype')!=''): ?>
            getSingleSelect2List({
                selector:document.getElementById('documenttype'),
                placeholder:'Select Document Type...',
                model:'m_lookupfixed',
                field_id_name:'keyvalue',
                field_name:'keyvalue',
                whereArr: [{'keyvalue': "<?php echo e(old('documenttype')); ?>"},{'keyname':"invdocumenttypebill"}],
            });
            <?php endif; ?>
            // getSingleSelect2List({
            //     selector:document.getElementsByClassName('paymentmode'),
            //     placeholder:'Select payment type...',
            //     model:'m_lookupfixed',
            //     field_id_name:'keyvalue',
            //     field_name:'keyvalue',
            //     whereArr:[{'keyname':"paymentmode"}],
            //     nonehospid:true,
            // });


            getSingleSelect2List({
                selector:document.getElementById('customerid'),
                placeholder:'Select Customer Name...',
                model:'customers',
                field_id_name:'id',
                field_name:'name',
                status:1,
            });

            <?php if(old('customerid')!=''): ?>
            getSingleSelect2List({
                selector:document.getElementById('customerid'),
                placeholder:'Select Customer Name...',
                model:'customers',
                field_id_name:'id',
                field_name:'name',
                status:1,
                whereArr: [{'id': "<?php echo e(old('customerid')); ?>"}],
            });
            <?php endif; ?>

            function initItemSelect2(){
                getSingleSelect2List({
                    selector:document.getElementsByClassName('itemid'),
                    placeholder:'Select item name or item code...',
                    model:'items',
                    field_id_name:'id',
                    field_name:'name',
                    status:1,
                    multicolumns:['id as id',"name as text"],
                });
            }
            initItemSelect2();


            /* End If doctype="PO" */

            /******* Item Grid ************/
            $('#expirydate-0').flatpickr({
                dateFormat: 'd-m-Y',
                // defaultDate: new Date(),
                minDate: new Date(),
                /*allowInput:true*/
            });

            function billItemGrid(){
                var doctype = $('#documenttype').val();
                $('.item_grid').each(function(row_count){
                    var row_num = $(this).attr('id').split('-');

        
                   

                    /* Jquery validate rule */
                    $('select[name="itemid-'+row_num[1]+'"]').rules("add", {
                        required: true,
                    });
                    $('input[name="days-'+row_num[1]+'"]').rules("add", {
                        number: true,
                        required: true,
                        maxlength:5,
                    });

                    $('input[name="qty-'+row_num[1]+'"]').rules("add", {
                        number: true,
                        required: true,
                        maxlength:10,
                    });

                    $('input[name="rate-'+row_num[1]+'"]').rules("add", {
                        required: true,
                        maxlength:13,
                        messages: {
                            maxlength: 'Please enter no more than 10.',
                        }
                    });

                   
                    $('input[name="totalamount-'+row_num[1]+'"]').rules("add", {
                        required: true,
                    });
                    billItemGridCalculation(row_num[1]);
                });
                grandTotal();
                //$('input[name="discamt"]').trigger('keyup');
            }
            // On load call function
            billItemGrid();
            grandTotal();
            // Add Charge Grid
            <?php if(isset($bill)): ?>
            var cnt_old ='<?php echo e(count($bill->billdetails)); ?>';
            if(cnt_old>0){
                var cpRow= $('.item_grid').length;
            }else{
                var cpRow = 0;
            }
            
            <?php else: ?>
            var cpRow = 1;
            
            <?php endif; ?>

            var template = jQuery.validator.format($.trim($("#addChild").html()));
            $("#addToTable").click(function (e) {
                e.preventDefault();
                $(template(cpRow++)).appendTo("#tbl_hms_body");
                $('input[class="gridSelectall"]:checked').prop('checked',false);
                initItemSelect2();
                billItemGrid(cpRow);
            });
            jQuery(document).delegate('.delete-record', 'click', function(e) {
                e.preventDefault();
                var $self=$(this);
                bootbox.dialog({
                    message:"Are you sure you want to delete this record ?",
                    title: "Confirm delete",
                    buttons: {
                        danger: {
                            label: "Confirm",
                            className: "btn-danger",
                            callback: function callback() {
                                $self.closest('tr').remove();
                                grandTotal();
                                $('input[name="discper"]').trigger('keyup');
                                $('input[name="othercharges"]').trigger('keyup');
                                if($('#tbl_hms_body tr').length==0){
                                 $('input[class="gridSelectall"]:checked').prop('checked',false);
                                }
                            }
                        },
                        main: {
                            label: "Cancel",
                            className: "btn-primary"
                        }
                    }
                });
            });
            $("#hms_form").submit(function(e){
                e.preventDefault();

                setTimeout(function () {
                    $('button[type="submit"]').removeAttr('disabled', 'disabled');
                    if($('#hms_form').valid()){
                        if($('#tbl_hms_body tr').length==0){
                            toastrError('','Please add items.');
                            $('button[type="submit"]').removeAttr('disabled', 'disabled');
                        } else {
                             bootbox.dialog({
                               message: "Are you sure you want to print this Bill?",
                               title: "ARE YOU SURE?",
                               buttons: {
                               danger: {
                                  label: "Confirm",
                                  className: "btn-danger",
                                  callback: function callback() {
                                     callSaveButtonAjax(true);
                                  }
                               },
                               main: {
                                  label: "Cancel",
                                  className: "btn-primary",
                                  callback: function callback() {
                                     callSaveButtonAjax(false);
                                  }
                               },
                               },
                               onEscape: function () {
                                  $('button[type="submit"]').removeAttr('disabled', 'disabled');
                               }
                            }); 
                            // ****Please remove this code when print enable****
                            /*$('button[type="submit"]').removeAttr('disabled', 'disabled');
                            callSaveButtonAjax(false);*/
                            // ***end***
                        }
                    }
                }, 1500);
            });

            function callSaveButtonAjax(printresult) {
                <?php if(isset($bill)): ?>
                var url = '<?php echo e(route("admin.bills.update", $bill->id)); ?>'
                <?php else: ?>
                var url = "<?php echo e(route('admin.bills.store')); ?>";
                <?php endif; ?>
                $.ajax({
                    url:url,
                    type:'POST',
                    data:$("#hms_form").serialize(),
                    beforeSend: function () { $('#hms_loader').show(); },
                    success:function(data){
                        if(data.success==true){
                            if (printresult == true) {
                                var purchasebillid = data.Billid;
                                <?php if(isset($bill)): ?>
                                    purchasebillid = '<?php echo e($bill->id); ?>';
                                <?php endif; ?>
                                var popup = window.open(base_url+'/admin/print/bill?id='+purchasebillid,
                                    '_blank'
                                );
                                popupBlockerChecker.check(popup);
                                window.location.href="<?php echo e(route("admin.bills.index")); ?>";
                            } else {
                                window.location.href="<?php echo e(route("admin.bills.index")); ?>";
                            }
                        }else{
                            $('#hms_loader').hide();
                            toastrError('',data.message);
                        }
                    },
                    error: function(response) {
                        printErrorMsg(response.responseJSON.errors);
                        $('button[type="submit"]').removeAttr('disabled', 'disabled');
                        $('#hms_loader').hide();
                    }
                });
            }

            /*$(document).on("change","select",function() {
                $(this).valid();
            });*/
            $(document).on("select2:close","select",function() {
                $(this).valid();
            });
            function printErrorMsg(msg){
                var error_html='';
                $.each( msg, function( key1, value1 ) {
                    $.each( value1, function( key2, value2 ) {
                        $('#'+key1).parents('div[class^="form-group"]').addClass('has-danger');
                        $('#'+key1).parents('div[class^="form-group "]').find('.invalid-feedback').html(value2).show();
                        error_html+='<li>'+value2+'</li>';
                    });
                });
                toastrErrors(error_html,'The given data was invalid.');
            }
        });
        
    </script>
    
    
    <script type="text/html" id="addChild">
        <tr id="row-{0}" data-row="" class="item_grid">
            <td>
                <div class="checkbox-custom checkbox-primary">
                    <input type="checkbox" class="gridChkRow">
                    <label for="gridChkRow"></label>
                </div>
            </td>
            <td class="hms_td_row">
                <select class="form-control itemid" name="itemid-{0}" id="itemid-{0}" style="width: 250px;">
                </select>
                <div class="invalid-feedback"></div>
            </td>
           <td class="hms_td_row">
               <input type="text" name="days-{0}" class="form-control allow_number" maxlength="3" value="">
               <div class="invalid-feedback"></div>
           </td>
            <td class="hms_td_row">
                <input type="text" name="qty-{0}" class="form-control allow_number" maxlength="10" style="width: 100px;">
                <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
                <input type="text" name="rate-{0}" class="form-control allow_decimal" data-beforedecimal="10" data-afterdecimal="2" style="width: 150px;">
                <div class="invalid-feedback"></div>
            </td>
            <td class="hms_td_row">
                <input type="text" name="totalamount-{0}" class="form-control totalamount" id="totalamount-{0}" readonly style="width: 150px;">
                <div class="invalid-feedback"></div>
            </td>            
            <td>
                <button type="button" class="btn btn-danger btn-xs delete-record">Delete</button>
            </td>
        </tr>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/purchase_bills/form.blade.php ENDPATH**/ ?>