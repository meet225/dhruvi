<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="bootstrap material admin template">
    <meta name="author" content="">
    
    <title>ANTRIX SUPPLIRES</title>
    
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/apple-touch-icon.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('global/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/css/bootstrap-extend.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/site.min.css')); ?>">
    
    <!-- Plugins -->
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/animsition/animsition.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/asscrollable/asScrollable.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/switchery/switchery.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/waves/waves.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/vendor/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/login-v3.min.css')); ?>">
        
    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('global/fonts/material-design/material-design.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('global/fonts/brand-icons/brand-icons.min.css')); ?>">
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <style type="text/css">
        .hms_brand{
            font-size: 30px;
            font-weight: 600;
            letter-spacing: 4px;
            color: #28ace2;    
        }
        .hms_brand .brand-text{
            margin-top: 15px;
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
    
    <!-- Scripts -->
    <script src="<?php echo e(asset('global/vendor/breakpoints/breakpoints.js')); ?>"></script>
    <script>
      Breakpoints();
    </script>
  </head>
  <body class="animsition page-login-v3 layout-full">
    <!-- Page -->
    <div class="page vertical-align text-center" data-animsition-in="fade-in" data-animsition-out="fade-out">>
      <div class="page-content vertical-align-middle">
        <?php echo $__env->yieldContent("content"); ?>
        <footer class="page-copyright page-copyright-inverse">
          <p>WEBSITE BY Mit Infotech</p>
          <p>© <?php echo e(date('Y')); ?>. All RIGHT RESERVED.</p>
        </footer>
      </div>
    </div>
    <!-- End Page -->

    <!-- Core  -->
    <script src="<?php echo e(asset('global/vendor/babel-external-helpers/babel-external-helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/popper-js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/mousewheel/jquery.mousewheel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/asscrollbar/jquery-asScrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/asscrollable/jquery-asScrollable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/ashoverscroll/jquery-asHoverScroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/waves/waves.min.js')); ?>"></script>
    
    <!-- Plugins -->
    <script src="<?php echo e(asset('global/vendor/switchery/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/vendor/jquery-placeholder/jquery.placeholder.min.js')); ?>"></script>
    
    <!-- Scripts -->
    <script src="<?php echo e(asset('global/js/Component.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Base.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Config.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/Section/Menubar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Section/Sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Section/PageAside.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Plugin/menu.js')); ?>"></script>
    
    <!-- Config -->
    <script>Config.set('assets', '<?php echo e(asset("assets")); ?>');</script>
    
    <!-- Page -->
    <script src="<?php echo e(asset('assets/js/Site.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin/asscrollable.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin/switchery.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin/material.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script>
    $(function(){
      <?php if(session('message')): ?>
        toastrSuccess('','<?php echo e(session('message')); ?>');
      <?php endif; ?>
      <?php if($errors->count() > 0): ?>
        var toster_msgs_arr='';
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        toster_msgs_arr+='<li><?php echo e($error); ?></li>';
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        toastrErrors(toster_msgs_arr,'Some fields are incorrect.');
      <?php endif; ?>
    });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\bill\resources\views/layouts/auth.blade.php ENDPATH**/ ?>