<!DOCTYPE html>
<html style="background-color: #d7ca6acc;">
<head>
	<title>Bill</title>
	<style>

	    @page  { margin: <?php echo e($page_margin); ?>; }
	</style>
	<link rel="stylesheet" href="<?php echo e(public_path('assets/css/print.css')); ?>">
</head>
<body >
	<!-- Header -->
	<div id="header">
   		<?php echo $__env->make('billprint.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<!-- Footer -->
	<div id="footer">
	   <?php echo $__env->make('billprint.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<!-- Main Content -->
	<div id="content">
	    <table id="charge_detail" class="table" cellspacing="0" style="margin-bottom: 30%;margin-top: 3%;">
	    	<thead class="border-bottom">
	    		<tr>
	    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
	    			<th style="text-align: center;" class="pb-10">Items</th>
		    		<th style="text-align: center;" class="pb-10">Qty</th>
		    		<th style="text-align: center;" class="pb-10">Day</th>
		    		<th style="text-align: center;" class="pb-10">Rate</th>
		    		<th style="text-align: center;" class="pb-10">Total</th>
	    		</tr>
	    	</thead>
	    	<tbody>
	    		<?php if($Bill->billdetails): ?>
	    			<?php $sr=1 ?>
		    		<?php $__currentLoopData = $Bill->billdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpdetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    		<tr class="align-center">
			    		<td><?php echo e($sr); ?></td>
			    		<td><?php echo e($cpdetails->item->name); ?></td>
			    		<td><?php echo e($cpdetails->days); ?></td>
			    		<td><?php echo e($cpdetails->qty); ?></td>
			    		<td><?php echo e($cpdetails->rate); ?></td>
			    		<td><?php echo e($cpdetails->netamount); ?></td>
		    		</tr>
		    		<?php
		    		 $sr++ 
		    		?>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	<?php else: ?>
		    		<tr>No data found.</tr>
		    	<?php endif; ?>
	    	</tbody>
	    </table>
	    <table class="table" cellpadding="4" cellspacing="6">
			<tbody>
				<tr>
					<td class="align-right"><strong>Grand Total &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left"><?php echo e($Bill->grandtotal); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Discount &nbsp;&nbsp;&nbsp;</strong><span class="align-left"><?php echo e($Bill->discper); ?> % (<?php echo e($Bill->discamt); ?>)</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Other Charges  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="align-left"><?php echo e($Bill->othercharges??'N/A'); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
				<tr>
					<td class="align-right"><strong>Net Amount : &nbsp;&nbsp;&nbsp;&nbsp;</strong><span><?php echo e($Bill->netamount); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>

				<tr>
					<?php
						$f = new \NumberFormatter( locale_get_default(), \NumberFormatter::SPELLOUT );
						$word = $f->format($Bill->netamount);
					?>
					<td class="border-top border-bottom"><strong>Amount in Words : <?php echo e(ucwords($word)); ?></strong></td>
				</tr>

			</tbody>
		</table>
		<?php if(isset($payment)): ?>
			<div class="page-break"></div>

			<center><h4 style="padding-top: 5px;padding-bottom: 5px;background: #e6e4e4">Payment Against Bill</h4></center>
			<table class="table" cellspacing="0">
		    	<thead class="border-bottom">
		    		<tr>
		    			<th style="text-align: center;" class="pb-10">Sr. No.</th>
		    			<th style="text-align: center;" class="pb-10">Payment Code</th>
		    			<th style="text-align: center;" class="pb-10">Payment Date</th>
			    		<th style="text-align: center;" class="pb-10">Received Amount</th>
		    		</tr>
		    	</thead>
		    	<tbody>
	    			<?php $sr=1; $sumTotal = 0; ?>
		    		<?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		    		<?php
			        	$datetime = date('d-m-Y H:i', strtotime($payments->paymentdatetime));
			     	?>
		    		<tr class="align-center">
			    		<td class="border-bottom"><?php echo e($sr); ?></td>
			    		<td class="border-bottom"><?php echo e($payments->paymentcode); ?></td>
			    		<td class="border-bottom"><?php echo e($datetime); ?></td>
			    		<td class="border-bottom"><?php echo e($payments->payingamount); ?></td>
		    		</tr>
		    		<?php $sr++; $sumTotal = $sumTotal + $payments->payingamount; ?>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	</tbody>
		    </table>
		    <table class="table" cellspacing="0">
			<tbody>
				<tr>
					<td class="align-right"><strong>Total Received Amount : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span><?php echo e($sumTotal); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				</tr>
			</tbody>
		</table>
	    <?php endif; ?>
	</div>	
</body>
</html><?php /**PATH C:\xampp\htdocs\bill\resources\views/billprint/bill.blade.php ENDPATH**/ ?>