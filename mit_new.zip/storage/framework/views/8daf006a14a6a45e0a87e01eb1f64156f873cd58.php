<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('global/vendor/bootstrap-tokenfield/bootstrap-tokenfield.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Code Generation</h1>
    <?php echo e(Breadcrumbs::render('admin.code_generations')); ?>

</div>
<div class="page-content">
    <div class="panel">
        <div class="panel-body">
            <form method="POST" action="<?php echo e(route("admin.code_generations.store")); ?>" id="hms_form" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group form-material <?php echo e($errors->has('typeid') ? 'has-danger' : ''); ?>">
                            <label class="form-control-label" for="typeid">Document Type<span class="required">*</span></label>
                            <select class="form-control select2" name="typeid" id="typeid">
                            </select>
                            <div class="invalid-feedback">
                                <?php if($errors->has('typeid')): ?>
                                <?php echo e($errors->first('typeid')); ?>

                                <?php endif; ?>
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group form-material">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label" for="pattern"><b>Pattern</b></label>
                                    <div class="checkbox-custom checkbox-primary">
                                        <input type="checkbox" class="pattern" id="hos" value="[HOS]" checked>
                                        <label for="hos">Hospital Code e.g.[ABCD]</label>
                                    </div>
                                    <div class="checkbox-custom checkbox-primary">
                                        <input type="checkbox" class="pattern" id="doc" value="[DOC]" checked>
                                        <label for="doc">DocType e.g.[ADM]</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-control-label">Month-Year<span class="required">*</span></label>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" class="pattern" id="yyyy" value="[YYYY]"checked name="date_patt">
                                        <label for="yyyy">YYYY e.g.[<?php echo e(date('Y')); ?>]</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" class="pattern" id="yymm" value="[YYMM]" name="date_patt">
                                        <label for="yymm">YYMM e.g.[<?php echo e(date('ym')); ?>]</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" class="pattern" id="mmyy" value="[MMYY]" name="date_patt">
                                        <label for="mmyy">MMYY e.g.[<?php echo e(date('my')); ?>]</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" class="pattern" id="yy-yy" value="[YY-YY]" name="date_patt">
                                        <?php $per_year = date("y",strtotime("-1 year")); ?>
                                        <label for="yy-yy">YY-YY e.g.[<?php echo e($per_year); ?>-<?php echo e(date('y')); ?>]</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-control-label">SR Number<span class="required">*</span></label>
                                    <div class="form-group <?php echo e($errors->has('man_pan') ? 'has-danger' : ''); ?>">
                                        <div class="radio-custom radio-primary">
                                            <input type="radio" class="pattern" id="yysr" value="[YYSR]" name="man_pan">
                                            <label for="yysr">YYSR e.g.[01<?php echo e(date('y')); ?>1]</label>
                                        </div>
                                        <div class="radio-custom radio-primary">
                                            <input type="radio" class="pattern" id="mmsr" value="[MMSR]" name="man_pan">
                                            <label for="mmsr">MMSR e.g.[<?php echo e(date('m')); ?>1]</label>
                                        </div>
                                        <div class="radio-custom radio-primary">
                                            <input type="radio" class="pattern" id="sr" value="[SR]" name="man_pan" checked>
                                            <label for="sr">SR e.g.[1]</label>
                                        </div>
                                        <div class="invalid-feedback">
                                            <?php if($errors->has('man_pan')): ?>
                                            <?php echo e($errors->first('man_pan')); ?>

                                            <?php endif; ?>
                                        </div>
                                        <span class="help-block"></span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <!-- <label>Seperator</label> -->
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" name="spc_char" id="forward_slash" value="/" checked>
                                        <label for="forward_slash">Forward Slash('/')</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" name="spc_char" id="backward_slash" value="\">
                                        <label for="backward_slash">Backward Slash('\')</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" name="spc_char" id="dash" value="-">
                                        <label for="dash">Dash('-')</label>
                                    </div>
                                    <div class="radio-custom radio-primary">
                                        <input type="radio" name="spc_char" id="no_sap" value="">
                                        <label for="no_sap">No Separator</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group form-material <?php echo e($errors->has('pattern') ? 'has-danger' : ''); ?>">
                            <input type="text" class="form-control" id="pattern" value="[HOS],/,[DOC],/,[YYYY],/,[SR]" name="pattern" readonly />
                            <div class="invalid-feedback">
                                <?php if($errors->has('pattern')): ?>
                                <?php echo e($errors->first('pattern')); ?>

                                <?php endif; ?>
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group form-material">
                            <label class="form-control-label" for="example_pattern">Example of Generated Pattern</label>
                            <input type="text" class="form-control" id="example_pattern" value="ABCD/ADM/<?php echo e(date('Y')); ?>/000001" disabled>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material <?php echo e($errors->has('startmonth') ? 'has-danger' : ''); ?>">
                            <label class="form-control-label" for="startmonth">Start Month</label>
                            <select class="form-control select2" name="startmonth" id="startmonth" disabled onchange="generate_ex_pattern();">
                                <?php $__currentLoopData = config('config.months'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($month); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                <?php if($errors->has('startmonth')): ?>
                                <?php echo e($errors->first('startmonth')); ?>

                                <?php endif; ?>
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material <?php echo e($errors->has('startwith') ? 'has-danger' : ''); ?>">
                            <label class="form-control-label" for="startwith">Start Serial No. (SR) With<span class="required">*</span></label>
                            <input type="text" class="form-control allow_number" id="startwith" name="startwith" value="1" onchange="generate_ex_pattern();" maxlength="7">
                            <div class="invalid-feedback">
                                <?php if($errors->has('startwith')): ?>
                                <?php echo e($errors->first('startwith')); ?>

                                <?php endif; ?>
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group form-material <?php echo e($errors->has('leadingzero') ? 'has-danger' : ''); ?>">
                            <label class="form-control-label" for="leadingzero">Leading Zero<span class="required">*</span></label>
                            <input type="text" class="form-control allow_number" id="leadingzero" name="leadingzero" value="5" onchange="generate_ex_pattern();" maxlength="1">
                            <div class="invalid-feedback">
                                <?php if($errors->has('leadingzero')): ?>
                                <?php echo e($errors->first('leadingzero')); ?>

                                <?php endif; ?>
                            </div>
                            <span class="help-block"></span>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="p-1">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('code_generation_add')): ?>
                                <button class="btn btn-primary waves-effect waves-classic" type="submit">
                                    Save
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('global/vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('global/vendor/bootstrap-tokenfield/bootstrap-tokenfield.min.js')); ?>"></script>
<script type="text/javascript">
    $('.select2').select2();
    $('.select2').on('change', function() {
        $(this).valid();
    });

    $("#hms_form").validate({
        rules: {
            typeid: {
                required: true,
            },
            man_pan:{
                required: true,
            },
            startwith: {
                required: true,
            },
            leadingzero: {
                required: true,
            },
            pattern: {
                required: true,
            }
        },
        errorPlacement: function (error, element){
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            error.appendTo($placement);
            $placement.show();
        },
        highlight: function(element, errorClass, validClass) {
            $(element).parent().addClass('has-danger').removeClass('has-success');
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            $placement.show();
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).parent().removeClass('has-danger').addClass('has-success');
            $placement=$(element).parents('div[class^="form-group "]').find('.invalid-feedback');
            $(element).removeClass('error');
            $placement.hide();
        },
        onfocusout: function(element) {
            valid_data(element);
        }
    });

    getSingleSelect2List({
        selector:document.getElementById('typeid'),
        placeholder:'Select Document Type...',
        model:'m_documenttype',
        field_id_name:'typeid',
        field_name:'typename'
    });

    $('#pattern').tokenfield(); 

    $('.pattern').click(function () {
        PatternGenrate($(this));
    });

    $('#typeid').change(function() {
        var typeid = $(this).val();
        $.ajax({
            type:'GET',
            url:"<?php echo e(url('/admin/code_generations')); ?>/"+typeid,
            success:function(data){
                if (!$.isEmptyObject(data)) {
                    $('.pattern').prop('checked',false);
                    var spec_char = '/';
                    $('#forward_slash').prop('checked',true);
                    if (data.tags_separator == 'D') {
                        spec_char = '-';
                        $('#dash').prop('checked',true);
                    } else if(data.tags_separator == 'B') {
                        spec_char = '\\';
                        $('#backward_slash').prop('checked',true);
                    } else if(data.tags_separator == null) {
                        spec_char = '~';
                        $('#no_sap').prop('checked',true);
                    }
                    var split_pattern = data.pattern.split(']'+spec_char);
                    // Enable Start Month if "[YYSR] checked"
                    if(jQuery.inArray("[YYSR]", split_pattern) > -1) {
                        $('#startmonth').attr('disabled',false)
                        $("#startmonth option[value="+data.startmonth+"]").attr('selected', 'selected').trigger('change');
                    }else{
                        $('#startmonth').attr('disabled',true)
                    }
                    $('#pattern').tokenfield('destroy').val('');
                    $('#pattern').tokenfield();
                    var new_pattern_spec_charc = [];
                    $(split_pattern).each(function(i,value){
                        if (i !== (split_pattern.length - 1)) {
                            value+=']';
                        }
                        new_pattern_spec_charc.push(value);
                        if (value.length > 1) 
                        {
                            var id = value.toLowerCase().slice(1,-1);
                            $('#'+id).prop('checked',true);
                        }
                        
                        if (i !== (split_pattern.length - 1)) {
                            if (spec_char == '~') {
                                spec_char = '';
                            }
                            new_pattern_spec_charc.push(spec_char);
                        }
                    });
                    $('#pattern').tokenfield('setTokens',new_pattern_spec_charc);
                    
                    $('#startwith').val(data.startwith);
                    $('#leadingzero').val(data.leadingzero);
                    generate_ex_pattern();
              }else{
                $('#hms_form').trigger("reset");
              }
           }
        });
    });

    function generate_ex_pattern()
    {
        var pattern = $('#pattern').tokenfield('getTokens');
        var spc_char = $("input[name='spc_char']:checked").val();
        var ex_pattern = '';
        var current_year = new Date().getFullYear().toString().substr(-2);
        var current_fullyear = new Date().getFullYear();
        var current_month = ("0" + (new Date().getMonth() + 1)).slice(-2);
        $(pattern).each(function(index,data){
            if (data.value.length > 1) 
            {
                var id = data.value.toLowerCase().slice(1,-1);
                if($('#'+id).val() == '[HOS]') {
                    ex_pattern += 'ABCD' + spc_char;
                }
                if ($('#'+id).val() == '[DOC]') {
                    ex_pattern += 'ADM' + spc_char;
                }
                if ($('#'+id).val() == '[YYYY]') {
                    ex_pattern += current_fullyear + spc_char;
                }
                if ($('#'+id).val() == '[YYMM]') {
                    ex_pattern += current_year + current_month + spc_char;
                }
                if ($('#'+id).val() == '[MMYY]') {
                    ex_pattern += current_month + current_year + spc_char;
                }
                if ($('#'+id).val() == '[YY-YY]') {
                    ex_pattern += '20-21' + spc_char;
                }               
            }
        });
        var pattern_lead = pattern_stlead(current_year,current_month);
        if (typeof(pattern_lead) !== 'undefined') {
            ex_pattern += pattern_lead;
        }
        $('#example_pattern').val(ex_pattern);
    }

    function pattern_stlead(current_year,current_month)
    {
        if ($('#yysr').is(':checked')) {
            make_pattern = $('#startmonth').val() + current_year;
            make_pattern += remove_srno_pattern();
            return make_pattern;
        }
        if ($('#mmsr').is(':checked')) {
            make_pattern = current_month;
            make_pattern += remove_srno_pattern();
            return make_pattern;
        }
        if ($('#sr').is(':checked')) {
            make_pattern = remove_srno_pattern();
            return make_pattern;
        }
    }
    function remove_srno_pattern(){
        var make_pattern = '';
        var startwith = $('#startwith').val();
        var leadingzero = $('#leadingzero').val();
        for (var i = 0; i < leadingzero; i++) {
            make_pattern += 0;
        }
        make_pattern += startwith;
        return make_pattern;
    }

    $("input[name='spc_char']").change(function() {
        PatternGenrate($(this));
    });

    function PatternGenrate(val)
    {
        if (val.is(':checked')) 
        {
            if($("input[name=man_pan]:checked").val() == '[YYSR]')
            {
                $('#startmonth').attr('disabled',false);
            }else{
                $('#startmonth').attr('disabled',true);
            }
            $('#pattern').tokenfield('setTokens', []);
            $('.pattern:checkbox:checked').each(function(){
                var spec_character = $("input[name='spc_char']:checked").val();
                $('#pattern').tokenfield('createToken', $(this).val()); 
                $('#pattern').tokenfield('createToken', spec_character);
            });

            $('.pattern:radio:checked').each(function(){
                var spec_character = $("input[name='spc_char']:checked").val();
                $('#pattern').tokenfield('createToken', $(this).val()); 
                $('#pattern').tokenfield('createToken', spec_character);
            });
            
        }else{
            $('#pattern').tokenfield('setTokens', []);
            $('.pattern:checkbox:checked').each(function(){
                var spec_character = $("input[name='spc_char']:checked").val();
                $('#pattern').tokenfield('createToken', $(this).val()); 
                $('#pattern').tokenfield('createToken', spec_character);
            });

            $('.pattern:radio:checked').each(function(){
                var spec_character = $("input[name='spc_char']:checked").val();
                $('#pattern').tokenfield('createToken', $(this).val()); 
                $('#pattern').tokenfield('createToken', spec_character);
            });
        }
        generate_ex_pattern();
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/code_generations/create.blade.php ENDPATH**/ ?>