<div class="site-menubar">
  <div class="site-menubar-body">
    <div>
      <div>
        <ul class="site-menu" data-plugin="menu">
          <li class="site-menu-item">
            <a class="animsition-link" href="#">
                <i class="site-menu-icon md-view-dashboard" aria-hidden="true"></i>
                <span class="site-menu-title">Dashboard</span>
            </a>
          </li>
           
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
            <li class="site-menu-item <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route("admin.users.index")); ?>">
                <span class="site-menu-title">Users</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
            <li class="site-menu-item <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.permissions.index')); ?>">
                <span class="site-menu-title">Permission</span>
              </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
            <li class="site-menu-item <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.roles.index')); ?>">
                <span class="site-menu-title">Role</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_access')): ?>
            <li class="site-menu-item <?php echo e(request()->is("admin/customers") || request()->is("admin/customers/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.customers.index')); ?>">
                <span class="site-menu-title">Customer</span>
              </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('item_access')): ?>
            <li class="site-menu-item <?php echo e(request()->is("admin/items") || request()->is("admin/items/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.items.index')); ?>">
                <span class="site-menu-title">Items</span>
              </a>
            </li>
            <?php endif; ?>

            <li class="site-menu-item <?php echo e(request()->is("admin/bills") || request()->is("admin/bills/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.bills.index')); ?>">
                <span class="site-menu-title">bills</span>
              </a>
            </li>

            <li class="site-menu-item <?php echo e(request()->is("admin/payment_entries") || request()->is("admin/payment_entries/*") ? "active" : ""); ?>">
              <a class="animsition-link" href="<?php echo e(route('admin.payment_entries.index')); ?>">
                <span class="site-menu-title">Payment</span>
              </a>
            </li>
        </ul>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\bill\resources\views/partials/menu.blade.php ENDPATH**/ ?>