
<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title"><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.permission.title_singular')); ?></h1>
</div>

<div class="page-content">
    <div class="panel">
        <div class="panel-body">
            <form method="POST" action="<?php echo e(route("admin.permissions.store")); ?>" enctype="multipart/form-data" id="hms_form">
                <?php echo csrf_field(); ?>
                <div class="form-group form-material">
                    <label class="form-control-label required" for="title"><?php echo e(trans('cruds.permission.fields.title')); ?></label>
                    <input class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" type="text" name="title" id="title" value="<?php echo e(old('title', '')); ?>" required>
                    <div class="invalid-feedback">
                    <?php if($errors->has('title')): ?>
                            <?php echo e($errors->first('title')); ?>

                    <?php endif; ?>
                    </div>
                    <span class="help-block"><?php echo e(trans('cruds.permission.fields.title_helper')); ?></span>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary waves-effect waves-classic" type="submit">
                        <?php echo e(trans('global.save')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script type="text/javascript">
    $("#hms_form").validate({
            rules: {
               title: {
                   required: true,
                   minlength:2
               }
            },
            errorPlacement: function (error, element){
                $placement=$(element).parent().find('.invalid-feedback');
                error.appendTo($placement);
                $placement.show();
            },
            highlight: function(element, errorClass, validClass) {
                $(element).parent().addClass('has-danger');
                $placement=$(element).parent().find('.invalid-feedback');
                $placement.show();
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).parent().removeClass('has-danger');
                $placement=$(element).parent().find('.invalid-feedback');
                $(element).removeClass('error');
                $placement.hide();
            }
       });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bill\resources\views/admin/permissions/create.blade.php ENDPATH**/ ?>