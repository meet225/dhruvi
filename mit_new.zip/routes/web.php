<?php
Route::get('/', function () { return redirect()->route('login'); });
Route::get('/login', function () { return redirect()->route('login'); });

Route::get('/home', function(){
    if(session('status')){
        return redirect()->route('admin.home')->with('status', session('status'));
    }
    return redirect()->route('admin.home');
});
Auth::routes(['register' => false]);
// Admin
Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth']], function () {
    Route::get('/', function () { return redirect()->route('login'); })->name('home');
    Route::get('dashboard', function () { return redirect()->route('admin.users.index'); })->name('home');

    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');

    /*Customers*/
    Route::delete('customers/destroy', 'CustomersController@massDestroy')->name('customers.massDestroy');
    Route::resource('customers', 'CustomersController');

    /*Items*/
    Route::delete('items/destroy', 'ItemsController@massDestroy')->name('items.massDestroy');
    Route::resource('items', 'ItemsController');

    Route::delete('bills/destroy', 'BillController@massDestroy')->name('bills.massDestroy');
    Route::resource('bills', 'BillController');

    //Code Generations
    Route::get('code_generations/{typeid}', 'CodeGenerationsController@fetch_codegen_data');
    Route::get('code_generations','CodeGenerationsController@index')->name('code_generations.index');
    Route::post('code_generations','CodeGenerationsController@store')->name('code_generations.store');

    /* Payment Entry*/
    Route::delete('payment_entries/massDestroy', 'PaymentEntryController@massDestroy')->name('payment_entries.massDestroy');
    Route::resource('payment_entries', 'PaymentEntryController');
    Route::get('party-bills', 'PaymentEntryController@getPartyBills')->name('party-bills');

    Route::get('print/bill', 'PrintBillController@index')->name('print.bill');
    Route::get('print/billpayment', 'PrintPaymentBillController@index')->name('print.billpayment');
    

    Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['auth']], function () {
        // Change password
        if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {
            Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
            Route::post('password', 'ChangePasswordController@update')->name('password.update');
        }
    });
    //Select2 Find
    Route::post('select2_find','CommonController@select2Find')->name('select2_find');
});
