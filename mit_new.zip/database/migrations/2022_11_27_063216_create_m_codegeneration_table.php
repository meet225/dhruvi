<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMCodegenerationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('m_codegeneration', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('typeid');
            $table->longText('pattern');
            $table->integer('startmonth');
            $table->bigInteger('startwith');
            $table->integer('leadingzero');
            $table->enum('tags_separator',['F','B','D'])->nullable()->default('F')->comment='F-forward slash, b-backward slash, d-dash';
            $table->tinyInteger('status')->default(1)->comment='1=Active, 0=Inactive';
            $table->timestamps();
            $table->softDeletes();
            $table->char('stats_flag',1);       
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('m_codegeneration');
    }
}
