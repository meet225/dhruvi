<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBillsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bills', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('billcode',100);
            $table->string('billcodeid',255);
            $table->dateTime('billatetime')->nullable();
            $table->bigInteger('customerid')->nullable();
            $table->decimal('grandtotal',65,2)->nullable();
            $table->decimal('discper',5,2)->nullable();
            $table->decimal('discamt',65,2)->nullable();
            $table->decimal('othercharges',9,2)->nullable();
            $table->decimal('roundoff',9,2)->nullable();
            $table->decimal('netamount',65,2)->nullable();
            $table->integer('billpay')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bills');
    }
}
