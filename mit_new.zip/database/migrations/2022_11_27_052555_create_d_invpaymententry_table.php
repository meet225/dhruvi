<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDInvpaymententryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_invpaymententry', function (Blueprint $table) {
            $table->bigIncrements('invpaymententrydetailid');
            $table->bigInteger('invpaymententryid');
            $table->bigInteger('purchasebillid');
            $table->decimal('invoiceamount',65,2)->nullable();
            $table->decimal('payingamount',65,2)->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->char('stats_flag',1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_invpaymententry');
    }
}
